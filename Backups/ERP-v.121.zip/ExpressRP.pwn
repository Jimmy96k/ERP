#pragma dynamic 65536

#include <a_samp>

new bool:ER_FirstSpawned[MAX_PLAYERS];
//  INCLUDES
#include <a_mysql>
#include <sscanf2>
#include <Pawn.CMD>
#include <streamer>
#include <foreach>
#include <whirlpool>
//  CORE
#include "includes/core/defines.pwn"
#include "includes/core/colors.pwn"
#include "includes/core/enums.pwn"
#include "includes/core/utils.pwn"
#include "includes/core/mysql.pwn"
#include "includes/core/servercore.pwn"
#include "includes/core/accounts.pwn"
#include "includes/core/savechars.pwn"
//  SYSTEMS
#include "includes/systems/tutorial.pwn"
#include "includes/systems/admin.pwn"
#include "includes/systems/stats.pwn"
#include "includes/systems/help.pwn"
#include "includes/systems/chat.pwn"
#include "includes/systems/phone.pwn"
#include "includes/systems/radio.pwn"
#include "includes/systems/inventory.pwn"
#include "includes/systems/weapons.pwn"
#include "includes/systems/vehicles.pwn"
#include "includes/systems/hospitals.pwn"
#include "includes/systems/death.pwn"
#include "includes/systems/businesses.pwn"
#include "includes/systems/families.pwn"
#include "includes/systems/factions.pwn"
//  MAPS
#include "includes/maps/pershing_square.pwn" 	// Pershing Square MAP
#include "includes/maps/cityhall_2018.pwn" 		// City Hall MAP
#include "includes/maps/rehab_community.pwn" 	// Rehab_Community MAP GROOVE
#include "includes/maps/restoran.pwn"           // Restaurant MAP GROOVE

//
main() { }

public OnGameModeInit()
{
    SetGameModeText("Express Roleplay - Gaming");
    ShowPlayerMarkers(PLAYER_MARKERS_MODE_GLOBAL);
    UsePlayerPedAnims();
    DisableInteriorEnterExits();
    ER_CreateLoginTextDraws();

    ER_MySQLConnect();
	//  CORE
    ER_LoadServerCore();
	//  SYSTEMS
	ER_LoadHospitals();
    ER_LoadHospitalBeds();
    ER_LoadAudioStreams();
    ER_LoadBusinesses();
    ER_LoadFamilies();
    ER_LoadFactions();
    ER_LoadVehicles();
	//  MAPS
	LoadPershingSquareMap();	// Pershing Square MAP
    LoadCityHall2018Map();		// City Hall MAP
    LoadRehabCommunityMap();	// Rehab Community MAP
    LoadRestoranObjects();		// Restaurant MAP GROOVE
    //
    return 1;
}

public OnGameModeExit()
{
    foreach(new i : Player)
    {
        if(PlayerInfo[i][pLoggedIn])
        {
            ER_SaveLastPosition(i);
            ER_SaveCharacter(i);
        }
    }
    ER_MySQLClose();
    return 1;
}

public OnPlayerConnect(playerid)
{
    ER_ResetPlayer(playerid);
    TogglePlayerSpectating(playerid, true);
    ER_ShowLoginScreen(playerid);
    ER_ShowLoginOrRegister(playerid);
    //  MAPS
    
    RemovePershingSquareMapForPlayer(playerid); 	// Pershing Square MAP
    RemoveRehabCommunityMap(playerid);				// Rehab Community MAP
    RemoveRestoranBuildings(playerid);              // Restaurant MAP GROOVE
    
    return 1;
}

public OnPlayerUpdate(playerid)
{
    if(PlayerInfo[playerid][pLoggedIn] && PlayerInfo[playerid][pTutorial] == 1 && !PlayerInfo[playerid][pInjured] && !PlayerInfo[playerid][pHospitalized])
    {
        GetPlayerPos(playerid, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ]);
        GetPlayerFacingAngle(playerid, PlayerInfo[playerid][pSpawnA]);
        PlayerInfo[playerid][pSpawnInt] = GetPlayerInterior(playerid);
        PlayerInfo[playerid][pSpawnVW] = GetPlayerVirtualWorld(playerid);
    }
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    ER_SaveLastPosition(playerid);
    ER_SaveCharacter(playerid);
    ER_ClearPhoneState(playerid);
    ER_ClearFamilyBeacon(playerid);
    ER_ReleaseHospitalBed(playerid);
    return 1;
}

public OnPlayerSpawn(playerid)
{
    if(PlayerInfo[playerid][pLoggedIn])
    {
        SetPlayerHealth(playerid, PlayerInfo[playerid][pHealth]);
        SetPlayerArmour(playerid, PlayerInfo[playerid][pArmor]);
        ER_GiveSavedWeapons(playerid);
    }
    return 1;
}

public OnPlayerText(playerid, text[])
{
    if(!PlayerInfo[playerid][pLoggedIn]) return 0;
    if(ER_PhoneText(playerid, text)) return 0;
    ER_LocalChat(playerid, text, CHAT_RANGE_NORMAL);
    return 0;
}

public OnPlayerDeath(playerid, killerid, reason)
{
    ER_StartInjured(playerid, killerid, reason);
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(ER_AccountDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_TutorialDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_HospitalDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_BusinessDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_FamilyDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_FactionDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_AudioDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_VehicleDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    return 0;
}


public OnPlayerRequestClass(playerid, classid)
{
	#pragma unused classid
	if(PlayerInfo[playerid][pLoggedIn])
	{
		ER_SpawnCharacter(playerid);
	}
	else
	{
		TogglePlayerSpectating(playerid, true);
		ER_ShowLoginScreen(playerid);
	}
	return 0;
}
