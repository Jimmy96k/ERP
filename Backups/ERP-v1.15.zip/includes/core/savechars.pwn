#if defined _ER_SAVECHARS_INCLUDED
    #endinput
#endif
#define _ER_SAVECHARS_INCLUDED


stock ER_SaveLastPosition(playerid)
{
    if(!PlayerInfo[playerid][pLoggedIn] || PlayerInfo[playerid][pID] <= 0) return 0;
    if(PlayerInfo[playerid][pTutorial] != 1) return 0;
    if(PlayerInfo[playerid][pInjured] || PlayerInfo[playerid][pHospitalized]) return 0;

    GetPlayerPos(playerid, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ]);
    GetPlayerFacingAngle(playerid, PlayerInfo[playerid][pSpawnA]);
    PlayerInfo[playerid][pSpawnInt] = GetPlayerInterior(playerid);
    PlayerInfo[playerid][pSpawnVW] = GetPlayerVirtualWorld(playerid);

    new q[256];
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `spawn_x`=%f,`spawn_y`=%f,`spawn_z`=%f,`spawn_a`=%f,`spawn_int`=%d,`spawn_vw`=%d WHERE `id`=%d",
        PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ], PlayerInfo[playerid][pSpawnA], PlayerInfo[playerid][pSpawnInt], PlayerInfo[playerid][pSpawnVW], PlayerInfo[playerid][pID]);
    mysql_tquery(MainPipeline, q);
    return 1;
}

CMD:savepos(playerid, params[])
{
    if(!PlayerInfo[playerid][pLoggedIn]) return ER_Send(playerid, COLOR_GREY, "You must be logged in.");
    ER_SaveLastPosition(playerid);
    return ER_Send(playerid, COLOR_GREEN, "Your current position has been saved.");
}


stock ER_LoadCharacter(playerid)
{
    new q[160];
    mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `accounts` WHERE `id`=%d LIMIT 1", PlayerInfo[playerid][pID]);
    mysql_tquery(MainPipeline, q, "ER_OnCharacterLoad", "i", playerid);
    return 1;
}

forward ER_OnCharacterLoad(playerid);
public ER_OnCharacterLoad(playerid)
{
    if(!IsPlayerConnected(playerid)) return 1;
    new rows;
    cache_get_row_count(rows);
    if(!rows) return Kick(playerid);
    cache_get_value_name_int(0, "id", PlayerInfo[playerid][pID]);
    cache_get_value_name_int(0, "tutorial", PlayerInfo[playerid][pTutorial]);
    cache_get_value_name_int(0, "admin", PlayerInfo[playerid][pAdmin]);
    cache_get_value_name_int(0, "vip", PlayerInfo[playerid][pPlayerVip]);
    cache_get_value_name_int(0, "level", PlayerInfo[playerid][pLevel]);
    cache_get_value_name_int(0, "playing_hours", PlayerInfo[playerid][pPlayingHours]);
    cache_get_value_name_int(0, "age", PlayerInfo[playerid][pAge]);
    cache_get_value_name(0, "dob", PlayerInfo[playerid][pDOB], 16);
    cache_get_value_name(0, "country", PlayerInfo[playerid][pCountry], 32);
    cache_get_value_name_int(0, "gender", PlayerInfo[playerid][pGender]);
    cache_get_value_name_int(0, "accent", PlayerInfo[playerid][pAccent]);
    cache_get_value_name_int(0, "skin", PlayerInfo[playerid][pSkin]);
    cache_get_value_name_int(0, "cash", PlayerInfo[playerid][pCash]);
    cache_get_value_name_int(0, "bank", PlayerInfo[playerid][pBank]);
    cache_get_value_name_int(0, "phone", PlayerInfo[playerid][pPhone]);
    cache_get_value_name_int(0, "phonebook", PlayerInfo[playerid][pPhonebook]);
    cache_get_value_name_int(0, "phone_off", PlayerInfo[playerid][pPhoneOff]);
    cache_get_value_name_int(0, "has_radio", PlayerInfo[playerid][pHasRadio]);
    cache_get_value_name_int(0, "radio_freq", PlayerInfo[playerid][pRadio]);
    cache_get_value_name_int(0, "vehicle_lock", PlayerInfo[playerid][pVehicleLock]);
    cache_get_value_name_int(0, "hosp_insurance", PlayerInfo[playerid][pHospInsurance]);
    cache_get_value_name(0, "married_to", PlayerInfo[playerid][pMarriedTo], MAX_PLAYER_NAME_EX);
    cache_get_value_name_int(0, "crimes", PlayerInfo[playerid][pCrimes]);
    cache_get_value_name_int(0, "arrests", PlayerInfo[playerid][pArrests]);
    cache_get_value_name_int(0, "wanted_level", PlayerInfo[playerid][pWantedLevel]);
    cache_get_value_name_int(0, "materials", PlayerInfo[playerid][pMaterials]);
    cache_get_value_name_int(0, "pot", PlayerInfo[playerid][pPot]);
    cache_get_value_name_int(0, "crack", PlayerInfo[playerid][pCrack]);
    cache_get_value_name_int(0, "rope", PlayerInfo[playerid][pRope]);
    cache_get_value_name_int(0, "packages", PlayerInfo[playerid][pPackages]);
    cache_get_value_name_int(0, "seeds", PlayerInfo[playerid][pSeeds]);
    cache_get_value_name_int(0, "sprunk", PlayerInfo[playerid][pSprunk]);
    cache_get_value_name_int(0, "spraycans", PlayerInfo[playerid][pSprayCans]);
    cache_get_value_name_float(0, "health", PlayerInfo[playerid][pHealth]);
    cache_get_value_name_float(0, "armor", PlayerInfo[playerid][pArmor]);
    cache_get_value_name_int(0, "respect_points", PlayerInfo[playerid][pRespectPoints]);
    cache_get_value_name_int(0, "warnings", PlayerInfo[playerid][pWarnings]);
    cache_get_value_name_int(0, "hospital_time", PlayerInfo[playerid][pHospitalTime]);
    cache_get_value_name_int(0, "tog_free_hospital", PlayerInfo[playerid][pTogFreeHospital]);
    cache_get_value_name_int(0, "family_id", PlayerInfo[playerid][pFamily]);
    cache_get_value_name_int(0, "family_rank", PlayerInfo[playerid][pFamilyRank]);
    cache_get_value_name_int(0, "family_crew", PlayerInfo[playerid][pFamilyCrew]);
    cache_get_value_name_int(0, "business_id", PlayerInfo[playerid][pBusiness]);
    cache_get_value_name_float(0, "spawn_x", PlayerInfo[playerid][pSpawnX]);
    cache_get_value_name_float(0, "spawn_y", PlayerInfo[playerid][pSpawnY]);
    cache_get_value_name_float(0, "spawn_z", PlayerInfo[playerid][pSpawnZ]);
    cache_get_value_name_float(0, "spawn_a", PlayerInfo[playerid][pSpawnA]);
    cache_get_value_name_int(0, "spawn_int", PlayerInfo[playerid][pSpawnInt]);
    cache_get_value_name_int(0, "spawn_vw", PlayerInfo[playerid][pSpawnVW]);
    for(new j; j < MAX_JOBS_PER_PLAYER; j++)
    {
        new field[16]; format(field, sizeof(field), "job%d", j);
        cache_get_value_name_int(0, field, PlayerInfo[playerid][pPlayerJob][j]);
    }
    for(new w; w < MAX_WEAPON_SLOTS; w++)
    {
        new field[16]; format(field, sizeof(field), "weapon%d", w);
        cache_get_value_name_int(0, field, PlayerInfo[playerid][pPlayerWeapons][w]);
    }
    PlayerInfo[playerid][pLoggedIn] = 1;
    ER_Send(playerid, COLOR_GREEN, "Login successful.");
    if(PlayerInfo[playerid][pTutorial]) ER_SpawnCharacter(playerid);
    else ER_StartTutorial(playerid);
    return 1;
}

stock ER_SaveCharacter(playerid)
{
    if(!PlayerInfo[playerid][pLoggedIn] || PlayerInfo[playerid][pID] <= 0) return 0;

    // ER_SAVECHAR_LIVE_POSITION_PATCH
    // Also refresh last position here before the big character save.
    if(PlayerInfo[playerid][pTutorial] == 1 && !PlayerInfo[playerid][pInjured] && !PlayerInfo[playerid][pHospitalized])
    {
        GetPlayerPos(playerid, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ]);
        GetPlayerFacingAngle(playerid, PlayerInfo[playerid][pSpawnA]);
        PlayerInfo[playerid][pSpawnInt] = GetPlayerInterior(playerid);
        PlayerInfo[playerid][pSpawnVW] = GetPlayerVirtualWorld(playerid);
    }

    GetPlayerHealth(playerid, PlayerInfo[playerid][pHealth]);
    GetPlayerArmour(playerid, PlayerInfo[playerid][pArmor]);
    new q[4096];
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `tutorial`=%d,`admin`=%d,`vip`=%d,`level`=%d,`playing_hours`=%d,`age`=%d,`dob`='%e',`country`='%e',`gender`=%d,`accent`=%d,`skin`=%d,`cash`=%d,`bank`=%d,`phone`=%d,`phonebook`=%d,`phone_off`=%d,`has_radio`=%d,`radio_freq`=%d,`vehicle_lock`=%d,`hosp_insurance`=%d,`married_to`='%e',`crimes`=%d,`arrests`=%d,`wanted_level`=%d,`materials`=%d,`pot`=%d,`crack`=%d,`rope`=%d,`packages`=%d,`seeds`=%d,`sprunk`=%d,`spraycans`=%d,`health`=%f,`armor`=%f,`respect_points`=%d,`warnings`=%d,`hospital_time`=%d,`tog_free_hospital`=%d,`family_id`=%d,`family_rank`=%d,`family_crew`=%d,`business_id`=%d,`spawn_x`=%f,`spawn_y`=%f,`spawn_z`=%f,`spawn_a`=%f,`spawn_int`=%d,`spawn_vw`=%d",
        PlayerInfo[playerid][pTutorial], PlayerInfo[playerid][pAdmin], PlayerInfo[playerid][pPlayerVip], PlayerInfo[playerid][pLevel], PlayerInfo[playerid][pPlayingHours], PlayerInfo[playerid][pAge], PlayerInfo[playerid][pDOB], PlayerInfo[playerid][pCountry], PlayerInfo[playerid][pGender], PlayerInfo[playerid][pAccent], PlayerInfo[playerid][pSkin], PlayerInfo[playerid][pCash], PlayerInfo[playerid][pBank], PlayerInfo[playerid][pPhone], PlayerInfo[playerid][pPhonebook], PlayerInfo[playerid][pPhoneOff], PlayerInfo[playerid][pHasRadio], PlayerInfo[playerid][pRadio], PlayerInfo[playerid][pVehicleLock], PlayerInfo[playerid][pHospInsurance], PlayerInfo[playerid][pMarriedTo], PlayerInfo[playerid][pCrimes], PlayerInfo[playerid][pArrests], PlayerInfo[playerid][pWantedLevel], PlayerInfo[playerid][pMaterials], PlayerInfo[playerid][pPot], PlayerInfo[playerid][pCrack], PlayerInfo[playerid][pRope], PlayerInfo[playerid][pPackages], PlayerInfo[playerid][pSeeds], PlayerInfo[playerid][pSprunk], PlayerInfo[playerid][pSprayCans], PlayerInfo[playerid][pHealth], PlayerInfo[playerid][pArmor], PlayerInfo[playerid][pRespectPoints], PlayerInfo[playerid][pWarnings], PlayerInfo[playerid][pHospitalTime], PlayerInfo[playerid][pTogFreeHospital], PlayerInfo[playerid][pFamily], PlayerInfo[playerid][pFamilyRank], PlayerInfo[playerid][pFamilyCrew], PlayerInfo[playerid][pBusiness], PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ], PlayerInfo[playerid][pSpawnA], PlayerInfo[playerid][pSpawnInt], PlayerInfo[playerid][pSpawnVW]);
    for(new j; j < MAX_JOBS_PER_PLAYER; j++) mysql_format(MainPipeline, q, sizeof(q), "%s,`job%d`=%d", q, j, PlayerInfo[playerid][pPlayerJob][j]);
    for(new w; w < MAX_WEAPON_SLOTS; w++) mysql_format(MainPipeline, q, sizeof(q), "%s,`weapon%d`=%d", q, w, PlayerInfo[playerid][pPlayerWeapons][w]);
    mysql_format(MainPipeline, q, sizeof(q), "%s WHERE `id`=%d", q, PlayerInfo[playerid][pID]);
    mysql_tquery(MainPipeline, q);
    return 1;
}
