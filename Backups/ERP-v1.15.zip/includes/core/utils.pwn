#if defined _ER_UTILS_INCLUDED
    #endinput
#endif
#define _ER_UTILS_INCLUDED

stock ER_Send(playerid, color, const msg[]) return SendClientMessage(playerid, color, msg);

stock ER_GetName(playerid)
{
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    return name;
}


new Text:ER_LoginTD[6];

stock ER_CreateLoginTextDraws()
{
	// Top black bar
	ER_LoginTD[0] = TextDrawCreate(0.000000, 0.000000, "_");
	TextDrawBackgroundColor(ER_LoginTD[0], 255);
	TextDrawFont(ER_LoginTD[0], 1);
	TextDrawLetterSize(ER_LoginTD[0], 0.500000, 15.500000);
	TextDrawColor(ER_LoginTD[0], -1);
	TextDrawSetOutline(ER_LoginTD[0], 0);
	TextDrawSetProportional(ER_LoginTD[0], 1);
	TextDrawUseBox(ER_LoginTD[0], 1);
	TextDrawBoxColor(ER_LoginTD[0], 255);
	TextDrawTextSize(ER_LoginTD[0], 640.000000, 0.000000);

	// Bottom black bar
	ER_LoginTD[1] = TextDrawCreate(0.000000, 345.000000, "_");
	TextDrawBackgroundColor(ER_LoginTD[1], 255);
	TextDrawFont(ER_LoginTD[1], 1);
	TextDrawLetterSize(ER_LoginTD[1], 0.500000, 13.500000);
	TextDrawColor(ER_LoginTD[1], -1);
	TextDrawSetOutline(ER_LoginTD[1], 0);
	TextDrawSetProportional(ER_LoginTD[1], 1);
	TextDrawUseBox(ER_LoginTD[1], 1);
	TextDrawBoxColor(ER_LoginTD[1], 255);
	TextDrawTextSize(ER_LoginTD[1], 640.000000, 0.000000);

	// Main title
	ER_LoginTD[2] = TextDrawCreate(320.000000, 42.000000, "Express Roleplay Gaming");
	TextDrawAlignment(ER_LoginTD[2], 2);
	TextDrawBackgroundColor(ER_LoginTD[2], 255);
	TextDrawFont(ER_LoginTD[2], 3);
	TextDrawLetterSize(ER_LoginTD[2], 0.850000, 4.000000);
	TextDrawColor(ER_LoginTD[2], 0xF6A800FF);
	TextDrawSetOutline(ER_LoginTD[2], 2);
	TextDrawSetProportional(ER_LoginTD[2], 1);
	TextDrawSetShadow(ER_LoginTD[2], 2);

	// Subtitle
	ER_LoginTD[3] = TextDrawCreate(320.000000, 104.000000, "_");
	TextDrawAlignment(ER_LoginTD[3], 2);
	TextDrawBackgroundColor(ER_LoginTD[3], 255);
	TextDrawFont(ER_LoginTD[3], 3);
	TextDrawLetterSize(ER_LoginTD[3], 0.010000, 0.010000);
	TextDrawColor(ER_LoginTD[3], 0xFFFFFFFF);
	TextDrawSetOutline(ER_LoginTD[3], 2);
	TextDrawSetProportional(ER_LoginTD[3], 1);
	TextDrawSetShadow(ER_LoginTD[3], 2);

	// Bottom info placeholders
	ER_LoginTD[4] = TextDrawCreate(320.000000, 365.000000, "News: Welcome to Express Roleplay - Gaming!");
	TextDrawAlignment(ER_LoginTD[4], 2);
	TextDrawBackgroundColor(ER_LoginTD[4], 255);
	TextDrawFont(ER_LoginTD[4], 2);
	TextDrawLetterSize(ER_LoginTD[4], 0.520000, 2.100000);
	TextDrawColor(ER_LoginTD[4], 0xFFFFFFFF);
	TextDrawSetOutline(ER_LoginTD[4], 2);
	TextDrawSetProportional(ER_LoginTD[4], 1);

	ER_LoginTD[5] = TextDrawCreate(320.000000, 415.000000, "Website:   |   Discord:");
	TextDrawAlignment(ER_LoginTD[5], 2);
	TextDrawBackgroundColor(ER_LoginTD[5], 255);
	TextDrawFont(ER_LoginTD[5], 2);
	TextDrawLetterSize(ER_LoginTD[5], 0.470000, 1.900000);
	TextDrawColor(ER_LoginTD[5], 0xFFFFFFFF);
	TextDrawSetOutline(ER_LoginTD[5], 2);
	TextDrawSetProportional(ER_LoginTD[5], 1);

	return 1;
}

stock ER_ShowLoginScreen(playerid)
{
	new bottom[144], news[160], website[96], discord[96];

	if(ServerCore[scNews][0]) format(news, sizeof(news), "News: %s", ServerCore[scNews]);
	else format(news, sizeof(news), "News: Welcome to Express Roleplay - Gaming!");

	if(ServerCore[scWebsite][0]) format(website, sizeof(website), "%s", ServerCore[scWebsite]);
	else format(website, sizeof(website), "Not set");

	if(ServerCore[scDiscord][0]) format(discord, sizeof(discord), "%s", ServerCore[scDiscord]);
	else format(discord, sizeof(discord), "Not set");

	format(bottom, sizeof(bottom), "Website: %s   |   Discord: %s", website, discord);
	TextDrawSetString(ER_LoginTD[4], news);
	TextDrawSetString(ER_LoginTD[5], bottom);

	for(new i; i < 6; i++)
	{
		TextDrawShowForPlayer(playerid, ER_LoginTD[i]);
	}

	// Login/Register should always look like night, regardless of real server time.
	SetPlayerWeather(playerid, 20);
	SetPlayerTime(playerid, 0, 0);
	return 1;
}

stock ER_HideLoginScreen(playerid)
{
	for(new i; i < 6; i++)
	{
		TextDrawHideForPlayer(playerid, ER_LoginTD[i]);
	}

	// After login/register, return player to normal daylight/server style.
	SetPlayerWeather(playerid, 1);
	SetPlayerTime(playerid, 12, 0);
	return 1;
}

stock ER_ForceDefaultSpawn(playerid)
{
	PlayerInfo[playerid][pSpawnX] = ServerCore[scDefaultSpawnX];
	PlayerInfo[playerid][pSpawnY] = ServerCore[scDefaultSpawnY];
	PlayerInfo[playerid][pSpawnZ] = ServerCore[scDefaultSpawnZ];
	PlayerInfo[playerid][pSpawnA] = ServerCore[scDefaultSpawnA];
	PlayerInfo[playerid][pSpawnInt] = ServerCore[scDefaultSpawnInt];
	PlayerInfo[playerid][pSpawnVW] = ServerCore[scDefaultSpawnVW];

	if(PlayerInfo[playerid][pID] > 0)
	{
		new q[256];
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `spawn_x`=%f,`spawn_y`=%f,`spawn_z`=%f,`spawn_a`=%f,`spawn_int`=%d,`spawn_vw`=%d WHERE `id`=%d",
			PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ], PlayerInfo[playerid][pSpawnA], PlayerInfo[playerid][pSpawnInt], PlayerInfo[playerid][pSpawnVW], PlayerInfo[playerid][pID]);
		mysql_tquery(MainPipeline, q);
	}
	return 1;
}


stock ER_ResetPlayer(playerid)
{
    format(PlayerInfo[playerid][pName], MAX_PLAYER_NAME_EX, "%s", ER_GetName(playerid));
    PlayerInfo[playerid][pID] = 0;
    PlayerInfo[playerid][pLoggedIn] = 0;
    PlayerInfo[playerid][pRegistered] = 0;
    PlayerInfo[playerid][pTutorial] = 0;
    PlayerInfo[playerid][pTutorialStep] = 0;
    PlayerInfo[playerid][pAdmin] = 0;
    PlayerInfo[playerid][pPlayerVip] = 0;
    PlayerInfo[playerid][pPhone] = 0;
    PlayerInfo[playerid][pPhoneOff] = false;
    PlayerInfo[playerid][pPhonespeaker] = false;
    PlayerInfo[playerid][pPhoneline] = INVALID_CALL_PLAYER;
    PlayerInfo[playerid][pCalling] = INVALID_CALL_PLAYER;
    PlayerInfo[playerid][pCallState] = 0;
    PlayerInfo[playerid][pPhonebook] = 0;
    PlayerInfo[playerid][pHospInsurance] = NO_HOSPITAL_INSURANCE;
    PlayerInfo[playerid][pHasRadio] = 0;
    PlayerInfo[playerid][pRadio] = 0;
    PlayerInfo[playerid][pVehicleLock] = 0;
    PlayerInfo[playerid][pHospitalTime] = 30;
    PlayerInfo[playerid][pTogFreeHospital] = 0;
    PlayerInfo[playerid][pFamily] = INVALID_FAMILY_ID;
    PlayerInfo[playerid][pFamilyRank] = 0;
    PlayerInfo[playerid][pFamilyCrew] = 0;
    PlayerInfo[playerid][pBusiness] = INVALID_BUSINESS_ID;
    PlayerInfo[playerid][pInjured] = 0;
    PlayerInfo[playerid][pHospitalized] = 0;
    PlayerInfo[playerid][pHospitalBed] = -1;
    PlayerInfo[playerid][pHospitalID] = -1;
    PlayerInfo[playerid][pDeliveredByEMS] = 0;
    for(new i; i < MAX_JOBS_PER_PLAYER; i++) PlayerInfo[playerid][pPlayerJob][i] = 0;
    for(new w; w < MAX_WEAPON_SLOTS; w++) PlayerInfo[playerid][pPlayerWeapons][w] = 0;
    return 1;
}

stock ER_FormatMoney(amount)
{
    new out[32];
    format(out, sizeof(out), "$%d", amount);
    return out;
}

stock ER_IsAdmin(playerid, level)
{
    return PlayerInfo[playerid][pAdmin] >= level || PlayerInfo[playerid][pAdmin] == ADMIN_EXEC;
}

stock ER_ApplyDefaultPlayerInfo(playerid)
{
    PlayerInfo[playerid][pTutorial] = 0;
    PlayerInfo[playerid][pTutorialStep] = 0;
    PlayerInfo[playerid][pLevel] = 1;
    PlayerInfo[playerid][pPlayingHours] = 0;
    PlayerInfo[playerid][pCash] = ServerCore[scDefaultCash];
    PlayerInfo[playerid][pBank] = ServerCore[scDefaultBank];
    PlayerInfo[playerid][pAge] = 18;
    format(PlayerInfo[playerid][pDOB], 16, "01/01/2000");
    format(PlayerInfo[playerid][pCountry], 32, "Unknown");
    PlayerInfo[playerid][pGender] = 1;
    PlayerInfo[playerid][pAccent] = 0;
    PlayerInfo[playerid][pSkin] = ServerCore[scDefaultMaleSkin];
    PlayerInfo[playerid][pPhone] = 0;
    PlayerInfo[playerid][pPhoneOff] = false;
    PlayerInfo[playerid][pPhonebook] = 0;
    PlayerInfo[playerid][pHospInsurance] = NO_HOSPITAL_INSURANCE;
    format(PlayerInfo[playerid][pMarriedTo], MAX_PLAYER_NAME_EX, "Nobody");
    PlayerInfo[playerid][pCrimes] = 0;
    PlayerInfo[playerid][pArrests] = 0;
    PlayerInfo[playerid][pWantedLevel] = 0;
    PlayerInfo[playerid][pMaterials] = 0;
    PlayerInfo[playerid][pPot] = 0;
    PlayerInfo[playerid][pCrack] = 0;
    PlayerInfo[playerid][pRope] = 0;
    PlayerInfo[playerid][pPackages] = 0;
    PlayerInfo[playerid][pSeeds] = 0;
    PlayerInfo[playerid][pSprunk] = 0;
    PlayerInfo[playerid][pSprayCans] = 0;
    PlayerInfo[playerid][pHealth] = 100.0;
    PlayerInfo[playerid][pArmor] = 0.0;
    PlayerInfo[playerid][pRespectPoints] = 0;
    PlayerInfo[playerid][pWarnings] = 0;
    PlayerInfo[playerid][pSpawnX] = ServerCore[scDefaultSpawnX];
    PlayerInfo[playerid][pSpawnY] = ServerCore[scDefaultSpawnY];
    PlayerInfo[playerid][pSpawnZ] = ServerCore[scDefaultSpawnZ];
    PlayerInfo[playerid][pSpawnA] = ServerCore[scDefaultSpawnA];
    PlayerInfo[playerid][pSpawnInt] = ServerCore[scDefaultSpawnInt];
    PlayerInfo[playerid][pSpawnVW] = ServerCore[scDefaultSpawnVW];
    return 1;
}

stock ER_SpawnCharacter(playerid)
{
    ER_HideLoginScreen(playerid);

    SetSpawnInfo(playerid, 0, PlayerInfo[playerid][pSkin],
        PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ], PlayerInfo[playerid][pSpawnA],
        0, 0, 0, 0, 0, 0);

    TogglePlayerSpectating(playerid, false);
    SpawnPlayer(playerid);

    SetPlayerInterior(playerid, PlayerInfo[playerid][pSpawnInt]);
    SetPlayerVirtualWorld(playerid, PlayerInfo[playerid][pSpawnVW]);
    SetPlayerPos(playerid, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ]);
    SetPlayerFacingAngle(playerid, PlayerInfo[playerid][pSpawnA]);
    SetPlayerSkin(playerid, PlayerInfo[playerid][pSkin]);
    SetPlayerHealth(playerid, PlayerInfo[playerid][pHealth]);
    SetPlayerArmour(playerid, PlayerInfo[playerid][pArmor]);

    ResetPlayerMoney(playerid);
    GivePlayerMoney(playerid, PlayerInfo[playerid][pCash]);
    return 1;
}

stock ER_NearbyMessage(Float:x, Float:y, Float:z, Float:range, color, const message[], world = -1, interior = -1)
{
    foreach(new i : Player)
    {
        if(!IsPlayerConnected(i) || !PlayerInfo[i][pLoggedIn]) continue;
        if(world != -1 && GetPlayerVirtualWorld(i) != world) continue;
        if(interior != -1 && GetPlayerInterior(i) != interior) continue;
        if(IsPlayerInRangeOfPoint(i, range, x, y, z)) SendClientMessage(i, color, message);
    }
    return 1;
}

stock Float:ER_FloatMin(Float:a, Float:b)
{
	return (a < b) ? a : b;
}

stock ER_GetPlayerZone(playerid, zone[], size = sizeof(zone))
{
	new Float:x, Float:y, Float:z;
	GetPlayerPos(playerid, x, y, z);

	if(x >= 44.0 && x <= 2997.0 && y >= -2892.0 && y <= -768.0)
		format(zone, size, "Los Santos");
	else if(x >= -2997.0 && x <= -1213.0 && y >= -1115.0 && y <= 1659.0)
		format(zone, size, "San Fierro");
	else if(x >= 869.0 && x <= 2997.0 && y >= 596.0 && y <= 2997.0)
		format(zone, size, "Las Venturas");
	else
		format(zone, size, "San Andreas");

	return 1;
}
