#if defined _ER_FACTIONS_INCLUDED
    #endinput
#endif
#define _ER_FACTIONS_INCLUDED

stock ER_LoadFactions()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `factions` WHERE `enabled`=1", "ER_OnFactionsLoad");
    return 1;
}

forward ER_OnFactionsLoad();
public ER_OnFactionsLoad()
{
    new rows;
    cache_get_row_count(rows);
    printf("[Factions] Loaded %d factions.", rows);
    return 1;
}

CMD:createfaction(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createfaction [name]");

    new q[256];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `factions` (`name`,`leader_id`,`leader_name`,`motd`,`enabled`) VALUES ('%e',0,'Nobody','Welcome to the faction.',1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnFactionCreated", "i", playerid);
    return 1;
}

forward ER_OnFactionCreated(playerid);
public ER_OnFactionCreated(playerid)
{
    new fid = cache_insert_id(), msg[96];
    format(msg, sizeof(msg), "Faction created. ID: %d. Use /editfaction [id] to edit it.", fid);
    ER_Send(playerid, COLOR_GREEN, msg);
    ER_LoadFactions();
    return 1;
}

CMD:editfactions(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    mysql_tquery(MainPipeline, "SELECT id,name,leader_name,enabled FROM `factions` ORDER BY id ASC", "ER_OnEditFactionsList", "i", playerid);
    return 1;
}

forward ER_OnEditFactionsList(playerid);
public ER_OnEditFactionsList(playerid)
{
    new rows, list[2048], id, name[64], leader[24], enabled;
    cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "No factions found.");

    format(list, sizeof(list), "ID\tName\tLeader\tStatus\n");
    for(new r; r < rows; r++)
    {
        cache_get_value_name_int(r, "id", id);
        cache_get_value_name(r, "name", name, sizeof(name));
        cache_get_value_name(r, "leader_name", leader, sizeof(leader));
        cache_get_value_name_int(r, "enabled", enabled);
        format(list, sizeof(list), "%s%d\t%s\t%s\t%s\n", list, id, name, leader, enabled ? "Enabled" : "Disabled");
    }
    ShowPlayerDialog(playerid, DIALOG_ADMIN_HELP, DIALOG_STYLE_TABLIST_HEADERS, "Factions", list, "Close", "");
    return 1;
}

CMD:editfaction(playerid, params[])
{
    new fid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", fid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editfaction [id]");

    new msg[128];
    format(msg, sizeof(msg), "Faction editor placeholder opened for faction ID %d. Full editor will be added next.", fid);
    return ER_Send(playerid, COLOR_GREEN, msg);
}
