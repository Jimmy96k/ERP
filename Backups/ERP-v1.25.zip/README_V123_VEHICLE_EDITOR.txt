
ExpressRP v1.23 Vehicle Editor Patch

Changes:
- Fixed vehicles not spawning on server start (VehID 65535 issue).
- Added Reset Vehicle before Reload This Vehicle.
- Reset respawns only selected vehicle to its saved SQL position.
- Paintjob no longer respawns vehicle; applies live.
- NOS no longer respawns vehicle; applies live.
- NOS page now has Unlimited NOS at the top (uses 10x nitro component for now).
- Mods are now selected from named dialogs instead of typing component numbers.
- Selected mod applies live and saves to SQL.
