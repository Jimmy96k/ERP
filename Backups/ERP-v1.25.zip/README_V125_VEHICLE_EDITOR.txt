
ExpressRP v1.25 Vehicle Editor Patch

Changes:
- Unlimited NOS now displays as "Unlimited NOS" instead of "NOS 10x".
- Added `unlimited_nos` SQL flag.
- Hydraulics moved to the main /editvehicle menu under NOS.
- Removed Stereo, NOS, and Hydraulics from the Mods dialog.
- Mods dialog now only shows body/visual mod categories.
- If the vehicle has no compatible body mods, it shows:
  "This vehicle does not have any compatible body modifications."
- Specific mod pages still filter incompatible components per vehicle model.

Run SQL_V125_VEHICLE_EDITOR.sql once before using this version.
