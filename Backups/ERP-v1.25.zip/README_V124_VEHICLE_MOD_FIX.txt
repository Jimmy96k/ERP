
ExpressRP v1.24 Vehicle Mods Fix

Fixes:
- Invalid/incompatible vehicle mod components no longer show for the selected model.
- Repeated X-Flow/Alien spoiler options reduced by compatibility filtering.
- Prevents AddVehicleComponent on incompatible mods to avoid opcode 0x6E7 warnings.
- Mods/paintjobs/NOS are reapplied when a vehicle respawns after exploding.
- OnVehicleSpawn hook added to reapply saved mods.
- Existing vehicle editor remains with live mod application and SQL saving.

Note:
Component compatibility is now filtered for the main tunable SA-MP vehicles:
Sultan, Jester, Elegy, Uranus, Flash, Stratum, Remington, Slamvan, Blade,
Savanna, Broadway, Tornado, plus universal wheels/NOS/stereo/hydraulics.
