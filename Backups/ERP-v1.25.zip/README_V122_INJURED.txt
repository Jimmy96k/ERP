
ExpressRP v1.22 Injured/Death Patch

Changes:
- Player enters injured mode after death.
- Sets health to 50 HP.
- Freezes the player on the floor.
- Applies CRACK/crckdeth2 lying animation.
- Shows: INJURED / WAITING FOR EMS TO ARRIVE...
- Re-applies freeze/animation every injury tick to prevent movement/desync.
- HP reduces until hospital transfer.
- /accept death still sends player to hospital immediately.
