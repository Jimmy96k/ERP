#if defined _ER_VEHICLES_INCLUDED
    #endinput
#endif
#define _ER_VEHICLES_INCLUDED

new VehicleTrackIcon[MAX_PLAYERS] = { -1, ... };

new const ER_VehicleNames[212][] =
{
	"Landstalker","Bravura","Buffalo","Linerunner","Pereniel"
	,"Sentinel","Dumper","Firetruck","Trashmaster","Stretch"
	,"Manana","Infernus","Voodoo","Pony","Mule","Cheetah"
	,"Ambulance","Leviathan","Moonbeam","Esperanto","Taxi"
	,"Washington","Bobcat","Mr Whoopee","BF Injection"
	,"Hunter","Premier","Enforcer","Securicar","Banshee"
	,"Predator","Bus","Rhino","Barracks","Hotknife","Trailer"
	,"Previon","Coach","Cabbie","Stallion","Rumpo","RC Bandit"
	,"Romero","Packer","Monster","Admiral","Squalo","Seasparrow"
	,"Pizzaboy","Tram","Trailer","Turismo","Speeder","Reefer","Tropic"
	,"Flatbed","Yankee","Caddy","Solair","Berkley's RC Van","Skimmer"
	,"PCJ-600","Faggio","Freeway","RC Baron","RC Raider","Glendale"
	,"Oceanic","Sanchez","Sparrow","Patriot","Quad","Coastguard"
	,"Dinghy","Hermes","Sabre","Rustler","ZR-350","Walton","Regina"
	,"Comet","BMX","Burrito","Camper","Marquis","Baggage","Dozer"
	,"Maverick","News Chopper","Rancher","FBI Rancher","Virgo"
	,"Greenwood","Jetmax","Hotring","Sandking","Blista Compact"
	,"Police Maverick","Boxville","Benson","Mesa","RC Goblin"
	,"Hotring Racer A","Hotring Racer B","Bloodring Banger"
	,"Rancher","Super GT","Elegant","Journey","Bike","Mountain Bike"
	,"Beagle","Cropdust","Stunt","Tanker","RoadTrain","Nebula","Majestic"
	,"Buccaneer","Shamal","Hydra","FCR-900","NRG-500","HPV1000"
	,"Cement Truck","Tow Truck","Fortune","Cadrona","FBI Truck"
	,"Willard","Forklift","Tractor","Combine","Feltzer","Remington"
	,"Slamvan","Blade","Freight","Streak","Vortex","Vincent","Bullet"
	,"Clover","Sadler","Firetruck LA","Hustler","Intruder","Primo"
	,"Cargobob","Tampa","Sunrise","Merit","Utility","Nevada","Yosemite"
	,"Windsor","Monster A","Monster B","Uranus","Jester","Sultan","Stratum"
	,"Elegy","Raindance","RC Tiger","Flash","Tahoma","Savanna","Bandito"
	,"Freight Flat","Streak Carriage","Kart","Mower","Duneride","Sweeper"
	,"Broadway","Tornado","AT-400","DFT-30","Huntley","Stafford","BF-400"
	,"Newsvan","Tug","Trailer 3","Emperor","Wayfarer","Euros","Hotdog"
	,"Club","Freight Carriage","Trailer 3","Andromada","Dodo","RC Cam"
	,"Launch","Police Car LSPD","Police Car SFPD","Police Car LVPD"
	,"Police Ranger","Picador","S.W.A.T.","Alpha","Phoenix","Glendale Shit"
	,"Sadler Shit","Luggage Trailer A","Luggage Trailer B","Stair Trailer"
	,"Boxville","Farm Plow","Utility Trailer"
};

stock ER_GetVehicleModelName(model)
{
	static name[32];
	if(model >= 400 && model <= 611) format(name, sizeof(name), "%s", ER_VehicleNames[model - 400]);
	else format(name, sizeof(name), "Unknown");
	return name;
}

stock ER_FindVehicleModel(const input[])
{
	if(strlen(input) == 0) return 0;
	if(input[0] >= '0' && input[0] <= '9')
	{
		new model = strval(input);
		if(model >= 400 && model <= 611) return model;
		return 0;
	}

	for(new i; i < sizeof(ER_VehicleNames); i++)
	{
		if(!strcmp(input, ER_VehicleNames[i], true)) return i + 400;
	}
	if(!strcmp(input, "nrg", true) || !strcmp(input, "nrg500", true)) return 522;
	return 0;
}

stock ER_GetVehicleAreaName(Float:x, Float:y, Float:z, dest[], size = sizeof(dest))
{
	#pragma unused z
	if(x >= 44.0 && x <= 2997.0 && y >= -2892.0 && y <= -768.0) format(dest, size, "Los Santos");
	else if(x >= -2997.0 && x <= -1213.0 && y >= -1115.0 && y <= 1659.0) format(dest, size, "San Fierro");
	else if(x >= 869.0 && x <= 2997.0 && y >= 596.0 && y <= 2997.0) format(dest, size, "Las Venturas");
	else format(dest, size, "San Andreas");
	return 1;
}

stock ER_GetVehicleLockName(locktype)
{
	static name[16];
	switch(locktype)
	{
		case 1: format(name, sizeof(name), "Alarm");
		case 2: format(name, sizeof(name), "Industrial");
		default: format(name, sizeof(name), "None");
	}
	return name;
}


stock ER_GetVehiclePaintjobName(paintjob)
{
    static name[18];
    switch(paintjob)
    {
        case -1: format(name, sizeof(name), "None");
        case 0: format(name, sizeof(name), "Paintjob 1");
        case 1: format(name, sizeof(name), "Paintjob 2");
        case 2: format(name, sizeof(name), "Paintjob 3");
        default: format(name, sizeof(name), "None");
    }
    return name;
}

stock ER_CanVehicleUsePaintjob(model)
{
    switch(model)
    {
        case 534, 535, 536, 558, 559, 560, 561, 562, 565, 567, 575, 576: return 1;
    }
    return 0;
}

stock ER_GetVehicleNOSName(nos)
{
    static name[18];
    switch(nos)
    {
        case 1008: format(name, sizeof(name), "NOS 5x");
        case 1009: format(name, sizeof(name), "NOS 2x");
        case 1010: format(name, sizeof(name), "NOS 10x");
        default: format(name, sizeof(name), "None");
    }
    return name;
}


stock ER_GetVehicleComponentName(component)
{
    static name[32];
    switch(component)
    {
        case 1000: format(name, sizeof(name), "Pro Spoiler");
        case 1001: format(name, sizeof(name), "Win Spoiler");
        case 1002: format(name, sizeof(name), "Drag Spoiler");
        case 1003: format(name, sizeof(name), "Alpha Spoiler");
        case 1014: format(name, sizeof(name), "Champ Scoop Hood");
        case 1015: format(name, sizeof(name), "Fury Scoop Hood");
        case 1016: format(name, sizeof(name), "Worx Scoop Hood");
        case 1017: format(name, sizeof(name), "Right Side Skirt");
        case 1018: format(name, sizeof(name), "Upswept Exhaust");
        case 1019: format(name, sizeof(name), "Twin Exhaust");
        case 1020: format(name, sizeof(name), "Large Exhaust");
        case 1021: format(name, sizeof(name), "Medium Exhaust");
        case 1022: format(name, sizeof(name), "Small Exhaust");
        case 1023: format(name, sizeof(name), "Fury Spoiler");
        case 1024: format(name, sizeof(name), "Square Fog Lamps");
        case 1025: format(name, sizeof(name), "Offroad Wheels");
        case 1073: format(name, sizeof(name), "Shadow Rims");
        case 1074: format(name, sizeof(name), "Mega Rims");
        case 1075: format(name, sizeof(name), "Rimshine Rims");
        case 1076: format(name, sizeof(name), "Wires Rims");
        case 1077: format(name, sizeof(name), "Classic Rims");
        case 1078: format(name, sizeof(name), "Twist Rims");
        case 1079: format(name, sizeof(name), "Cutter Rims");
        case 1080: format(name, sizeof(name), "Switch Rims");
        case 1081: format(name, sizeof(name), "Grove Rims");
        case 1082: format(name, sizeof(name), "Import Rims");
        case 1083: format(name, sizeof(name), "Dollar Rims");
        case 1084: format(name, sizeof(name), "Trance Rims");
        case 1085: format(name, sizeof(name), "Atomic Rims");
        case 1086: format(name, sizeof(name), "Stereo");
        case 1087: format(name, sizeof(name), "Hydraulics");
        case 1088: format(name, sizeof(name), "Alien Roof Vent");
        case 1089: format(name, sizeof(name), "X-Flow Exhaust");
        case 1090: format(name, sizeof(name), "Right Alien Side Skirt");
        case 1091: format(name, sizeof(name), "X-Flow Side Skirt");
        case 1092: format(name, sizeof(name), "Alien Exhaust");
        case 1093: format(name, sizeof(name), "X-Flow Exhaust");
        case 1094: format(name, sizeof(name), "Alien Side Skirt");
        case 1095: format(name, sizeof(name), "X-Flow Side Skirt");
        case 1096: format(name, sizeof(name), "Ahab Rims");
        case 1097: format(name, sizeof(name), "Virtual Rims");
        case 1098: format(name, sizeof(name), "Access Rims");
        case 1099: format(name, sizeof(name), "Left Chrome Side Skirt");
        case 1100: format(name, sizeof(name), "Chrome Grill");
        case 1101: format(name, sizeof(name), "Left Chrome Flames");
        case 1102: format(name, sizeof(name), "Left Chrome Strip");
        case 1103: format(name, sizeof(name), "Convertible Roof");
        case 1104: format(name, sizeof(name), "Chrome Exhaust");
        case 1105: format(name, sizeof(name), "Slamin Exhaust");
        case 1106: format(name, sizeof(name), "Right Chrome Arches");
        case 1107: format(name, sizeof(name), "Left Chrome Strip");
        case 1108: format(name, sizeof(name), "Right Chrome Strip");
        case 1109: format(name, sizeof(name), "Chrome Rear Bullbars");
        case 1110: format(name, sizeof(name), "Slamin Rear Bullbars");
        case 1111: format(name, sizeof(name), "Front Sign");
        case 1112: format(name, sizeof(name), "Front Sign");
        case 1113: format(name, sizeof(name), "Chrome Exhaust");
        case 1114: format(name, sizeof(name), "Slamin Exhaust");
        case 1115: format(name, sizeof(name), "Chrome Front Bullbars");
        case 1116: format(name, sizeof(name), "Slamin Front Bullbars");
        case 1117: format(name, sizeof(name), "Chrome Front Bumper");
        case 1118: format(name, sizeof(name), "Right Chrome Trim");
        case 1119: format(name, sizeof(name), "Right Wheelcovers");
        case 1120: format(name, sizeof(name), "Left Chrome Trim");
        case 1121: format(name, sizeof(name), "Left Wheelcovers");
        case 1122: format(name, sizeof(name), "Right Chrome Flames");
        case 1123: format(name, sizeof(name), "Bullbar Chrome Bars");
        case 1124: format(name, sizeof(name), "Left Chrome Arches");
        case 1125: format(name, sizeof(name), "Bullbar Chrome Lights");
        case 1126: format(name, sizeof(name), "Chrome Exhaust");
        case 1127: format(name, sizeof(name), "Slamin Exhaust");
        case 1128: format(name, sizeof(name), "Vinyl Hardtop");
        case 1129: format(name, sizeof(name), "Chrome Exhaust");
        case 1130: format(name, sizeof(name), "Hardtop Roof");
        case 1131: format(name, sizeof(name), "Softtop Roof");
        case 1132: format(name, sizeof(name), "Slamin Exhaust");
        case 1133: format(name, sizeof(name), "Right Chrome Strip");
        case 1134: format(name, sizeof(name), "Right Chrome Strip");
        case 1135: format(name, sizeof(name), "Slamin Exhaust");
        case 1136: format(name, sizeof(name), "Chrome Exhaust");
        case 1137: format(name, sizeof(name), "Left Chrome Strip");
        case 1138: format(name, sizeof(name), "Alien Spoiler");
        case 1139: format(name, sizeof(name), "X-Flow Spoiler");
        case 1140: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1141: format(name, sizeof(name), "Alien Rear Bumper");
        case 1142: format(name, sizeof(name), "Left Oval Vents");
        case 1143: format(name, sizeof(name), "Right Oval Vents");
        case 1144: format(name, sizeof(name), "Left Square Vents");
        case 1145: format(name, sizeof(name), "Right Square Vents");
        case 1146: format(name, sizeof(name), "X-Flow Spoiler");
        case 1147: format(name, sizeof(name), "Alien Spoiler");
        case 1148: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1149: format(name, sizeof(name), "Alien Rear Bumper");
        case 1150: format(name, sizeof(name), "Alien Rear Bumper");
        case 1151: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1152: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1153: format(name, sizeof(name), "Alien Front Bumper");
        case 1154: format(name, sizeof(name), "Alien Rear Bumper");
        case 1155: format(name, sizeof(name), "Alien Front Bumper");
        case 1156: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1157: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1158: format(name, sizeof(name), "X-Flow Spoiler");
        case 1159: format(name, sizeof(name), "Alien Rear Bumper");
        case 1160: format(name, sizeof(name), "Alien Front Bumper");
        case 1161: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1162: format(name, sizeof(name), "Alien Spoiler");
        case 1163: format(name, sizeof(name), "X-Flow Spoiler");
        case 1164: format(name, sizeof(name), "Alien Spoiler");
        case 1165: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1166: format(name, sizeof(name), "Alien Front Bumper");
        case 1167: format(name, sizeof(name), "X-Flow Rear Bumper");
        case 1168: format(name, sizeof(name), "Alien Rear Bumper");
        case 1169: format(name, sizeof(name), "Alien Front Bumper");
        case 1170: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1171: format(name, sizeof(name), "Alien Front Bumper");
        case 1172: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1173: format(name, sizeof(name), "X-Flow Front Bumper");
        case 1174: format(name, sizeof(name), "Chrome Front Bumper");
        case 1175: format(name, sizeof(name), "Slamin Front Bumper");
        case 1176: format(name, sizeof(name), "Chrome Rear Bumper");
        case 1177: format(name, sizeof(name), "Slamin Rear Bumper");
        case 1178: format(name, sizeof(name), "Slamin Rear Bumper");
        case 1179: format(name, sizeof(name), "Chrome Front Bumper");
        case 1180: format(name, sizeof(name), "Chrome Rear Bumper");
        case 1181: format(name, sizeof(name), "Slamin Front Bumper");
        case 1182: format(name, sizeof(name), "Chrome Front Bumper");
        case 1183: format(name, sizeof(name), "Slamin Rear Bumper");
        case 1184: format(name, sizeof(name), "Chrome Rear Bumper");
        case 1185: format(name, sizeof(name), "Slamin Front Bumper");
        case 1186: format(name, sizeof(name), "Slamin Rear Bumper");
        case 1187: format(name, sizeof(name), "Chrome Rear Bumper");
        case 1188: format(name, sizeof(name), "Slamin Front Bumper");
        case 1189: format(name, sizeof(name), "Chrome Front Bumper");
        case 1190: format(name, sizeof(name), "Slamin Front Bumper");
        case 1191: format(name, sizeof(name), "Chrome Front Bumper");
        case 1192: format(name, sizeof(name), "Chrome Rear Bumper");
        case 1193: format(name, sizeof(name), "Slamin Rear Bumper");
        default:
        {
            if(component > 0) format(name, sizeof(name), "Component %d", component);
            else format(name, sizeof(name), "None");
        }
    }
    return name;
}

stock ER_ShowVehicleComponentList(playerid, slot)
{
    new list[2048];
    format(list, sizeof(list), "None\t0\n");

    switch(slot)
    {
        case 0: // spoiler
        {
            format(list, sizeof(list), "%sPro Spoiler\t1000\nWin Spoiler\t1001\nDrag Spoiler\t1002\nAlpha Spoiler\t1003\nFury Spoiler\t1023\nAlien Spoiler\t1138\nX-Flow Spoiler\t1139\nX-Flow Spoiler\t1146\nAlien Spoiler\t1147\nX-Flow Spoiler\t1158\nAlien Spoiler\t1162\nX-Flow Spoiler\t1163\nAlien Spoiler\t1164\n", list);
        }
        case 1: // hood
        {
            format(list, sizeof(list), "%sChamp Scoop Hood\t1014\nFury Scoop Hood\t1015\nWorx Scoop Hood\t1016\nRace Scoop Hood\t1065\nWorx Scoop Hood\t1066\n", list);
        }
        case 2: // roof
        {
            format(list, sizeof(list), "%sAlien Roof Vent\t1088\nX-Flow Roof Vent\t1091\nConvertible Roof\t1103\nVinyl Hardtop\t1128\nHardtop Roof\t1130\nSofttop Roof\t1131\n", list);
        }
        case 3, 4: // skirts
        {
            format(list, sizeof(list), "%sRight Side Skirt\t1017\nLeft Side Skirt\t1026\nRight Alien Side Skirt\t1030\nLeft X-Flow Side Skirt\t1031\nLeft Alien Side Skirt\t1036\nRight X-Flow Side Skirt\t1039\nRight Alien Side Skirt\t1040\nLeft X-Flow Side Skirt\t1041\nRight X-Flow Side Skirt\t1051\nLeft Alien Side Skirt\t1052\nLeft Alien Side Skirt\t1069\nRight Alien Side Skirt\t1070\nLeft X-Flow Side Skirt\t1071\nRight X-Flow Side Skirt\t1072\nLeft Chrome Side Skirt\t1099\nRight Chrome Strip\t1101\nLeft Chrome Strip\t1102\n", list);
        }
        case 5: // lamps
        {
            format(list, sizeof(list), "%sSquare Fog Lamps\t1024\nRound Fog Lamps\t1027\n", list);
        }
        case 6: // nitro
        {
            format(list, sizeof(list), "%sNOS 2x\t1009\nNOS 5x\t1008\nNOS 10x\t1010\nUnlimited NOS\t1010\n", list);
        }
        case 7: // exhaust
        {
            format(list, sizeof(list), "%sUpswept Exhaust\t1018\nTwin Exhaust\t1019\nLarge Exhaust\t1020\nMedium Exhaust\t1021\nSmall Exhaust\t1022\nAlien Exhaust\t1034\nX-Flow Exhaust\t1037\nAlien Exhaust\t1044\nX-Flow Exhaust\t1046\nChrome Exhaust\t1104\nSlamin Exhaust\t1105\nChrome Exhaust\t1113\nSlamin Exhaust\t1114\nChrome Exhaust\t1126\nSlamin Exhaust\t1127\nChrome Exhaust\t1129\nSlamin Exhaust\t1132\nSlamin Exhaust\t1135\nChrome Exhaust\t1136\n", list);
        }
        case 8: // wheels
        {
            format(list, sizeof(list), "%sOffroad Wheels\t1025\nShadow Rims\t1073\nMega Rims\t1074\nRimshine Rims\t1075\nWires Rims\t1076\nClassic Rims\t1077\nTwist Rims\t1078\nCutter Rims\t1079\nSwitch Rims\t1080\nGrove Rims\t1081\nImport Rims\t1082\nDollar Rims\t1083\nTrance Rims\t1084\nAtomic Rims\t1085\nAhab Rims\t1096\nVirtual Rims\t1097\nAccess Rims\t1098\n", list);
        }
        case 9: format(list, sizeof(list), "%sStereo\t1086\n", list);
        case 10: format(list, sizeof(list), "%sHydraulics\t1087\n", list);
        case 11: // front bumper
        {
            format(list, sizeof(list), "%sAlien Front Bumper\t1115\nX-Flow Front Bumper\t1116\nChrome Front Bumper\t1117\nSlamin Front Bumper\t1152\nAlien Front Bumper\t1153\nAlien Front Bumper\t1155\nX-Flow Front Bumper\t1157\nAlien Front Bumper\t1160\nX-Flow Front Bumper\t1165\nAlien Front Bumper\t1166\nAlien Front Bumper\t1169\nX-Flow Front Bumper\t1170\nAlien Front Bumper\t1171\nX-Flow Front Bumper\t1172\nX-Flow Front Bumper\t1173\nChrome Front Bumper\t1174\nSlamin Front Bumper\t1175\nChrome Front Bumper\t1179\nSlamin Front Bumper\t1181\nChrome Front Bumper\t1182\nSlamin Front Bumper\t1185\nSlamin Front Bumper\t1188\nChrome Front Bumper\t1189\nSlamin Front Bumper\t1190\nChrome Front Bumper\t1191\n", list);
        }
        case 12: // rear bumper
        {
            format(list, sizeof(list), "%sChrome Rear Bumper\t1109\nSlamin Rear Bumper\t1110\nX-Flow Rear Bumper\t1140\nAlien Rear Bumper\t1141\nX-Flow Rear Bumper\t1148\nAlien Rear Bumper\t1149\nAlien Rear Bumper\t1150\nX-Flow Rear Bumper\t1151\nAlien Rear Bumper\t1154\nX-Flow Rear Bumper\t1156\nAlien Rear Bumper\t1159\nX-Flow Rear Bumper\t1161\nX-Flow Rear Bumper\t1167\nAlien Rear Bumper\t1168\nChrome Rear Bumper\t1176\nSlamin Rear Bumper\t1177\nSlamin Rear Bumper\t1178\nChrome Rear Bumper\t1180\nSlamin Rear Bumper\t1183\nChrome Rear Bumper\t1184\nSlamin Rear Bumper\t1186\nChrome Rear Bumper\t1187\nChrome Rear Bumper\t1192\nSlamin Rear Bumper\t1193\n", list);
        }
        case 13, 14:
        {
            format(list, sizeof(list), "%sLeft Oval Vents\t1142\nRight Oval Vents\t1143\nLeft Square Vents\t1144\nRight Square Vents\t1145\n", list);
        }
    }

    return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_MOD_SELECT, DIALOG_STYLE_TABLIST, "Select Vehicle Component", list, "Select", "Back");
}

stock ER_SetVehicleSpawnID(idx, vehicleid)
{
    if(idx < 0 || idx >= MAX_DYNAMIC_VEHICLES) return 0;
    VehicleInfo[idx][vSpawnedID] = vehicleid;
    return 1;
}

forward ER_DelayedRespawnSavedVehicle(idx);
public ER_DelayedRespawnSavedVehicle(idx)
{
    if(idx < 0 || idx >= VehicleCount) return 0;
    if(VehicleInfo[idx][vSpawnedID] != INVALID_VEHICLE_ID && VehicleInfo[idx][vSpawnedID] != 0)
    {
        DestroyVehicle(VehicleInfo[idx][vSpawnedID]);
    }

    new veh = CreateVehicle(
        VehicleInfo[idx][vModel],
        VehicleInfo[idx][vX],
        VehicleInfo[idx][vY],
        VehicleInfo[idx][vZ],
        VehicleInfo[idx][vA],
        VehicleInfo[idx][vColor1],
        VehicleInfo[idx][vColor2],
        -1
    );
    ER_SetVehicleSpawnID(idx, veh);
    SetVehicleVirtualWorld(veh, VehicleInfo[idx][vVW]);
    LinkVehicleToInterior(veh, VehicleInfo[idx][vInt]);
    ER_ApplyVehicleMods(idx);
    return 1;
}

stock ER_ApplyVehicleMods(idx)
{
    if(idx < 0 || idx >= VehicleCount) return 0;
    new veh = VehicleInfo[idx][vSpawnedID];
    if(veh == INVALID_VEHICLE_ID || veh == 0) return 0;

    ChangeVehicleColor(veh, VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2]);

    if(VehicleInfo[idx][vPaintjob] >= 0 && ER_CanVehicleUsePaintjob(VehicleInfo[idx][vModel]))
    {
        ChangeVehiclePaintjob(veh, VehicleInfo[idx][vPaintjob]);
    }

    if(VehicleInfo[idx][vNos] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vNos]);
    if(VehicleInfo[idx][vModSpoiler] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModSpoiler]);
    if(VehicleInfo[idx][vModHood] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModHood]);
    if(VehicleInfo[idx][vModRoof] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModRoof]);
    if(VehicleInfo[idx][vModSideskirtL] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModSideskirtL]);
    if(VehicleInfo[idx][vModSideskirtR] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModSideskirtR]);
    if(VehicleInfo[idx][vModLamps] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModLamps]);
    if(VehicleInfo[idx][vModNitro] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModNitro]);
    if(VehicleInfo[idx][vModExhaust] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModExhaust]);
    if(VehicleInfo[idx][vModWheels] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModWheels]);
    if(VehicleInfo[idx][vModStereo] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModStereo]);
    if(VehicleInfo[idx][vModHydraulics] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModHydraulics]);
    if(VehicleInfo[idx][vModFrontBumper] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModFrontBumper]);
    if(VehicleInfo[idx][vModRearBumper] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModRearBumper]);
    if(VehicleInfo[idx][vModVentRight] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModVentRight]);
    if(VehicleInfo[idx][vModVentLeft] > 0) AddVehicleComponent(veh, VehicleInfo[idx][vModVentLeft]);
    return 1;
}

stock ER_RespawnSavedVehicle(idx, putplayerid = INVALID_PLAYER_ID)
{
    if(idx < 0 || idx >= VehicleCount) return 0;

    if(VehicleInfo[idx][vSpawnedID] != INVALID_VEHICLE_ID && VehicleInfo[idx][vSpawnedID] != 0)
    {
        DestroyVehicle(VehicleInfo[idx][vSpawnedID]);
    }

    VehicleInfo[idx][vSpawnedID] = CreateVehicle(
        VehicleInfo[idx][vModel],
        VehicleInfo[idx][vX],
        VehicleInfo[idx][vY],
        VehicleInfo[idx][vZ],
        VehicleInfo[idx][vA],
        VehicleInfo[idx][vColor1],
        VehicleInfo[idx][vColor2],
        -1
    );

    SetVehicleVirtualWorld(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vVW]);
    LinkVehicleToInterior(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vInt]);
    ER_ApplyVehicleMods(idx);

    if(putplayerid != INVALID_PLAYER_ID && IsPlayerConnected(putplayerid))
    {
        PutPlayerInVehicle(putplayerid, VehicleInfo[idx][vSpawnedID], 0);
    }
    return 1;
}

stock ER_SaveVehicleTuning(idx)
{
    if(idx < 0 || idx >= VehicleCount) return 0;
    new veh = VehicleInfo[idx][vSpawnedID];
    if(veh == INVALID_VEHICLE_ID || veh == 0) return 0;

    VehicleInfo[idx][vNos] = GetVehicleComponentInSlot(veh, CARMODTYPE_NITRO);
    VehicleInfo[idx][vModNitro] = VehicleInfo[idx][vNos];
    VehicleInfo[idx][vModSpoiler] = GetVehicleComponentInSlot(veh, CARMODTYPE_SPOILER);
    VehicleInfo[idx][vModHood] = GetVehicleComponentInSlot(veh, CARMODTYPE_HOOD);
    VehicleInfo[idx][vModRoof] = GetVehicleComponentInSlot(veh, CARMODTYPE_ROOF);
    VehicleInfo[idx][vModSideskirtL] = GetVehicleComponentInSlot(veh, CARMODTYPE_SIDESKIRT);
    VehicleInfo[idx][vModSideskirtR] = 0;
    VehicleInfo[idx][vModLamps] = GetVehicleComponentInSlot(veh, CARMODTYPE_LAMPS);
    VehicleInfo[idx][vModExhaust] = GetVehicleComponentInSlot(veh, CARMODTYPE_EXHAUST);
    VehicleInfo[idx][vModWheels] = GetVehicleComponentInSlot(veh, CARMODTYPE_WHEELS);
    VehicleInfo[idx][vModStereo] = GetVehicleComponentInSlot(veh, CARMODTYPE_STEREO);
    VehicleInfo[idx][vModHydraulics] = GetVehicleComponentInSlot(veh, CARMODTYPE_HYDRAULICS);
    VehicleInfo[idx][vModFrontBumper] = GetVehicleComponentInSlot(veh, CARMODTYPE_FRONT_BUMPER);
    VehicleInfo[idx][vModRearBumper] = GetVehicleComponentInSlot(veh, CARMODTYPE_REAR_BUMPER);
    VehicleInfo[idx][vModVentRight] = GetVehicleComponentInSlot(veh, CARMODTYPE_VENT_RIGHT);
    VehicleInfo[idx][vModVentLeft] = GetVehicleComponentInSlot(veh, CARMODTYPE_VENT_LEFT);

    new q[900];
    mysql_format(MainPipeline, q, sizeof(q),
        "UPDATE `vehicles` SET `nos`=%d,`mod_spoiler`=%d,`mod_hood`=%d,`mod_roof`=%d,`mod_sideskirt_l`=%d,`mod_sideskirt_r`=%d,`mod_lamps`=%d,`mod_nitro`=%d,`mod_exhaust`=%d,`mod_wheels`=%d,`mod_stereo`=%d,`mod_hydraulics`=%d,`mod_front_bumper`=%d,`mod_rear_bumper`=%d,`mod_vent_right`=%d,`mod_vent_left`=%d WHERE `id`=%d",
        VehicleInfo[idx][vNos], VehicleInfo[idx][vModSpoiler], VehicleInfo[idx][vModHood], VehicleInfo[idx][vModRoof],
        VehicleInfo[idx][vModSideskirtL], VehicleInfo[idx][vModSideskirtR], VehicleInfo[idx][vModLamps], VehicleInfo[idx][vModNitro],
        VehicleInfo[idx][vModExhaust], VehicleInfo[idx][vModWheels], VehicleInfo[idx][vModStereo], VehicleInfo[idx][vModHydraulics],
        VehicleInfo[idx][vModFrontBumper], VehicleInfo[idx][vModRearBumper], VehicleInfo[idx][vModVentRight], VehicleInfo[idx][vModVentLeft],
        VehicleInfo[idx][vSQLID]
    );
    mysql_tquery(MainPipeline, q);
    return 1;
}

stock ER_GetBestVehicleEditPositionEx(playerid, sqlid, &Float:x, &Float:y, &Float:z, &Float:a, &interior, &vw)
{
    new playerveh = GetPlayerVehicleID(playerid);
    if(playerveh != 0)
    {
        GetVehiclePos(playerveh, x, y, z);
        GetVehicleZAngle(playerveh, a);
        interior = GetPlayerInterior(playerid);
        vw = GetPlayerVirtualWorld(playerid);
        return 1;
    }

    new idx = ER_FindVehicleBySQLID(sqlid);
    if(idx != -1 && VehicleInfo[idx][vSpawnedID] != INVALID_VEHICLE_ID && VehicleInfo[idx][vSpawnedID] != 0)
    {
        GetVehiclePos(VehicleInfo[idx][vSpawnedID], x, y, z);
        GetVehicleZAngle(VehicleInfo[idx][vSpawnedID], a);
        interior = VehicleInfo[idx][vInt];
        vw = VehicleInfo[idx][vVW];
        return 1;
    }

    GetPlayerPos(playerid, x, y, z);
    GetPlayerFacingAngle(playerid, a);
    interior = GetPlayerInterior(playerid);
    vw = GetPlayerVirtualWorld(playerid);
    return 1;
}

stock ER_FindVehicleBySpawnID(vehicleid)
{
	for(new i; i < VehicleCount; i++)
	{
		if(VehicleInfo[i][vSpawnedID] == vehicleid) return i;
	}
	return -1;
}

stock ER_FindVehicleBySQLID(sqlid)
{
	for(new i; i < VehicleCount; i++)
	{
		if(VehicleInfo[i][vSQLID] == sqlid) return i;
	}
	return -1;
}

stock ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername[], dest[], size = sizeof(dest))
{
	if(ownerpid > 0) format(dest, size, "Player Owned (%d) %s", ownerpid, ownername[0] ? ownername : "Unknown");
	else if(familyid > 0) format(dest, size, "Family Owned (%d)", familyid);
	else if(factionid > 0) format(dest, size, "Faction Owned (%d)", factionid);
	else format(dest, size, "None");
	return 1;
}

stock ER_LoadVehicles()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `vehicles` WHERE `enabled`=1", "ER_OnVehiclesLoad");
    return 1;
}

forward ER_ReloadVehicles();
public ER_ReloadVehicles()
{
    ER_LoadVehicles();
    return 1;
}

forward ER_OnVehiclesLoad();
public ER_OnVehiclesLoad()
{
    new rows; cache_get_row_count(rows);

    for(new i; i < VehicleCount; i++)
    {
        if(VehicleInfo[i][vSpawnedID] != INVALID_VEHICLE_ID)
        {
            DestroyVehicle(VehicleInfo[i][vSpawnedID]);
        }
    }

    VehicleCount = 0;
    for(new r; r < rows && VehicleCount < MAX_DYNAMIC_VEHICLES; r++)
    {
        cache_get_value_name_int(r, "id", VehicleInfo[VehicleCount][vSQLID]);
        cache_get_value_name_int(r, "owner_pid", VehicleInfo[VehicleCount][vOwnerPID]);
        cache_get_value_name_int(r, "family_id", VehicleInfo[VehicleCount][vFamilyID]);
        cache_get_value_name_int(r, "faction_id", VehicleInfo[VehicleCount][vFactionID]);
        cache_get_value_name_int(r, "model", VehicleInfo[VehicleCount][vModel]);
        cache_get_value_name_int(r, "color1", VehicleInfo[VehicleCount][vColor1]);
        cache_get_value_name_int(r, "color2", VehicleInfo[VehicleCount][vColor2]);
        cache_get_value_name_int(r, "paintjob", VehicleInfo[VehicleCount][vPaintjob]);
        cache_get_value_name_float(r, "x", VehicleInfo[VehicleCount][vX]);
        cache_get_value_name_float(r, "y", VehicleInfo[VehicleCount][vY]);
        cache_get_value_name_float(r, "z", VehicleInfo[VehicleCount][vZ]);
        cache_get_value_name_float(r, "a", VehicleInfo[VehicleCount][vA]);
        cache_get_value_name_int(r, "interior", VehicleInfo[VehicleCount][vInt]);
        cache_get_value_name_int(r, "vw", VehicleInfo[VehicleCount][vVW]);
        cache_get_value_name_int(r, "lock_type", VehicleInfo[VehicleCount][vLockType]);
        cache_get_value_name_int(r, "nos", VehicleInfo[VehicleCount][vNos]);
        cache_get_value_name_int(r, "mod_spoiler", VehicleInfo[VehicleCount][vModSpoiler]);
        cache_get_value_name_int(r, "mod_hood", VehicleInfo[VehicleCount][vModHood]);
        cache_get_value_name_int(r, "mod_roof", VehicleInfo[VehicleCount][vModRoof]);
        cache_get_value_name_int(r, "mod_sideskirt_l", VehicleInfo[VehicleCount][vModSideskirtL]);
        cache_get_value_name_int(r, "mod_sideskirt_r", VehicleInfo[VehicleCount][vModSideskirtR]);
        cache_get_value_name_int(r, "mod_lamps", VehicleInfo[VehicleCount][vModLamps]);
        cache_get_value_name_int(r, "mod_nitro", VehicleInfo[VehicleCount][vModNitro]);
        cache_get_value_name_int(r, "mod_exhaust", VehicleInfo[VehicleCount][vModExhaust]);
        cache_get_value_name_int(r, "mod_wheels", VehicleInfo[VehicleCount][vModWheels]);
        cache_get_value_name_int(r, "mod_stereo", VehicleInfo[VehicleCount][vModStereo]);
        cache_get_value_name_int(r, "mod_hydraulics", VehicleInfo[VehicleCount][vModHydraulics]);
        cache_get_value_name_int(r, "mod_front_bumper", VehicleInfo[VehicleCount][vModFrontBumper]);
        cache_get_value_name_int(r, "mod_rear_bumper", VehicleInfo[VehicleCount][vModRearBumper]);
        cache_get_value_name_int(r, "mod_vent_right", VehicleInfo[VehicleCount][vModVentRight]);
        cache_get_value_name_int(r, "mod_vent_left", VehicleInfo[VehicleCount][vModVentLeft]);

        VehicleInfo[VehicleCount][vSpawnedID] = CreateVehicle(
            VehicleInfo[VehicleCount][vModel],
            VehicleInfo[VehicleCount][vX],
            VehicleInfo[VehicleCount][vY],
            VehicleInfo[VehicleCount][vZ],
            VehicleInfo[VehicleCount][vA],
            VehicleInfo[VehicleCount][vColor1],
            VehicleInfo[VehicleCount][vColor2],
            -1
        );
        SetVehicleVirtualWorld(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vVW]);
        LinkVehicleToInterior(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vInt]);
        ER_ApplyVehicleMods(VehicleCount);
        VehicleCount++;
    }
    printf("[Vehicles] Loaded %d vehicles.", VehicleCount);
    return 1;
}

CMD:aveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0;
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /aveh [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    new Float:x, Float:y, Float:z, Float:a;
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    x += (3.0 * floatsin(-a, degrees));
    y += (3.0 * floatcos(-a, degrees));
    new veh = CreateVehicle(model, x, y, z, a, c1, c2, -1);
    SetVehicleVirtualWorld(veh, GetPlayerVirtualWorld(playerid));
    LinkVehicleToInterior(veh, GetPlayerInterior(playerid));
    PutPlayerInVehicle(playerid, veh, 0);

    new msg[96];
    format(msg, sizeof(msg), "Spawned temporary %s (%d).", ER_GetVehicleModelName(model), model);
    return ER_Send(playerid, COLOR_GREEN, msg);
}

CMD:createveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0, q[512], Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createveh(icle) [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    x += (3.0 * floatsin(-a, degrees));
    y += (3.0 * floatcos(-a, degrees));
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`paintjob`,`x`,`y`,`z`,`a`,`interior`,`vw`,`lock_type`,`enabled`) VALUES (0,0,0,%d,%d,%d,-1,%f,%f,%f,%f,%d,%d,0,1)",
        model, c1, c2, x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    SetPVarInt(playerid, "CreateVehModel", model);
    SetPVarInt(playerid, "CreateVehColor1", c1);
    SetPVarInt(playerid, "CreateVehColor2", c2);
    SetPVarFloat(playerid, "CreateVehX", x);
    SetPVarFloat(playerid, "CreateVehY", y);
    SetPVarFloat(playerid, "CreateVehZ", z);
    SetPVarFloat(playerid, "CreateVehA", a);
    SetPVarInt(playerid, "CreateVehInt", GetPlayerInterior(playerid));
    SetPVarInt(playerid, "CreateVehVW", GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q, "ER_OnAdminVehicleCreated", "i", playerid);
    return 1;
}
alias:createveh("createvehicle")

forward ER_OnAdminVehicleCreated(playerid);
public ER_OnAdminVehicleCreated(playerid)
{
    new vid = cache_insert_id();

    if(VehicleCount < MAX_DYNAMIC_VEHICLES)
    {
        new idx = VehicleCount;
        VehicleInfo[idx][vSQLID] = vid;
        VehicleInfo[idx][vOwnerPID] = 0;
        VehicleInfo[idx][vFamilyID] = 0;
        VehicleInfo[idx][vFactionID] = 0;
        VehicleInfo[idx][vModel] = GetPVarInt(playerid, "CreateVehModel");
        VehicleInfo[idx][vColor1] = GetPVarInt(playerid, "CreateVehColor1");
        VehicleInfo[idx][vColor2] = GetPVarInt(playerid, "CreateVehColor2");
        VehicleInfo[idx][vPaintjob] = -1;
        VehicleInfo[idx][vX] = GetPVarFloat(playerid, "CreateVehX");
        VehicleInfo[idx][vY] = GetPVarFloat(playerid, "CreateVehY");
        VehicleInfo[idx][vZ] = GetPVarFloat(playerid, "CreateVehZ");
        VehicleInfo[idx][vA] = GetPVarFloat(playerid, "CreateVehA");
        VehicleInfo[idx][vInt] = GetPVarInt(playerid, "CreateVehInt");
        VehicleInfo[idx][vVW] = GetPVarInt(playerid, "CreateVehVW");
        VehicleInfo[idx][vLockType] = 0;

        VehicleInfo[idx][vSpawnedID] = CreateVehicle(VehicleInfo[idx][vModel], VehicleInfo[idx][vX], VehicleInfo[idx][vY], VehicleInfo[idx][vZ], VehicleInfo[idx][vA], VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2], -1);
        SetVehicleVirtualWorld(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vVW]);
        LinkVehicleToInterior(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vInt]);
        PutPlayerInVehicle(playerid, VehicleInfo[idx][vSpawnedID], 0);
        VehicleCount++;
    }

    new msg[128], model = GetPVarInt(playerid, "CreateVehModel");
    format(msg, sizeof(msg), "Saved vehicle created. SQL ID: %d | %s (%d).", vid, ER_GetVehicleModelName(model), model);
    ER_Send(playerid, COLOR_GREEN, msg);
    return 1;
}

CMD:createpveh(playerid, params[])
{
    new pid, modelstr[32], model, q[512], c1 = 0, c2 = 0, Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "ds[32]D(0)D(0)", pid, modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createpveh [pID] [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    x += (3.0 * floatsin(-a, degrees));
    y += (3.0 * floatcos(-a, degrees));
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`paintjob`,`x`,`y`,`z`,`a`,`interior`,`vw`,`enabled`) VALUES (%d,0,0,%d,%d,%d,-1,%f,%f,%f,%f,%d,%d,1)",
        pid, model, c1, c2, x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
    return ER_Send(playerid, COLOR_GREEN, "Player vehicle created.");
}

CMD:vehicles(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnMyVehiclesDialog", "i", playerid);
	return 1;
}

forward ER_OnMyVehiclesDialog(playerid);
public ER_OnMyVehiclesDialog(playerid)
{
	new rows, list[2048], model, locktype, spawnid, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		new sqlid;
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_MY_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "My Vehicles", list, "Close", "");
	return 1;
}

CMD:trackveh(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleList", "i", playerid);
	return 1;
}
alias:trackveh("trackvehicle")

forward ER_OnTrackVehicleList(playerid);
public ER_OnTrackVehicleList(playerid)
{
	new rows, list[2048], model, locktype, spawnid, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		new sqlid;
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_TRACK_VEHICLE, DIALOG_STYLE_TABLIST_HEADERS, "Track Vehicle", list, "Track", "Close");
	return 1;
}

CMD:allvehs(playerid, params[])
{
	if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
	mysql_tquery(MainPipeline, "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.enabled=1 ORDER BY v.id ASC LIMIT 150", "ER_OnAllVehiclesDialog", "i", playerid);
	return 1;
}
alias:allvehs("allvehicles")

CMD:editvehicles(playerid, params[])
{
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	mysql_tquery(MainPipeline, "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.enabled=1 ORDER BY v.id ASC LIMIT 150", "ER_OnEditVehiclesDialog", "i", playerid);
	return 1;
}

forward ER_OnAllVehiclesDialog(playerid);
public ER_OnAllVehiclesDialog(playerid)
{
	new rows, list[4096], sqlid, model, ownerpid, familyid, factionid, spawnid, Float:x, Float:y, Float:z, area[32], owner[96], ownername[24];
	cache_get_row_count(rows);
	format(list, sizeof(list), "ID\tVehID\tModel\tOwner\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "owner_pid", ownerpid);
		cache_get_value_name_int(r, "family_id", familyid);
		cache_get_value_name_int(r, "faction_id", factionid);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		cache_get_value_name(r, "owner_name", ownername, sizeof(ownername));

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), owner, area);
	}
	ShowPlayerDialog(playerid, DIALOG_ALL_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "All Vehicles", list, "Close", "");
	return 1;
}

forward ER_OnEditVehiclesDialog(playerid);
public ER_OnEditVehiclesDialog(playerid)
{
	new rows, list[4096], sqlid, model, ownerpid, familyid, factionid, spawnid, Float:x, Float:y, Float:z, area[32], owner[96], ownername[24];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "No vehicles found.");
	format(list, sizeof(list), "ID\tVehID\tModel\tOwner\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "owner_pid", ownerpid);
		cache_get_value_name_int(r, "family_id", familyid);
		cache_get_value_name_int(r, "faction_id", factionid);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		cache_get_value_name(r, "owner_name", ownername, sizeof(ownername));

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), owner, area);
	}
	ShowPlayerDialog(playerid, DIALOG_EDIT_VEHICLE_LIST, DIALOG_STYLE_TABLIST_HEADERS, "Edit Vehicles", list, "Edit", "Close");
	return 1;
}

CMD:editveh(playerid, params[])
{
	new vehid, sqlid;
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editveh(icle) [ingame vehicle id]");

	new idx = ER_FindVehicleBySpawnID(vehid);
	if(idx == -1) return ER_Send(playerid, COLOR_GREY, "That ingame vehicle ID is not a saved dynamic vehicle.");

	sqlid = VehicleInfo[idx][vSQLID];
	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	ER_ShowVehicleEditor(playerid, sqlid);
	return 1;
}
alias:editveh("editvehicle")

CMD:deleteveh(playerid, params[])
{
	new vehid, q[128], sqlid = 0;
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /deleteveh(icle) [ingame vehicle id]");

	new idx = ER_FindVehicleBySpawnID(vehid);
	if(idx != -1) sqlid = VehicleInfo[idx][vSQLID];
	else sqlid = vehid; // fallback, useful if admin typed SQL ID

	mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", sqlid);
	mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
	return ER_Send(playerid, COLOR_GREEN, "Vehicle disabled/deleted.");
}
alias:deleteveh("deletevehicle")

stock ER_ShowVehicleEditor(playerid, sqlid)
{
	new q[256];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.id=%d LIMIT 1", sqlid);
	mysql_tquery(MainPipeline, q, "ER_OnShowVehicleEditor", "i", playerid);
	return 1;
}

forward ER_OnShowVehicleEditor(playerid);
public ER_OnShowVehicleEditor(playerid)
{
	new rows;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	new sqlid, model, c1, c2, paintjob, nos, ownerpid, familyid, factionid, spawnid, ownername[24], owner[96], list[1280];
	cache_get_value_name_int(0, "id", sqlid);
	cache_get_value_name_int(0, "model", model);
	cache_get_value_name_int(0, "color1", c1);
	cache_get_value_name_int(0, "color2", c2);
	cache_get_value_name_int(0, "paintjob", paintjob);
	cache_get_value_name_int(0, "nos", nos);
	cache_get_value_name_int(0, "owner_pid", ownerpid);
	cache_get_value_name_int(0, "family_id", familyid);
	cache_get_value_name_int(0, "faction_id", factionid);
	cache_get_value_name(0, "owner_name", ownername, sizeof(ownername));

	spawnid = INVALID_VEHICLE_ID;
	new idx = ER_FindVehicleBySQLID(sqlid);
	if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

	ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));

	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	format(list, sizeof(list),
		"Owner: %s\nModel: %s (%d)\nColor 1: %d\nColor 2: %d\nPaintjob: %s\nNOS: %s\nMods\nPosition: Set here\nGoto Vehicle\nReset Vehicle\nReload This Vehicle\nDisable/Delete",
		owner, ER_GetVehicleModelName(model), model, c1, c2, ER_GetVehiclePaintjobName(paintjob), ER_GetVehicleNOSName(nos));
	new title[64];
	format(title, sizeof(title), "Vehicle Editor - ID %d | VehID %d", sqlid, spawnid);
	ShowPlayerDialog(playerid, DIALOG_EDIT_VEHICLE_MENU, DIALOG_STYLE_LIST, title, list, "Select", "Close");
	return 1;
}

stock ER_SetVehicleOwner(playerid, sqlid, type, value)
{
	new q[256];
	if(type == 1)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	else if(type == 2)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	else if(type == 3)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	return 1;
}

forward ER_OnCheckVehicleOwnerSet(playerid, sqlid);
public ER_OnCheckVehicleOwnerSet(playerid, sqlid)
{
	new rows, ownerpid, familyid, factionid, type, value, q[256], err[128];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	cache_get_value_name_int(0, "owner_pid", ownerpid);
	cache_get_value_name_int(0, "family_id", familyid);
	cache_get_value_name_int(0, "faction_id", factionid);

	type = GetPVarInt(playerid, "SetOwnerType");
	value = GetPVarInt(playerid, "SetOwnerValue");

	if(value > 0)
	{
		if(type != 1 && ownerpid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Player: %d.", ownerpid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
		if(type != 2 && familyid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Family: %d.", familyid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
		if(type != 3 && factionid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Faction: %d.", factionid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
	}

	switch(type)
	{
		case 1: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=%d,`family_id`=0,`faction_id`=0 WHERE `id`=%d", value, sqlid);
		case 2: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=%d,`faction_id`=0 WHERE `id`=%d", value, sqlid);
		case 3: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=0,`faction_id`=%d WHERE `id`=%d", value, sqlid);
		default: return ER_ShowVehicleEditor(playerid, sqlid);
	}
	mysql_tquery(MainPipeline, q);
	new idx = ER_FindVehicleBySQLID(sqlid);
	if(idx != -1)
	{
		switch(type)
		{
			case 1: { VehicleInfo[idx][vOwnerPID] = value; VehicleInfo[idx][vFamilyID] = 0; VehicleInfo[idx][vFactionID] = 0; }
			case 2: { VehicleInfo[idx][vOwnerPID] = 0; VehicleInfo[idx][vFamilyID] = value; VehicleInfo[idx][vFactionID] = 0; }
			case 3: { VehicleInfo[idx][vOwnerPID] = 0; VehicleInfo[idx][vFamilyID] = 0; VehicleInfo[idx][vFactionID] = value; }
		}
	}
	ER_Send(playerid, COLOR_GREEN, "Vehicle owner updated.");
	return ER_ShowVehicleEditor(playerid, sqlid);
}

stock ER_VehicleDialog(playerid, dialogid, response, listitem, inputtext[])
{
	if(dialogid == DIALOG_TRACK_VEHICLE)
	{
		if(!response) return 1;
		new q[160];
		mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC LIMIT %d,1", PlayerInfo[playerid][pID], listitem);
		mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleSelect", "i", playerid);
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEHICLE_LIST)
	{
		if(!response) return 1;
		new q[160];
		mysql_format(MainPipeline, q, sizeof(q), "SELECT `id` FROM `vehicles` WHERE `enabled`=1 ORDER BY `id` ASC LIMIT %d,1", listitem);
		mysql_tquery(MainPipeline, q, "ER_OnEditVehicleListSelect", "i", playerid);
		return 1;
	}

	if(dialogid == DIALOG_MY_VEHICLES || dialogid == DIALOG_ALL_VEHICLES)
	{
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEHICLE_MENU)
	{
		if(!response) return 1;
		new sqlid = GetPVarInt(playerid, "EditingVehicleID");
		if(sqlid <= 0) return 1;

		switch(listitem)
		{
			case 0: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER, DIALOG_STYLE_LIST, "Vehicle Owner", "Player\nFamily (SQL ID)\nFaction (SQL ID)\nClear Owner", "Select", "Back");
			case 1: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_MODEL, DIALOG_STYLE_INPUT, "Vehicle Model", "Enter model ID or vehicle name:", "Save", "Back");
			case 2: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_COLOR1, DIALOG_STYLE_INPUT, "Vehicle Color 1", "Enter color 1 number:", "Save", "Back");
			case 3: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_COLOR2, DIALOG_STYLE_INPUT, "Vehicle Color 2", "Enter color 2 number:", "Save", "Back");
			case 4: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_PAINTJOB, DIALOG_STYLE_LIST, "Vehicle Paintjob", "None\nPaintjob 1\nPaintjob 2\nPaintjob 3", "Select", "Back");
			case 5: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_NOS, DIALOG_STYLE_LIST, "Vehicle NOS", "Unlimited NOS\nNone\nNOS 2x\nNOS 5x\nNOS 10x", "Select", "Back");
			case 6: ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_MODS, DIALOG_STYLE_LIST, "Vehicle Mods", "Spoiler\nHood\nRoof\nSide Skirt L\nSide Skirt R\nLamps\nNitro\nExhaust\nWheels/Rims\nStereo\nHydraulics\nFront Bumper\nRear Bumper\nVent Right\nVent Left", "Select", "Back");
			case 7:
			{
				new Float:x, Float:y, Float:z, Float:a, interior, vw, q[256];
				ER_GetBestVehicleEditPositionEx(playerid, sqlid, x, y, z, a, interior, vw);

				new idx = ER_FindVehicleBySQLID(sqlid);
				if(idx != -1)
				{
					if(GetPlayerVehicleID(playerid) == VehicleInfo[idx][vSpawnedID]) ER_SaveVehicleTuning(idx);

					VehicleInfo[idx][vX] = x;
					VehicleInfo[idx][vY] = y;
					VehicleInfo[idx][vZ] = z;
					VehicleInfo[idx][vA] = a;
					VehicleInfo[idx][vInt] = interior;
					VehicleInfo[idx][vVW] = vw;

					mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `x`=%f,`y`=%f,`z`=%f,`a`=%f,`interior`=%d,`vw`=%d WHERE `id`=%d", x, y, z, a, interior, vw, sqlid);
					mysql_tquery(MainPipeline, q);

					ER_RespawnSavedVehicle(idx);
				}
				ER_Send(playerid, COLOR_GREEN, "Vehicle position has been saved and respawned at the exact location.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 8:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
				mysql_tquery(MainPipeline, q, "ER_OnGotoVehicleSQL", "i", playerid);
			}
			case 9:
			{
				new idx = ER_FindVehicleBySQLID(sqlid);
				if(idx != -1)
				{
					ER_SaveVehicleTuning(idx);
					ER_RespawnSavedVehicle(idx);
				}
				ER_Send(playerid, COLOR_GREEN, "Vehicle reloaded successfully.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 10:
			{
				new idx = ER_FindVehicleBySQLID(sqlid);
				if(idx != -1)
				{
					ER_RespawnSavedVehicle(idx);
				}
				ER_Send(playerid, COLOR_GREEN, "Vehicle has been reset to its saved position.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 11:
			{
				new idx = ER_FindVehicleBySQLID(sqlid);
				if(idx != -1)
				{
					ER_SaveVehicleTuning(idx);
					ER_RespawnSavedVehicle(idx);
				}
				ER_Send(playerid, COLOR_GREEN, "Vehicle reloaded successfully.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 12:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", sqlid);
				mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
				ER_Send(playerid, COLOR_GREEN, "Vehicle disabled/deleted.");
			}
		}
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		if(listitem == 0)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER_PLAYER_TYPE, DIALOG_STYLE_LIST, "Player Owner", "Online Player\nOffline Player SQL ID", "Select", "Back");
		}
		if(listitem == 1)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_FAMILY, DIALOG_STYLE_INPUT, "Family Owner", "Enter family SQL ID:", "Save", "Back");
		}
		if(listitem == 2)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_FACTION, DIALOG_STYLE_INPUT, "Faction Owner", "Enter faction SQL ID:", "Save", "Back");
		}

		new q[128], sqlid = GetPVarInt(playerid, "EditingVehicleID");
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=0,`faction_id`=0 WHERE `id`=%d", sqlid);
		mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
		ER_Send(playerid, COLOR_GREEN, "Vehicle owner cleared.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER_PLAYER_TYPE)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		if(listitem == 0)
		{
			new list[1024], count = 0, name[MAX_PLAYER_NAME];
			list[0] = EOS;
			foreach(new i : Player)
			{
				if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pID] > 0)
				{
					GetPlayerName(i, name, sizeof(name));
					new pvarname[24]; format(pvarname, sizeof(pvarname), "OwnerOnline%d", count); SetPVarInt(playerid, pvarname, i);
					format(list, sizeof(list), "%s%d\t%s\tSQL ID: %d\n", list, i, name, PlayerInfo[i][pID]);
					count++;
				}
			}
			if(!count) return ER_Send(playerid, COLOR_GREY, "No online players found.");
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER_ONLINE_PLAYER, DIALOG_STYLE_TABLIST, "Select Online Player", list, "Select", "Back");
		}
		return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_PLAYER, DIALOG_STYLE_INPUT, "Offline Player Owner", "Enter player SQL ID:", "Save", "Back");
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER_ONLINE_PLAYER)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		new pvarname[24]; format(pvarname, sizeof(pvarname), "OwnerOnline%d", listitem); new target = GetPVarInt(playerid, pvarname);
		if(!IsPlayerConnected(target) || PlayerInfo[target][pID] <= 0) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		return ER_SetVehicleOwner(playerid, GetPVarInt(playerid, "EditingVehicleID"), 1, PlayerInfo[target][pID]);
	}

	if(dialogid == DIALOG_EDIT_VEH_SET_PLAYER || dialogid == DIALOG_EDIT_VEH_SET_FAMILY || dialogid == DIALOG_EDIT_VEH_SET_FACTION)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		new value = strval(inputtext), sqlid = GetPVarInt(playerid, "EditingVehicleID");
		if(value < 0) value = 0;
		if(dialogid == DIALOG_EDIT_VEH_SET_PLAYER) return ER_SetVehicleOwner(playerid, sqlid, 1, value);
		if(dialogid == DIALOG_EDIT_VEH_SET_FAMILY) return ER_SetVehicleOwner(playerid, sqlid, 2, value);
		if(dialogid == DIALOG_EDIT_VEH_SET_FACTION) return ER_SetVehicleOwner(playerid, sqlid, 3, value);
	}

	if(dialogid == DIALOG_EDIT_VEH_MODEL || dialogid == DIALOG_EDIT_VEH_COLOR1 || dialogid == DIALOG_EDIT_VEH_COLOR2)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		new sqlid = GetPVarInt(playerid, "EditingVehicleID"), q[160], value;
		if(dialogid == DIALOG_EDIT_VEH_MODEL)
		{
			value = ER_FindVehicleModel(inputtext);
			if(value < 400 || value > 611)
			{
				ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");
				return ER_ShowVehicleEditor(playerid, sqlid);
			}
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `model`=%d WHERE `id`=%d", value, sqlid);
		}
		else if(dialogid == DIALOG_EDIT_VEH_COLOR1)
		{
			value = strval(inputtext);
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `color1`=%d WHERE `id`=%d", value, sqlid);
		}
		else
		{
			value = strval(inputtext);
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `color2`=%d WHERE `id`=%d", value, sqlid);
		}
		mysql_tquery(MainPipeline, q);

		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1)
		{
			if(dialogid == DIALOG_EDIT_VEH_MODEL)
			{
				VehicleInfo[idx][vModel] = value;
				ER_RespawnSavedVehicle(idx);
			}
			else if(dialogid == DIALOG_EDIT_VEH_COLOR1)
			{
				VehicleInfo[idx][vColor1] = value;
				ChangeVehicleColor(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2]);
				ER_ApplyVehicleMods(idx);
			}
			else
			{
				VehicleInfo[idx][vColor2] = value;
				ChangeVehicleColor(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2]);
				ER_ApplyVehicleMods(idx);
			}
		}

		ER_Send(playerid, COLOR_GREEN, "Vehicle updated.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	if(dialogid == DIALOG_EDIT_VEH_PAINTJOB)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		new sqlid = GetPVarInt(playerid, "EditingVehicleID");
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx == -1) return ER_ShowVehicleEditor(playerid, sqlid);

		if(!ER_CanVehicleUsePaintjob(VehicleInfo[idx][vModel]) && listitem > 0)
		{
			ER_Send(playerid, COLOR_GREY, "This vehicle model does not support paintjobs.");
			return ER_ShowVehicleEditor(playerid, sqlid);
		}

		new paintjob = -1;
		switch(listitem)
		{
			case 0: paintjob = -1;
			case 1: paintjob = 0;
			case 2: paintjob = 1;
			case 3: paintjob = 2;
		}

		VehicleInfo[idx][vPaintjob] = paintjob;

		new q[128];
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `paintjob`=%d WHERE `id`=%d", paintjob, sqlid);
		mysql_tquery(MainPipeline, q);

		if(paintjob >= 0) ChangeVehiclePaintjob(VehicleInfo[idx][vSpawnedID], paintjob);
		ChangeVehicleColor(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2]);
		ER_ApplyVehicleMods(idx);

		ER_Send(playerid, COLOR_GREEN, "Vehicle paintjob updated.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	if(dialogid == DIALOG_EDIT_VEH_NOS)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		new sqlid = GetPVarInt(playerid, "EditingVehicleID");
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx == -1) return ER_ShowVehicleEditor(playerid, sqlid);

		new nos = 0;
		switch(listitem)
		{
			case 0: nos = 1010; // Unlimited NOS placeholder, applied as 10x nitro
			case 1: nos = 0;
			case 2: nos = 1009;
			case 3: nos = 1008;
			case 4: nos = 1010;
		}

		VehicleInfo[idx][vNos] = nos;
		VehicleInfo[idx][vModNitro] = nos;

		new q[160];
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `nos`=%d,`mod_nitro`=%d WHERE `id`=%d", nos, nos, sqlid);
		mysql_tquery(MainPipeline, q);

		if(nos > 0) AddVehicleComponent(VehicleInfo[idx][vSpawnedID], nos);
		ER_Send(playerid, COLOR_GREEN, "Vehicle NOS updated.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	if(dialogid == DIALOG_EDIT_VEH_MODS)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		SetPVarInt(playerid, "EditingVehicleModSlot", listitem);
		return ER_ShowVehicleComponentList(playerid, listitem);
	}

	if(dialogid == DIALOG_EDIT_VEH_MOD_SELECT)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		new sqlid = GetPVarInt(playerid, "EditingVehicleID");
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx == -1) return ER_ShowVehicleEditor(playerid, sqlid);

		new component = 0;
		switch(GetPVarInt(playerid, "EditingVehicleModSlot"))
		{
			case 0:
			{
				switch(listitem) { case 0: component=0; case 1: component=1000; case 2: component=1001; case 3: component=1002; case 4: component=1003; case 5: component=1023; case 6: component=1138; case 7: component=1139; case 8: component=1146; case 9: component=1147; case 10: component=1158; case 11: component=1162; case 12: component=1163; case 13: component=1164; }
				VehicleInfo[idx][vModSpoiler] = component;
			}
			case 1:
			{
				switch(listitem) { case 0: component=0; case 1: component=1014; case 2: component=1015; case 3: component=1016; case 4: component=1065; case 5: component=1066; }
				VehicleInfo[idx][vModHood] = component;
			}
			case 2:
			{
				switch(listitem) { case 0: component=0; case 1: component=1088; case 2: component=1091; case 3: component=1103; case 4: component=1128; case 5: component=1130; case 6: component=1131; }
				VehicleInfo[idx][vModRoof] = component;
			}
			case 3, 4:
			{
				switch(listitem) { case 0: component=0; case 1: component=1017; case 2: component=1026; case 3: component=1030; case 4: component=1031; case 5: component=1036; case 6: component=1039; case 7: component=1040; case 8: component=1041; case 9: component=1051; case 10: component=1052; case 11: component=1069; case 12: component=1070; case 13: component=1071; case 14: component=1072; case 15: component=1099; case 16: component=1101; case 17: component=1102; }
				if(GetPVarInt(playerid, "EditingVehicleModSlot") == 3) VehicleInfo[idx][vModSideskirtL] = component;
				else VehicleInfo[idx][vModSideskirtR] = component;
			}
			case 5:
			{
				switch(listitem) { case 0: component=0; case 1: component=1024; case 2: component=1027; }
				VehicleInfo[idx][vModLamps] = component;
			}
			case 6:
			{
				switch(listitem) { case 0: component=0; case 1: component=1009; case 2: component=1008; case 3: component=1010; case 4: component=1010; }
				VehicleInfo[idx][vModNitro] = component;
				VehicleInfo[idx][vNos] = component;
			}
			case 7:
			{
				switch(listitem) { case 0: component=0; case 1: component=1018; case 2: component=1019; case 3: component=1020; case 4: component=1021; case 5: component=1022; case 6: component=1034; case 7: component=1037; case 8: component=1044; case 9: component=1046; case 10: component=1104; case 11: component=1105; case 12: component=1113; case 13: component=1114; case 14: component=1126; case 15: component=1127; case 16: component=1129; case 17: component=1132; case 18: component=1135; case 19: component=1136; }
				VehicleInfo[idx][vModExhaust] = component;
			}
			case 8:
			{
				switch(listitem) { case 0: component=0; case 1: component=1025; case 2: component=1073; case 3: component=1074; case 4: component=1075; case 5: component=1076; case 6: component=1077; case 7: component=1078; case 8: component=1079; case 9: component=1080; case 10: component=1081; case 11: component=1082; case 12: component=1083; case 13: component=1084; case 14: component=1085; case 15: component=1096; case 16: component=1097; case 17: component=1098; }
				VehicleInfo[idx][vModWheels] = component;
			}
			case 9: { if(listitem == 1) component=1086; VehicleInfo[idx][vModStereo] = component; }
			case 10: { if(listitem == 1) component=1087; VehicleInfo[idx][vModHydraulics] = component; }
			case 11:
			{
				switch(listitem) { case 0: component=0; case 1: component=1115; case 2: component=1116; case 3: component=1117; case 4: component=1152; case 5: component=1153; case 6: component=1155; case 7: component=1157; case 8: component=1160; case 9: component=1165; case 10: component=1166; case 11: component=1169; case 12: component=1170; case 13: component=1171; case 14: component=1172; case 15: component=1173; case 16: component=1174; case 17: component=1175; case 18: component=1179; case 19: component=1181; case 20: component=1182; case 21: component=1185; case 22: component=1188; case 23: component=1189; case 24: component=1190; case 25: component=1191; }
				VehicleInfo[idx][vModFrontBumper] = component;
			}
			case 12:
			{
				switch(listitem) { case 0: component=0; case 1: component=1109; case 2: component=1110; case 3: component=1140; case 4: component=1141; case 5: component=1148; case 6: component=1149; case 7: component=1150; case 8: component=1151; case 9: component=1154; case 10: component=1156; case 11: component=1159; case 12: component=1161; case 13: component=1167; case 14: component=1168; case 15: component=1176; case 16: component=1177; case 17: component=1178; case 18: component=1180; case 19: component=1183; case 20: component=1184; case 21: component=1186; case 22: component=1187; case 23: component=1192; case 24: component=1193; }
				VehicleInfo[idx][vModRearBumper] = component;
			}
			case 13, 14:
			{
				switch(listitem) { case 0: component=0; case 1: component=1142; case 2: component=1143; case 3: component=1144; case 4: component=1145; }
				if(GetPVarInt(playerid, "EditingVehicleModSlot") == 13) VehicleInfo[idx][vModVentRight] = component;
				else VehicleInfo[idx][vModVentLeft] = component;
			}
		}

		new q[900];
		mysql_format(MainPipeline, q, sizeof(q),
			"UPDATE `vehicles` SET `nos`=%d,`mod_spoiler`=%d,`mod_hood`=%d,`mod_roof`=%d,`mod_sideskirt_l`=%d,`mod_sideskirt_r`=%d,`mod_lamps`=%d,`mod_nitro`=%d,`mod_exhaust`=%d,`mod_wheels`=%d,`mod_stereo`=%d,`mod_hydraulics`=%d,`mod_front_bumper`=%d,`mod_rear_bumper`=%d,`mod_vent_right`=%d,`mod_vent_left`=%d WHERE `id`=%d",
			VehicleInfo[idx][vNos], VehicleInfo[idx][vModSpoiler], VehicleInfo[idx][vModHood], VehicleInfo[idx][vModRoof],
			VehicleInfo[idx][vModSideskirtL], VehicleInfo[idx][vModSideskirtR], VehicleInfo[idx][vModLamps], VehicleInfo[idx][vModNitro],
			VehicleInfo[idx][vModExhaust], VehicleInfo[idx][vModWheels], VehicleInfo[idx][vModStereo], VehicleInfo[idx][vModHydraulics],
			VehicleInfo[idx][vModFrontBumper], VehicleInfo[idx][vModRearBumper], VehicleInfo[idx][vModVentRight], VehicleInfo[idx][vModVentLeft],
			sqlid
		);
		mysql_tquery(MainPipeline, q);

		if(component > 0) AddVehicleComponent(VehicleInfo[idx][vSpawnedID], component);
		ER_Send(playerid, COLOR_GREEN, "Vehicle modification updated.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}



	return 0;
}

forward ER_OnEditVehicleListSelect(playerid);
public ER_OnEditVehicleListSelect(playerid)
{
	new rows, sqlid;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");
	cache_get_value_name_int(0, "id", sqlid);
	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	return ER_ShowVehicleEditor(playerid, sqlid);
}

forward ER_OnTrackVehicleSelect(playerid);
public ER_OnTrackVehicleSelect(playerid)
{
	new rows, Float:x, Float:y, Float:z, sqlid, model;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	cache_get_value_name_int(0, "id", sqlid);
	cache_get_value_name_int(0, "model", model);
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);

	if(VehicleTrackIcon[playerid] != -1) DestroyDynamicMapIcon(VehicleTrackIcon[playerid]);
	VehicleTrackIcon[playerid] = CreateDynamicMapIcon(x, y, z, 55, 0xFF0000FF, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid), playerid, 6000.0, MAPICON_GLOBAL);

	new msg[128];
	format(msg, sizeof(msg), "Tracking vehicle %d: %s. Red marker added to your map.", sqlid, ER_GetVehicleModelName(model));
	return ER_Send(playerid, COLOR_GREEN, msg);
}

forward ER_OnGotoVehicleSQL(playerid);
public ER_OnGotoVehicleSQL(playerid)
{
	new rows, Float:x, Float:y, Float:z, interior, vw;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);
	cache_get_value_name_int(0, "interior", interior);
	cache_get_value_name_int(0, "vw", vw);
	SetPlayerInterior(playerid, interior);
	SetPlayerVirtualWorld(playerid, vw);
	SetPlayerPos(playerid, x + 2.0, y, z);
	return 1;
}



stock ER_GetBestVehicleEditPosition(playerid, &Float:x, &Float:y, &Float:z, &Float:a)
{
    new vehicleid = GetPlayerVehicleID(playerid);

    if(vehicleid != 0)
    {
        GetVehiclePos(vehicleid, x, y, z);
        GetVehicleZAngle(vehicleid, a);
        return vehicleid;
    }

    GetPlayerPos(playerid, x, y, z);
    GetPlayerFacingAngle(playerid, a);
    return 0;
}


stock ER_PlayerCanUseVehicle(playerid, vehicleid)
{
    new idx = ER_FindVehicleBySpawnID(vehicleid);
    if(idx == -1) return 0;

    if(VehicleInfo[idx][vOwnerPID] > 0 && VehicleInfo[idx][vOwnerPID] == PlayerInfo[playerid][pID])
    {
        ER_Send(playerid, COLOR_GREEN, "You are the owner of this vehicle.");
        return 1;
    }

    if(VehicleInfo[idx][vFactionID] > 0 && VehicleInfo[idx][vFactionID] == PlayerInfo[playerid][pFaction])
    {
        ER_Send(playerid, COLOR_GREEN, "You are in a faction that owns this vehicle.");
        return 1;
    }

    if(VehicleInfo[idx][vFamilyID] > 0 && VehicleInfo[idx][vFamilyID] == PlayerInfo[playerid][pFamily])
    {
        ER_Send(playerid, COLOR_GREEN, "You are in a family that owns this vehicle.");
        return 1;
    }

    return 0;
}

stock ER_PlayerOwnsVehicleDirectly(playerid, vehicleid)
{
    new idx = ER_FindVehicleBySpawnID(vehicleid);
    if(idx == -1) return 0;
    return (VehicleInfo[idx][vOwnerPID] > 0 && VehicleInfo[idx][vOwnerPID] == PlayerInfo[playerid][pID]);
}


CMD:veh(playerid, params[])
{
    new vehicleid = GetPlayerVehicleID(playerid);
    if(vehicleid == 0) return ER_Send(playerid, COLOR_GREY, "You must be inside a vehicle.");
    ER_PlayerCanUseVehicle(playerid, vehicleid);

    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /veh(icle) [engine/lights/hood/trunk/windows]");
    return ER_Send(playerid, COLOR_GREY, "Vehicle component command placeholder. Engine/lights/hood/trunk/windows logic comes next.");
}
alias:veh("vehicle")

CMD:vehlock(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREY, "Vehicle lock/unlock placeholder. Ownership lock logic comes next.");
}
alias:vehlock("vehiclelock")

CMD:park(playerid, params[])
{
    new vehicleid = GetPlayerVehicleID(playerid);

    if(vehicleid == 0)
    {
        return ER_Send(playerid, COLOR_GREY, "You must be inside the vehicle you wish to park.");
    }

    if(!ER_PlayerOwnsVehicleDirectly(playerid, vehicleid))
    {
        return ER_Send(playerid, COLOR_GREY, "You cannot park a vehicle you do not personally own.");
    }

    new idx = ER_FindVehicleBySpawnID(vehicleid);

    if(idx == -1)
    {
        return ER_Send(playerid, COLOR_GREY, "This vehicle is not a saved dynamic vehicle.");
    }

    GetVehiclePos(vehicleid, VehicleInfo[idx][vX], VehicleInfo[idx][vY], VehicleInfo[idx][vZ]);
    GetVehicleZAngle(vehicleid, VehicleInfo[idx][vA]);
    VehicleInfo[idx][vInt] = GetPlayerInterior(playerid);
    VehicleInfo[idx][vVW] = GetPlayerVirtualWorld(playerid);

    ER_SaveVehicleTuning(idx);

    new q[256];
    mysql_format(MainPipeline, q, sizeof(q),
        "UPDATE `vehicles` SET `x`=%f,`y`=%f,`z`=%f,`a`=%f,`interior`=%d,`vw`=%d WHERE `id`=%d",
        VehicleInfo[idx][vX], VehicleInfo[idx][vY], VehicleInfo[idx][vZ], VehicleInfo[idx][vA],
        VehicleInfo[idx][vInt], VehicleInfo[idx][vVW], VehicleInfo[idx][vSQLID]
    );
    mysql_tquery(MainPipeline, q);

    ER_RespawnSavedVehicle(idx, playerid);

    return ER_Send(playerid, COLOR_GREEN, "Your vehicle has been parked successfully.");
}
