
ExpressRP v1.26 Vehicle Editor Patch

Changes:
- Added Rims as main /editvehicle option under Hydraulics.
- Rims removed from Mods dialog.
- Mods line is hidden completely if the vehicle has no compatible body mods.
- Mods dialog now only contains body/visual categories:
  Spoiler, Hood, Roof, Side Skirts, Lamps, Exhaust, Front/Rear Bumpers, Vents.
- When changing the vehicle model, incompatible saved mods/paintjob/NOS are reset automatically
  so the new model does not keep invalid components.
- Existing compatible universal options like rims/hydraulics/NOS remain where applicable.
