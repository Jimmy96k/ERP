#if defined _ER_HELP_INCLUDED
    #endinput
#endif
#define _ER_HELP_INCLUDED

CMD:help(playerid, params[])
{
    SendClientMessage(playerid, COLOR_HELP, "*** ACCOUNT *** /stats /inventory /changepass /togphone /number");
    SendClientMessage(playerid, COLOR_HELP, "*** CHAT *** /s(hout) /l(ow) /g /newb(ie) /me /do /accent");
    SendClientMessage(playerid, COLOR_HELP, "*** PHONE/RADIO *** /call /p(ickup) /h(angup) /sms /setfreq /pr /fbackup");
    SendClientMessage(playerid, COLOR_HELP, "*** GENERAL *** /pay /give /use /tie /buyinsurance /togfreehospital");
    SendClientMessage(playerid, COLOR_HELP, "*** VEHICLE *** /veh(icle) /veh(icle)lock /park /trackveh(icle) /vehicles /vehiclehelp");
    SendClientMessage(playerid, COLOR_HELP, "*** OTHER HELP *** /jobhelp /familyhelp /factionhelp /househelp /businesshelp /ahelp");
    return 1;
}

CMD:vehiclehelp(playerid, params[])
{
    SendClientMessage(playerid, COLOR_HELP, "*** VEHICLE HELP *** /veh(icle) engine /veh(icle) lights /veh(icle) hood /veh(icle) trunk /veh(icle) windows");
    SendClientMessage(playerid, COLOR_HELP, "*** VEHICLE HELP *** /veh(icle)lock /park /trackveh(icle) /vehicles");
    return 1;
}
alias:vehiclehelp("vehhelp")

CMD:jobhelp(playerid, params[]) { return ER_Send(playerid, COLOR_HELP, "Job help placeholder. Job commands will be listed here later."); }
CMD:familyhelp(playerid, params[]) { return ER_Send(playerid, COLOR_HELP, "Family help placeholder. Family commands will be listed here later."); }
CMD:factionhelp(playerid, params[]) { return ER_Send(playerid, COLOR_HELP, "Faction help placeholder. Faction commands will be listed here later."); }
CMD:househelp(playerid, params[]) { return ER_Send(playerid, COLOR_HELP, "House help placeholder. House commands will be listed here later."); }
CMD:businesshelp(playerid, params[]) { return ER_Send(playerid, COLOR_HELP, "Business help placeholder. Business commands will be listed here later."); }

CMD:ahelp(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** ADMIN *** /a /goto /gethere /aveh [model/name] [c1] [c2] /createpveh /createveh /editveh /deleteveh /allvehs");
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** DYNAMIC *** /createhospital /edithospitals /edithospital /createbusiness /editbusinesses /editbusiness /createfamily /editfamilies /editfamily");
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** AUDIO *** /audiostream [distance]");
    return 1;
}
