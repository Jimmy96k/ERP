#if defined _ER_VEHICLES_INCLUDED
    #endinput
#endif
#define _ER_VEHICLES_INCLUDED

new VehicleTrackIcon[MAX_PLAYERS] = { -1, ... };

new const ER_VehicleNames[212][] =
{
	"Landstalker","Bravura","Buffalo","Linerunner","Pereniel","Sentinel","Dumper","Firetruck","Trashmaster","Stretch","Manana","Infernus","Voodoo","Pony","Mule","Cheetah","Ambulance","Leviathan","Moonbeam","Esperanto","Taxi","Washington","Bobcat","Mr Whoopee","BF Injection","Hunter","Premier","Enforcer","Securicar","Banshee","Predator","Bus","Rhino","Barracks","Hotknife","Trailer","Previon","Coach","Cabbie","Stallion","Rumpo","RC Bandit","Romero","Packer","Monster","Admiral","Squalo","Seasparrow","Pizzaboy","Tram","Trailer","Turismo","Speeder","Reefer","Tropic","Flatbed","Yankee","Caddy","Solair","Berkley's RC Van","Skimmer","PCJ-600","Faggio","Freeway","RC Baron","RC Raider","Glendale","Oceanic","Sanchez","Sparrow","Patriot","Quad","Coastguard","Dinghy","Hermes","Sabre","Rustler","ZR-350","Walton","Regina","Comet","BMX","Burrito","Camper","Marquis","Baggage","Dozer","Maverick","News Chopper","Rancher","FBI Rancher","Virgo","Greenwood","Jetmax","Hotring","Sandking","Blista Compact","Police Maverick","Boxville","Benson","Mesa","RC Goblin","Hotring Racer A","Hotring Racer B","Bloodring Banger","Rancher","Super GT","Elegant","Journey","Bike","Mountain Bike","Beagle","Cropdust","Stunt","Tanker","RoadTrain","Nebula","Majestic","Buccaneer","Shamal","Hydra","FCR-900","NRG-500","HPV1000","Cement Truck","Tow Truck","Fortune","Cadrona","FBI Truck","Willard","Forklift","Tractor","Combine","Feltzer","Remington","Slamvan","Blade","Freight","Streak","Vortex","Vincent","Bullet","Clover","Sadler","Firetruck LA","Hustler","Intruder","Primo","Cargobob","Tampa","Sunrise","Merit","Utility","Nevada","Yosemite","Windsor","Monster A","Monster B","Uranus","Jester","Sultan","Stratum","Elegy","Raindance","RC Tiger","Flash","Tahoma","Savanna","Bandito","Freight Flat","Streak Carriage","Kart","Mower","Duneride","Sweeper","Broadway","Tornado","AT-400","DFT-30","Huntley","Stafford","BF-400","Newsvan","Tug","Trailer 3","Emperor","Wayfarer","Euros","Hotdog","Club","Freight Carriage","Trailer 3","Andromada","Dodo","RC Cam","Launch","Police Car LSPD","Police Car SFPD","Police Car LVPD","Police Ranger","Picador","S.W.A.T.","Alpha","Phoenix","Glendale Shit","Sadler Shit","Luggage Trailer A","Luggage Trailer B","Stair Trailer","Boxville","Farm Plow","Utility Trailer"
};

stock ER_GetVehicleModelName(model)
{
	static name[32];
	if(model >= 400 && model <= 611) format(name, sizeof(name), "%s", ER_VehicleNames[model - 400]);
	else format(name, sizeof(name), "Unknown");
	return name;
}

stock ER_FindVehicleModel(const input[])
{
	if(strlen(input) == 0) return 0;
	if(input[0] >= '0' && input[0] <= '9')
	{
		new model = strval(input);
		if(model >= 400 && model <= 611) return model;
		return 0;
	}

	new compact[32], test[32];
	format(compact, sizeof(compact), "%s", input);
	for(new c; compact[c] != EOS; c++)
	{
		if(compact[c] == '-' || compact[c] == '_' || compact[c] == ' ') compact[c] = EOS;
	}

	for(new i; i < sizeof(ER_VehicleNames); i++)
	{
		if(!strcmp(input, ER_VehicleNames[i], true)) return i + 400;

		format(test, sizeof(test), "%s", ER_VehicleNames[i]);
		for(new c; test[c] != EOS; c++)
		{
			if(test[c] == '-' || test[c] == '_' || test[c] == ' ') test[c] = EOS;
		}
		if(!strcmp(compact, test, true)) return i + 400;
	}
	return 0;
}

stock ER_GetVehicleAreaName(Float:x, Float:y, Float:z, dest[], size = sizeof(dest))
{
	#pragma unused z
	if(x >= 44.0 && x <= 2997.0 && y >= -2892.0 && y <= -768.0) format(dest, size, "Los Santos");
	else if(x >= -2997.0 && x <= -1213.0 && y >= -1115.0 && y <= 1659.0) format(dest, size, "San Fierro");
	else if(x >= 869.0 && x <= 2997.0 && y >= 596.0 && y <= 2997.0) format(dest, size, "Las Venturas");
	else format(dest, size, "San Andreas");
	return 1;
}

stock ER_GetVehicleLockName(locktype)
{
	static name[16];
	switch(locktype)
	{
		case 1: format(name, sizeof(name), "Alarm");
		case 2: format(name, sizeof(name), "Industrial");
		default: format(name, sizeof(name), "None");
	}
	return name;
}

stock ER_LoadVehicles()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `vehicles` WHERE `enabled`=1", "ER_OnVehiclesLoad");
    return 1;
}

forward ER_OnVehiclesLoad();
public ER_OnVehiclesLoad()
{
    new rows; cache_get_row_count(rows); VehicleCount = 0;
    for(new r; r < rows && VehicleCount < MAX_DYNAMIC_VEHICLES; r++)
    {
        cache_get_value_name_int(r, "id", VehicleInfo[VehicleCount][vSQLID]);
        cache_get_value_name_int(r, "owner_pid", VehicleInfo[VehicleCount][vOwnerPID]);
        cache_get_value_name_int(r, "family_id", VehicleInfo[VehicleCount][vFamilyID]);
        cache_get_value_name_int(r, "faction_id", VehicleInfo[VehicleCount][vFactionID]);
        cache_get_value_name_int(r, "model", VehicleInfo[VehicleCount][vModel]);
        cache_get_value_name_int(r, "color1", VehicleInfo[VehicleCount][vColor1]);
        cache_get_value_name_int(r, "color2", VehicleInfo[VehicleCount][vColor2]);
        cache_get_value_name_float(r, "x", VehicleInfo[VehicleCount][vX]);
        cache_get_value_name_float(r, "y", VehicleInfo[VehicleCount][vY]);
        cache_get_value_name_float(r, "z", VehicleInfo[VehicleCount][vZ]);
        cache_get_value_name_float(r, "a", VehicleInfo[VehicleCount][vA]);
        cache_get_value_name_int(r, "interior", VehicleInfo[VehicleCount][vInt]);
        cache_get_value_name_int(r, "vw", VehicleInfo[VehicleCount][vVW]);
        cache_get_value_name_int(r, "lock_type", VehicleInfo[VehicleCount][vLockType]);

        VehicleInfo[VehicleCount][vSpawnedID] = CreateVehicle(VehicleInfo[VehicleCount][vModel], VehicleInfo[VehicleCount][vX], VehicleInfo[VehicleCount][vY], VehicleInfo[VehicleCount][vZ], VehicleInfo[VehicleCount][vA], VehicleInfo[VehicleCount][vColor1], VehicleInfo[VehicleCount][vColor2], -1);
        SetVehicleVirtualWorld(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vVW]);
        LinkVehicleToInterior(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vInt]);
        VehicleCount++;
    }
    printf("[Vehicles] Loaded %d vehicles.", VehicleCount);
    return 1;
}

CMD:aveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0;
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /aveh [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    new Float:x, Float:y, Float:z, Float:a;
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    new veh = CreateVehicle(model, x + 3.0, y, z, a, c1, c2, -1);
    SetVehicleVirtualWorld(veh, GetPlayerVirtualWorld(playerid));
    LinkVehicleToInterior(veh, GetPlayerInterior(playerid));
    PutPlayerInVehicle(playerid, veh, 0);

    new msg[96];
    format(msg, sizeof(msg), "Spawned temporary %s (%d).", ER_GetVehicleModelName(model), model);
    return ER_Send(playerid, COLOR_GREEN, msg);
}

CMD:createveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0, q[512], Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createveh(icle) [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`x`,`y`,`z`,`a`,`interior`,`vw`,`lock_type`,`enabled`) VALUES (0,0,0,%d,%d,%d,%f,%f,%f,%f,%d,%d,0,1)",
        model, c1, c2, x + 3.0, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q, "ER_OnAdminVehicleCreated", "iiiii", playerid, model, c1, c2, GetPlayerVirtualWorld(playerid));
    return 1;
}
alias:createveh("createvehicle")

forward ER_OnAdminVehicleCreated(playerid, model, c1, c2, vw);
public ER_OnAdminVehicleCreated(playerid, model, c1, c2, vw)
{
	#pragma unused vw
	new vid = cache_insert_id();
	ER_LoadVehicles();
	new msg[128];
	format(msg, sizeof(msg), "Saved vehicle created. SQL ID: %d | %s (%d).", vid, ER_GetVehicleModelName(model), model);
	ER_Send(playerid, COLOR_GREEN, msg);
	return 1;
}

CMD:createpveh(playerid, params[])
{
    new pid, modelstr[32], model, q[512], c1 = 0, c2 = 0, Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "ds[32]D(0)D(0)", pid, modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createpveh [pID] [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`x`,`y`,`z`,`a`,`interior`,`vw`,`enabled`) VALUES (%d,0,0,%d,%d,%d,%f,%f,%f,%f,%d,%d,1)",
        pid, model, c1, c2, x+3.0, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q);
    ER_LoadVehicles();
    return ER_Send(playerid, COLOR_GREEN, "Player vehicle created.");
}

CMD:vehicles(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnMyVehiclesDialog", "i", playerid);
	return 1;
}

forward ER_OnMyVehiclesDialog(playerid);
public ER_OnMyVehiclesDialog(playerid)
{
	new rows, list[2048], model, locktype, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", model); // temp id
		new sqlid = model;
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%s\t%s\t%s\n", list, sqlid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_MY_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "My Vehicles", list, "Close", "");
	return 1;
}

CMD:trackveh(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleList", "i", playerid);
	return 1;
}
alias:trackveh("trackvehicle")

forward ER_OnTrackVehicleList(playerid);
public ER_OnTrackVehicleList(playerid)
{
	new rows, list[2048], model, locktype, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		new sqlid;
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%s\t%s\t%s\n", list, sqlid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_TRACK_VEHICLE, DIALOG_STYLE_TABLIST_HEADERS, "Track Vehicle", list, "Track", "Close");
	return 1;
}

CMD:allvehs(playerid, params[])
{
	if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
	mysql_tquery(MainPipeline, "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.enabled=1 ORDER BY v.id ASC LIMIT 100", "ER_OnAllVehiclesDialog", "i", playerid);
	return 1;
}
alias:allvehs("allvehicles")

forward ER_OnAllVehiclesDialog(playerid);
public ER_OnAllVehiclesDialog(playerid)
{
	new rows, list[4096], sqlid, model, ownerpid, familyid, factionid, Float:x, Float:y, Float:z, area[32], owner[64], ownername[24];
	cache_get_row_count(rows);
	format(list, sizeof(list), "ID\tModel\tOwner\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "owner_pid", ownerpid);
		cache_get_value_name_int(r, "family_id", familyid);
		cache_get_value_name_int(r, "faction_id", factionid);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		cache_get_value_name(r, "owner_name", ownername, sizeof(ownername));
		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		if(ownerpid > 0) format(owner, sizeof(owner), "Player Owned (%d) %s", ownerpid, ownername[0] ? ownername : "Unknown");
		else if(factionid > 0) format(owner, sizeof(owner), "Faction Owned (%d)", factionid);
		else if(familyid > 0) format(owner, sizeof(owner), "Family Owned (%d)", familyid);
		else format(owner, sizeof(owner), "None");
		format(list, sizeof(list), "%s%d\t%s\t%s\t%s\n", list, sqlid, ER_GetVehicleModelName(model), owner, area);
	}
	ShowPlayerDialog(playerid, DIALOG_ALL_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "All Vehicles", list, "Close", "");
	return 1;
}

CMD:editveh(playerid, params[])
{
	new vehid;
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editveh(icle) [vehicle SQL id]");
	SetPVarInt(playerid, "EditingVehicleID", vehid);
	ShowPlayerDialog(playerid, DIALOG_EDIT_VEHICLE_MENU, DIALOG_STYLE_LIST, "Edit Vehicle", "Goto Vehicle\nRespawn Vehicle\nSet Position Here\nDelete Vehicle", "Select", "Close");
	return 1;
}
alias:editveh("editvehicle")

CMD:deleteveh(playerid, params[])
{
	new vehid, q[128];
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /deleteveh(icle) [vehicle SQL id]");
	mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", vehid);
	mysql_tquery(MainPipeline, q);
	ER_LoadVehicles();
	return ER_Send(playerid, COLOR_GREEN, "Vehicle deleted/disabled.");
}
alias:deleteveh("deletevehicle")

stock ER_VehicleDialog(playerid, dialogid, response, listitem, inputtext[])
{
	#pragma unused inputtext

	if(dialogid == DIALOG_TRACK_VEHICLE)
	{
		if(!response) return 1;
		new q[160];
		// Requery by list index.
		mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC LIMIT %d,1", PlayerInfo[playerid][pID], listitem);
		mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleSelect", "i", playerid);
		return 1;
	}

	if(dialogid == DIALOG_MY_VEHICLES || dialogid == DIALOG_ALL_VEHICLES)
	{
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEHICLE_MENU)
	{
		if(!response) return 1;
		new vehid = GetPVarInt(playerid, "EditingVehicleID");
		if(vehid <= 0) return 1;

		switch(listitem)
		{
			case 0:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `id`=%d LIMIT 1", vehid);
				mysql_tquery(MainPipeline, q, "ER_OnGotoVehicleSQL", "i", playerid);
			}
			case 1:
			{
				ER_LoadVehicles();
				ER_Send(playerid, COLOR_GREEN, "Vehicle reload requested.");
			}
			case 2:
			{
				new Float:x, Float:y, Float:z, Float:a, q[256];
				GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
				mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `x`=%f,`y`=%f,`z`=%f,`a`=%f,`interior`=%d,`vw`=%d WHERE `id`=%d",
					x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid), vehid);
				mysql_tquery(MainPipeline, q);
				ER_LoadVehicles();
				ER_Send(playerid, COLOR_GREEN, "Vehicle position updated.");
			}
			case 3:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", vehid);
				mysql_tquery(MainPipeline, q);
				ER_LoadVehicles();
				ER_Send(playerid, COLOR_GREEN, "Vehicle disabled.");
			}
		}
		return 1;
	}
	return 0;
}

forward ER_OnTrackVehicleSelect(playerid);
public ER_OnTrackVehicleSelect(playerid)
{
	new rows, Float:x, Float:y, Float:z, sqlid, model;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	cache_get_value_name_int(0, "id", sqlid);
	cache_get_value_name_int(0, "model", model);
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);

	if(VehicleTrackIcon[playerid] != -1) DestroyDynamicMapIcon(VehicleTrackIcon[playerid]);
	VehicleTrackIcon[playerid] = CreateDynamicMapIcon(x, y, z, 55, 0xFF0000FF, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid), playerid, 6000.0, MAPICON_GLOBAL);

	new msg[128];
	format(msg, sizeof(msg), "Tracking vehicle %d: %s. Red marker added to your map.", sqlid, ER_GetVehicleModelName(model));
	return ER_Send(playerid, COLOR_GREEN, msg);
}

forward ER_OnGotoVehicleSQL(playerid);
public ER_OnGotoVehicleSQL(playerid)
{
	new rows, Float:x, Float:y, Float:z, interior, vw;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);
	cache_get_value_name_int(0, "interior", interior);
	cache_get_value_name_int(0, "vw", vw);
	SetPlayerInterior(playerid, interior);
	SetPlayerVirtualWorld(playerid, vw);
	SetPlayerPos(playerid, x + 2.0, y, z);
	return 1;
}

CMD:veh(playerid, params[])
{
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /veh(icle) [engine/lights/hood/trunk/windows]");
    return ER_Send(playerid, COLOR_GREY, "Vehicle component command placeholder. Engine/lights/hood/trunk/windows logic comes next.");
}
alias:veh("vehicle")

CMD:vehlock(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREY, "Vehicle lock/unlock placeholder. Ownership lock logic comes next.");
}
alias:vehlock("vehiclelock")

CMD:park(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREY, "Vehicle park placeholder. Owned vehicle save logic comes next.");
}
