
ExpressRP v1.20 Vehicle Patch

Included:
- Persistent vehicle tuning
- Persistent NOS
- Persistent paintjobs
- Exact /park save transform
- Exact /editvehicle position transform
- Vehicle-only reload
- Paintjob names
- Unsupported paintjob checks

Import:
SQL_V120_VEHICLE_UPGRADE.sql

Recompile the gamemode after replacing files.
