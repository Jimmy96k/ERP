#if defined _ER_VEHICLES_INCLUDED
    #endinput
#endif
#define _ER_VEHICLES_INCLUDED

stock ER_LoadVehicles()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `vehicles` WHERE `enabled`=1", "ER_OnVehiclesLoad");
    return 1;
}

forward ER_OnVehiclesLoad();
public ER_OnVehiclesLoad()
{
    new rows; cache_get_row_count(rows); VehicleCount = 0;
    for(new r; r < rows && VehicleCount < MAX_DYNAMIC_VEHICLES; r++)
    {
        cache_get_value_name_int(r, "id", VehicleInfo[VehicleCount][vSQLID]);
        cache_get_value_name_int(r, "owner_pid", VehicleInfo[VehicleCount][vOwnerPID]);
        cache_get_value_name_int(r, "family_id", VehicleInfo[VehicleCount][vFamilyID]);
        cache_get_value_name_int(r, "faction_id", VehicleInfo[VehicleCount][vFactionID]);
        cache_get_value_name_int(r, "model", VehicleInfo[VehicleCount][vModel]);
        cache_get_value_name_int(r, "color1", VehicleInfo[VehicleCount][vColor1]);
        cache_get_value_name_int(r, "color2", VehicleInfo[VehicleCount][vColor2]);
        cache_get_value_name_float(r, "x", VehicleInfo[VehicleCount][vX]);
        cache_get_value_name_float(r, "y", VehicleInfo[VehicleCount][vY]);
        cache_get_value_name_float(r, "z", VehicleInfo[VehicleCount][vZ]);
        cache_get_value_name_float(r, "a", VehicleInfo[VehicleCount][vA]);
        cache_get_value_name_int(r, "interior", VehicleInfo[VehicleCount][vInt]);
        cache_get_value_name_int(r, "vw", VehicleInfo[VehicleCount][vVW]);
        cache_get_value_name_int(r, "lock_type", VehicleInfo[VehicleCount][vLockType]);
        VehicleInfo[VehicleCount][vSpawnedID] = CreateVehicle(VehicleInfo[VehicleCount][vModel], VehicleInfo[VehicleCount][vX], VehicleInfo[VehicleCount][vY], VehicleInfo[VehicleCount][vZ], VehicleInfo[VehicleCount][vA], VehicleInfo[VehicleCount][vColor1], VehicleInfo[VehicleCount][vColor2], -1);
        SetVehicleVirtualWorld(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vVW]);
        LinkVehicleToInterior(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vInt]);
        VehicleCount++;
    }
    printf("[Vehicles] Loaded %d vehicles.", VehicleCount);
    return 1;
}

CMD:aveh(playerid, params[])
{
    new model, c1 = 0, c2 = 0;
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    if(sscanf(params, "iD(0)D(0)", model, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /aveh [model] [color1 optional] [color2 optional]");
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid model.");
    new Float:x, Float:y, Float:z, Float:a;
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    new veh = CreateVehicle(model, x+3.0, y, z, a, c1, c2, -1);
    SetVehicleVirtualWorld(veh, GetPlayerVirtualWorld(playerid));
    LinkVehicleToInterior(veh, GetPlayerInterior(playerid));
    PutPlayerInVehicle(playerid, veh, 0);
    return 1;
}

CMD:createpveh(playerid, params[])
{
    new pid, model, q[512], c1 = 0, c2 = 0, Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "iiD(0)D(0)", pid, model, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createpveh [pID] [model] [color1 optional] [color2 optional]");
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid model.");
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`x`,`y`,`z`,`a`,`interior`,`vw`,`enabled`) VALUES (%d,-1,-1,%d,%d,%d,%f,%f,%f,%f,%d,%d,1)", pid, model, c1, c2, x+3.0, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q);
    return ER_Send(playerid, COLOR_GREEN, "Player vehicle created in SQL. Use /reloadvehicles later or restart.");
}

CMD:vehicle(playerid, params[])
{
    new action[24];
    if(sscanf(params, "s[24]", action)) return ER_Send(playerid, COLOR_GREY, "USAGE: /vehicle [engine/lights/hood/trunk/windows]");
    new veh = GetPlayerVehicleID(playerid);
    if(!veh) return ER_Send(playerid, COLOR_GREY, "You are not in a vehicle.");
    new engine, lights, alarm, doors, bonnet, boot, objective;
    GetVehicleParamsEx(veh, engine, lights, alarm, doors, bonnet, boot, objective);
    if(!strcmp(action, "engine", true)) engine = !engine;
    else if(!strcmp(action, "lights", true)) lights = !lights;
    else if(!strcmp(action, "hood", true)) bonnet = !bonnet;
    else if(!strcmp(action, "trunk", true)) boot = !boot;
    else if(!strcmp(action, "windows", true)) return ER_Send(playerid, COLOR_GREEN, "Window system placeholder: closed windows will block outside normal chat in vehicle module phase 2.");
    else return ER_Send(playerid, COLOR_GREY, "Invalid vehicle action.");
    SetVehicleParamsEx(veh, engine, lights, alarm, doors, bonnet, boot, objective);
    return ER_Send(playerid, COLOR_GREEN, "Vehicle state updated.");
}
alias:vehicle("veh")

CMD:park(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREEN, "Vehicle park placeholder added. Owned vehicle saving will be expanded in phase 2.");
}

CMD:vehlock(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREEN, "Vehicle lock/unlock placeholder added. Lock ownership checks will be expanded in phase 2.");
}
alias:vehlock("vehiclelock")
