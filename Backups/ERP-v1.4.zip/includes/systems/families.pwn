#if defined _ER_FAMILIES_INCLUDED
    #endinput
#endif
#define _ER_FAMILIES_INCLUDED

stock ER_LoadFamilies()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `families` WHERE `enabled`=1", "ER_OnFamiliesLoad");
    return 1;
}
forward ER_OnFamiliesLoad();
public ER_OnFamiliesLoad()
{
    new rows; cache_get_row_count(rows); FamilyCount = 0;
    for(new r; r < rows && FamilyCount < MAX_FAMILIES; r++)
    {
        cache_get_value_name_int(r, "id", Families[FamilyCount][fSQLID]);
        cache_get_value_name(r, "name", Families[FamilyCount][fName], 64);
        cache_get_value_name_int(r, "leader_id", Families[FamilyCount][fLeaderID]);
        cache_get_value_name(r, "leader_name", Families[FamilyCount][fLeaderName], MAX_PLAYER_NAME_EX);
        cache_get_value_name(r, "motd", Families[FamilyCount][fMOTD], 128);
        FamilyCount++;
    }
    printf("[Families] Loaded %d families.", FamilyCount);
    return 1;
}

CMD:createfamily(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createfamily [name]");
    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `families` (`name`,`leader_id`,`leader_name`,`motd`,`safe_deposit_rank`,`safe_withdraw_rank`,`locker_deposit_rank`,`locker_withdraw_rank`,`locker_gun_rank`,`enabled`) VALUES ('%e',0,'Nobody','Welcome to the family.',1,6,1,6,1,1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnFamilyCreated", "i", playerid);
    return 1;
}
forward ER_OnFamilyCreated(playerid);
public ER_OnFamilyCreated(playerid)
{
    new fid = cache_insert_id(), q[1024];
    for(new r = 1; r <= 6; r++)
    {
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_ranks` (`family_id`,`rank_id`,`rank_name`) VALUES (%d,%d,'Rank %d')", fid, r, r);
        mysql_tquery(MainPipeline, q);
    }
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_lockers` (`family_id`,`materials`,`enabled`) VALUES (%d,10000,1)", fid);
    mysql_tquery(MainPipeline, q, "ER_OnDefaultFamilyLocker", "i", fid);
    ER_LoadFamilies();
    ER_Send(playerid, COLOR_GREEN, "Family created with 6 ranks, 1 locker and default materials.");
    return 1;
}
forward ER_OnDefaultFamilyLocker(fid);
public ER_OnDefaultFamilyLocker(fid)
{
    new lockerid = cache_insert_id(), q[256];
    for(new w; w < 10; w++)
    {
        new weapon = (w == 0) ? 22 : ((w == 1) ? 23 : ((w == 2) ? 29 : 0));
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_locker_guns` (`locker_id`,`weaponid`,`admin_enabled`,`leader_enabled`) VALUES (%d,%d,1,1)", lockerid, weapon);
        mysql_tquery(MainPipeline, q);
    }
    return 1;
}

CMD:editfamilies(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new list[2048];
    for(new i; i < FamilyCount; i++) format(list, sizeof(list), "%s%d | %s | Leader: %s\n", list, Families[i][fSQLID], Families[i][fName], Families[i][fLeaderName]);
    ShowPlayerDialog(playerid, DIALOG_FAMILY_LIST, DIALOG_STYLE_LIST, "Select Family", list, "Edit", "Cancel");
    return 1;
}


stock ER_ShowFamilyEditor(playerid, fid)
{
	SetPVarInt(playerid, "EditingFamily", fid);
	ShowPlayerDialog(playerid, DIALOG_FAMILY_EDITOR, DIALOG_STYLE_LIST, "Family Editor",
		"Name\nLeader\nMOTD\nRanks\nCrews\nLockers\nSafes\nPermissions\nStatus\nSave & Reload",
		"Select", "Close");
	return 1;
}


CMD:editfamily(playerid, params[])
{
    new fid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", fid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editfamily [id]");
    return ER_ShowFamilyEditor(playerid, fid);
}

CMD:f(playerid, params[])
{
    if(PlayerInfo[playerid][pFamily] == INVALID_FAMILY_ID) return ER_Send(playerid, COLOR_GREY, "You are not in a family.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /f [message]");
    new msg[160]; format(msg, sizeof(msg), "(( Family )) [Crew %d] %s: %s", PlayerInfo[playerid][pFamilyCrew], ER_GetName(playerid), params);
    foreach(new i : Player) if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pFamily] == PlayerInfo[playerid][pFamily]) SendClientMessage(i, COLOR_GREEN, msg);
    return 1;
}
alias:f("family")

CMD:familysettings(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREEN, "Family settings placeholder. Leaders will manage leader-enabled guns, lockers, safes and crews here.");
}

stock ER_FamilyDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_FAMILY_LIST)
    {
        if(response && listitem >= 0 && listitem < FamilyCount) { ER_ShowFamilyEditor(playerid, Families[listitem][fSQLID]); }
        return 1;
    }
    if(dialogid == DIALOG_FAMILY_EDITOR) { if(response) ER_Send(playerid, COLOR_GREY, "Family editor field placeholder for next phase."); return 1; }
    return 0;
}
