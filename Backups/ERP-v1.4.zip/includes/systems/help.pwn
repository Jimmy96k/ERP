#if defined _ER_HELP_INCLUDED
    #endinput
#endif
#define _ER_HELP_INCLUDED

CMD:help(playerid, params[])
{
    SendClientMessage(playerid, COLOR_HELP, "*** ACCOUNT *** /stats /inventory /changepass /togphone /number");
    SendClientMessage(playerid, COLOR_HELP, "*** CHAT *** /s(hout) /l(ow) /g /newb(ie) /me /do /accent");
    SendClientMessage(playerid, COLOR_HELP, "*** PHONE/RADIO *** /call /p(ickup) /h(angup) /sms /setfreq /pr /fbackup");
    SendClientMessage(playerid, COLOR_HELP, "*** GENERAL *** /pay /give /use /tie /buyinsurance /togfreehospital");
    SendClientMessage(playerid, COLOR_HELP, "*** VEHICLE *** /veh /vehicle /park /vehlock /vehiclelock");
    SendClientMessage(playerid, COLOR_HELP, "*** OTHER *** /family /businesssettings /familysettings /help /ahelp");
    return 1;
}

CMD:ahelp(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** ADMIN *** /a /goto /gethere /aveh /createpveh /setadmin /setvip /osetstat");
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** DYNAMIC *** /createhospital /edithospitals /edithospital /createbusiness /editbusinesses /editbusiness /createfamily /editfamilies /editfamily");
    SendClientMessage(playerid, COLOR_LIGHTRED, "*** AUDIO *** /audiostream [distance]");
    return 1;
}
