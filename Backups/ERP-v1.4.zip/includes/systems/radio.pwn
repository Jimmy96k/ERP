#if defined _ER_RADIO_INCLUDED
    #endinput
#endif
#define _ER_RADIO_INCLUDED

new FamilyBeaconActive[MAX_PLAYERS];
new FamilyBeaconTimer[MAX_PLAYERS];
new FamilyBeaconIcon[MAX_PLAYERS][MAX_PLAYERS];

stock ER_LoadAudioStreams()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `audio_streams` WHERE `enabled`=1 ORDER BY `id` ASC", "ER_OnAudioStreamsLoad");
    return 1;
}

forward ER_OnAudioStreamsLoad();
public ER_OnAudioStreamsLoad()
{
    new rows;
    cache_get_row_count(rows);
    AudioStreamCount = 0;
    for(new r; r < rows && AudioStreamCount < MAX_AUDIO_STREAMS; r++)
    {
        cache_get_value_name_int(r, "id", AudioStreams[AudioStreamCount][asSQLID]);
        cache_get_value_name(r, "name", AudioStreams[AudioStreamCount][asName], 64);
        cache_get_value_name(r, "url", AudioStreams[AudioStreamCount][asURL], 256);
        AudioStreamCount++;
    }
    printf("[AudioStreams] Loaded %d streams.", AudioStreamCount);
    return 1;
}

CMD:setfreq(playerid, params[])
{
    new freq;
    if(sscanf(params, "d", freq)) return ER_Send(playerid, COLOR_GREY, "USAGE: /setfreq [1 to 99999]");
    if(!PlayerInfo[playerid][pHasRadio]) return ER_Send(playerid, COLOR_GREY, "You must have a radio to use this command.");
    if(freq < RADIO_MIN_FREQ || freq > RADIO_MAX_FREQ) return ER_Send(playerid, COLOR_GREY, "Frequency must be between 1 and 99999.");
    PlayerInfo[playerid][pRadio] = freq;
    new msg[96]; format(msg, sizeof(msg), "Radio frequency set to %d.", freq);
    return ER_Send(playerid, COLOR_RADIO, msg);
}

CMD:pr(playerid, params[])
{
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /pr [message]");
    if(!PlayerInfo[playerid][pHasRadio]) return ER_Send(playerid, COLOR_GREY, "You must have a radio to use this command.");
    if(PlayerInfo[playerid][pRadio] == 0) return ER_Send(playerid, COLOR_GREY, "Please set your radio frequency first by using /setfreq [1 to 99999].");
    new msg[160], local[160], Float:x, Float:y, Float:z;
    format(msg, sizeof(msg), "[Radio: %d] %s says: %s", PlayerInfo[playerid][pRadio], ER_GetName(playerid), params);
    foreach(new i : Player)
    {
        if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pHasRadio] && PlayerInfo[i][pRadio] == PlayerInfo[playerid][pRadio]) SendClientMessage(i, COLOR_RADIO, msg);
    }
    GetPlayerPos(playerid, x, y, z);
    format(local, sizeof(local), "%s using (Radio): %s", ER_GetName(playerid), params);
    ER_NearbyMessage(x, y, z, CHAT_RANGE_LOW, COLOR_WHITE, local, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
    return 1;
}
alias:pr("publicradio")

CMD:fbackup(playerid, params[])
{
    if(PlayerInfo[playerid][pFamily] == INVALID_FAMILY_ID) return ER_Send(playerid, COLOR_GREY, "You are not in a family.");
    if(!PlayerInfo[playerid][pHasRadio]) return ER_Send(playerid, COLOR_GREY, "You must have a radio to use this command.");
    if(FamilyBeaconActive[playerid]) return ER_Send(playerid, COLOR_GREY, "You already have an active beacon.");
    new zone[32] = "Unknown", msg[160], local[128], Float:x, Float:y, Float:z;
    ER_GetPlayerZone(playerid, zone, sizeof(zone));
    if(PlayerInfo[playerid][pWantedLevel] > 0) format(msg, sizeof(msg), "** Radio ** %s (%d): I need urgent backup, Wanted with %d charges! At: %s!", ER_GetName(playerid), playerid, PlayerInfo[playerid][pWantedLevel], zone);
    else format(msg, sizeof(msg), "** Radio ** %s (%d): I need urgent backup! Currently at %s!", ER_GetName(playerid), playerid, zone);
    foreach(new i : Player)
    {
        if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pFamily] == PlayerInfo[playerid][pFamily])
        {
            SendClientMessage(i, COLOR_RADIO, msg);
            FamilyBeaconIcon[playerid][i] = SetPlayerMapIcon(i, 90 + playerid, x, y, z, 0, COLOR_YELLOW, MAPICON_GLOBAL);
        }
    }
    GetPlayerPos(playerid, x, y, z);
    format(local, sizeof(local), "* %s broadcasts a beacon signal.", ER_GetName(playerid));
    ER_NearbyMessage(x, y, z, CHAT_RANGE_NORMAL, COLOR_ME, local, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
    FamilyBeaconActive[playerid] = 1;
    FamilyBeaconTimer[playerid] = SetTimerEx("ER_ClearFamilyBeaconTimer", ServerCore[scFamilyBackupBeaconTime] * 1000, false, "i", playerid);
    ER_Send(playerid, COLOR_YELLOW, "Your beacon has been placed automatically. Type /nofbackup to clear your beacon.");
    return 1;
}

forward ER_ClearFamilyBeaconTimer(playerid);
public ER_ClearFamilyBeaconTimer(playerid)
{
    ER_ClearFamilyBeacon(playerid);
    if(IsPlayerConnected(playerid)) ER_Send(playerid, COLOR_GREY, "Your beacon has been cleared automatically.");
    return 1;
}

stock ER_ClearFamilyBeacon(playerid)
{
    if(FamilyBeaconTimer[playerid]) KillTimer(FamilyBeaconTimer[playerid]);
    FamilyBeaconTimer[playerid] = 0;
    FamilyBeaconActive[playerid] = 0;
    foreach(new i : Player) RemovePlayerMapIcon(i, 90 + playerid);
    return 1;
}

CMD:nofbackup(playerid, params[])
{
    ER_ClearFamilyBeacon(playerid);
    return ER_Send(playerid, COLOR_YELLOW, "You have cleared your beacon.");
}

CMD:audiostream(playerid, params[])
{
    new Float:distance;
    if(!ER_IsAdmin(playerid, ADMIN_SENIOR)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "f", distance)) return ER_Send(playerid, COLOR_GREY, "USAGE: /audiostream [stream distance]");
    if(AudioStreamCount <= 0) return ER_Send(playerid, COLOR_GREY, "No audio streams loaded from SQL.");
    SetPVarFloat(playerid, "AudioStreamDistance", distance);
    new list[2048];
    for(new i; i < AudioStreamCount; i++) format(list, sizeof(list), "%s%s\n", list, AudioStreams[i][asName]);
    ShowPlayerDialog(playerid, DIALOG_AUDIO_SELECT, DIALOG_STYLE_LIST, "Select Audio Stream", list, "Play", "Cancel");
    return 1;
}

stock ER_AudioDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid != DIALOG_AUDIO_SELECT) return 0;
    if(!response || listitem < 0 || listitem >= AudioStreamCount) return 1;
    new Float:x, Float:y, Float:z, Float:dist;
    GetPlayerPos(playerid, x, y, z);
    dist = GetPVarFloat(playerid, "AudioStreamDistance");
    foreach(new i : Player)
    {
        if(IsPlayerInRangeOfPoint(i, dist, x, y, z)) PlayAudioStreamForPlayer(i, AudioStreams[listitem][asURL], x, y, z, dist, 1);
    }
    return 1;
}
