#if defined _ER_UTILS_INCLUDED
    #endinput
#endif
#define _ER_UTILS_INCLUDED

stock ER_Send(playerid, color, const msg[]) return SendClientMessage(playerid, color, msg);

stock ER_GetName(playerid)
{
    new name[MAX_PLAYER_NAME];
    GetPlayerName(playerid, name, sizeof(name));
    return name;
}

stock ER_ResetPlayer(playerid)
{
    format(PlayerInfo[playerid][pName], MAX_PLAYER_NAME_EX, "%s", ER_GetName(playerid));
    PlayerInfo[playerid][pID] = 0;
    PlayerInfo[playerid][pLoggedIn] = 0;
    PlayerInfo[playerid][pRegistered] = 0;
    PlayerInfo[playerid][pTutorial] = 0;
    PlayerInfo[playerid][pTutorialStep] = 0;
    PlayerInfo[playerid][pAdmin] = 0;
    PlayerInfo[playerid][pPlayerVip] = 0;
    PlayerInfo[playerid][pPhone] = 0;
    PlayerInfo[playerid][pPhoneOff] = false;
    PlayerInfo[playerid][pPhonespeaker] = false;
    PlayerInfo[playerid][pPhoneline] = INVALID_CALL_PLAYER;
    PlayerInfo[playerid][pCalling] = INVALID_CALL_PLAYER;
    PlayerInfo[playerid][pCallState] = 0;
    PlayerInfo[playerid][pPhonebook] = 0;
    PlayerInfo[playerid][pHospInsurance] = NO_HOSPITAL_INSURANCE;
    PlayerInfo[playerid][pHasRadio] = 0;
    PlayerInfo[playerid][pRadio] = 0;
    PlayerInfo[playerid][pVehicleLock] = 0;
    PlayerInfo[playerid][pHospitalTime] = 30;
    PlayerInfo[playerid][pTogFreeHospital] = 0;
    PlayerInfo[playerid][pFamily] = INVALID_FAMILY_ID;
    PlayerInfo[playerid][pFamilyRank] = 0;
    PlayerInfo[playerid][pFamilyCrew] = 0;
    PlayerInfo[playerid][pBusiness] = INVALID_BUSINESS_ID;
    PlayerInfo[playerid][pInjured] = 0;
    PlayerInfo[playerid][pHospitalized] = 0;
    PlayerInfo[playerid][pHospitalBed] = -1;
    PlayerInfo[playerid][pHospitalID] = -1;
    PlayerInfo[playerid][pDeliveredByEMS] = 0;
    for(new i; i < MAX_JOBS_PER_PLAYER; i++) PlayerInfo[playerid][pPlayerJob][i] = 0;
    for(new w; w < MAX_WEAPON_SLOTS; w++) PlayerInfo[playerid][pPlayerWeapons][w] = 0;
    return 1;
}

stock ER_FormatMoney(amount)
{
    new out[32];
    format(out, sizeof(out), "$%d", amount);
    return out;
}

stock ER_IsAdmin(playerid, level)
{
    return PlayerInfo[playerid][pAdmin] >= level || PlayerInfo[playerid][pAdmin] == ADMIN_EXEC;
}

stock ER_ApplyDefaultPlayerInfo(playerid)
{
    PlayerInfo[playerid][pTutorial] = 0;
    PlayerInfo[playerid][pTutorialStep] = 0;
    PlayerInfo[playerid][pLevel] = 1;
    PlayerInfo[playerid][pPlayingHours] = 0;
    PlayerInfo[playerid][pCash] = ServerCore[scDefaultCash];
    PlayerInfo[playerid][pBank] = ServerCore[scDefaultBank];
    PlayerInfo[playerid][pAge] = 18;
    format(PlayerInfo[playerid][pDOB], 16, "01/01/2000");
    format(PlayerInfo[playerid][pCountry], 32, "Unknown");
    PlayerInfo[playerid][pGender] = 1;
    PlayerInfo[playerid][pAccent] = 0;
    PlayerInfo[playerid][pSkin] = ServerCore[scDefaultMaleSkin];
    PlayerInfo[playerid][pPhone] = 0;
    PlayerInfo[playerid][pPhoneOff] = false;
    PlayerInfo[playerid][pPhonebook] = 0;
    PlayerInfo[playerid][pHospInsurance] = NO_HOSPITAL_INSURANCE;
    format(PlayerInfo[playerid][pMarriedTo], MAX_PLAYER_NAME_EX, "Nobody");
    PlayerInfo[playerid][pCrimes] = 0;
    PlayerInfo[playerid][pArrests] = 0;
    PlayerInfo[playerid][pWantedLevel] = 0;
    PlayerInfo[playerid][pMaterials] = 0;
    PlayerInfo[playerid][pPot] = 0;
    PlayerInfo[playerid][pCrack] = 0;
    PlayerInfo[playerid][pRope] = 0;
    PlayerInfo[playerid][pPackages] = 0;
    PlayerInfo[playerid][pSeeds] = 0;
    PlayerInfo[playerid][pSprunk] = 0;
    PlayerInfo[playerid][pSprayCans] = 0;
    PlayerInfo[playerid][pHealth] = 100.0;
    PlayerInfo[playerid][pArmor] = 0.0;
    PlayerInfo[playerid][pRespectPoints] = 0;
    PlayerInfo[playerid][pWarnings] = 0;
    PlayerInfo[playerid][pSpawnX] = ServerCore[scDefaultSpawnX];
    PlayerInfo[playerid][pSpawnY] = ServerCore[scDefaultSpawnY];
    PlayerInfo[playerid][pSpawnZ] = ServerCore[scDefaultSpawnZ];
    PlayerInfo[playerid][pSpawnA] = ServerCore[scDefaultSpawnA];
    PlayerInfo[playerid][pSpawnInt] = ServerCore[scDefaultSpawnInt];
    PlayerInfo[playerid][pSpawnVW] = ServerCore[scDefaultSpawnVW];
    return 1;
}

stock ER_SpawnCharacter(playerid)
{
    TogglePlayerSpectating(playerid, false);
    SetPlayerInterior(playerid, PlayerInfo[playerid][pSpawnInt]);
    SetPlayerVirtualWorld(playerid, PlayerInfo[playerid][pSpawnVW]);
    SetPlayerPos(playerid, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ]);
    SetPlayerFacingAngle(playerid, PlayerInfo[playerid][pSpawnA]);
    SetPlayerSkin(playerid, PlayerInfo[playerid][pSkin]);
    SetPlayerHealth(playerid, PlayerInfo[playerid][pHealth]);
    SetPlayerArmour(playerid, PlayerInfo[playerid][pArmor]);
    GivePlayerMoney(playerid, PlayerInfo[playerid][pCash]);
    return 1;
}

stock ER_NearbyMessage(Float:x, Float:y, Float:z, Float:range, color, const message[], world = -1, interior = -1)
{
    foreach(new i : Player)
    {
        if(!IsPlayerConnected(i) || !PlayerInfo[i][pLoggedIn]) continue;
        if(world != -1 && GetPlayerVirtualWorld(i) != world) continue;
        if(interior != -1 && GetPlayerInterior(i) != interior) continue;
        if(IsPlayerInRangeOfPoint(i, range, x, y, z)) SendClientMessage(i, color, message);
    }
    return 1;
}

stock Float:ER_FloatMin(Float:a, Float:b)
{
	return (a < b) ? a : b;
}

stock ER_GetPlayerZone(playerid, zone[], size = sizeof(zone))
{
	new Float:x, Float:y, Float:z;
	GetPlayerPos(playerid, x, y, z);

	if(x >= 44.0 && x <= 2997.0 && y >= -2892.0 && y <= -768.0)
		format(zone, size, "Los Santos");
	else if(x >= -2997.0 && x <= -1213.0 && y >= -1115.0 && y <= 1659.0)
		format(zone, size, "San Fierro");
	else if(x >= 869.0 && x <= 2997.0 && y >= 596.0 && y <= 2997.0)
		format(zone, size, "Las Venturas");
	else
		format(zone, size, "San Andreas");

	return 1;
}
