#if defined _ER_SERVERCORE_INCLUDED
    #endinput
#endif
#define _ER_SERVERCORE_INCLUDED

stock ER_LoadServerCore()
{
    mysql_tquery(MainPipeline, "SELECT `keyname`,`value` FROM `servercore`", "ER_OnServerCoreLoad");
    mysql_tquery(MainPipeline, "SELECT * FROM `weapon_material_costs`", "ER_OnWeaponCostsLoad");
    return 1;
}

forward ER_OnServerCoreLoad();
public ER_OnServerCoreLoad()
{
    new rows, key[64], val[128];
    cache_get_row_count(rows);

    format(ServerCore[scServerName], 64, SERVER_BRAND);
    ServerCore[scWebsite][0] = EOS;
    ServerCore[scDiscord][0] = EOS;
    ServerCore[scDefaultCash] = 1000;
    ServerCore[scDefaultBank] = 9000;
    ServerCore[scDefaultSpawnX] = 1642.18;
    ServerCore[scDefaultSpawnY] = -2334.90;
    ServerCore[scDefaultSpawnZ] = 13.54;
    ServerCore[scDefaultSpawnA] = 0.0;
    ServerCore[scDefaultSpawnInt] = 0;
    ServerCore[scDefaultSpawnVW] = 0;
    ServerCore[scDefaultMaleSkin] = 26;
    ServerCore[scDefaultFemaleSkin] = 12;
    ServerCore[scJobLimitDefault] = 1;
    ServerCore[scVipHospitalTransferMinLevel] = 1;
    ServerCore[scDeathHPDecrease] = 2.0;
    ServerCore[scDeathTickMS] = 5000;
    ServerCore[scHospitalRespawnHP] = 50.0;
    ServerCore[scFamilyBackupBeaconTime] = 120;
    for(new i; i < 6; i++)
    {
        ServerCore[scVipJobLimit][i] = i + 1;
        ServerCore[scVipHospitalTime][i] = 30 - (i * 5);
        if(ServerCore[scVipHospitalTime][i] < 5) ServerCore[scVipHospitalTime][i] = 5;
    }

    for(new r; r < rows; r++)
    {
        cache_get_value_name(r, "keyname", key, sizeof(key));
        cache_get_value_name(r, "value", val, sizeof(val));
        if(!strcmp(key, "ServerName", true)) format(ServerCore[scServerName], 64, "%s", val);
        else if(!strcmp(key, "Website", true)) format(ServerCore[scWebsite], 96, "%s", val);
        else if(!strcmp(key, "Discord", true)) format(ServerCore[scDiscord], 96, "%s", val);
        else if(!strcmp(key, "DefaultCash", true)) ServerCore[scDefaultCash] = strval(val);
        else if(!strcmp(key, "DefaultBank", true)) ServerCore[scDefaultBank] = strval(val);
        else if(!strcmp(key, "DefaultSpawnX", true)) ServerCore[scDefaultSpawnX] = floatstr(val);
        else if(!strcmp(key, "DefaultSpawnY", true)) ServerCore[scDefaultSpawnY] = floatstr(val);
        else if(!strcmp(key, "DefaultSpawnZ", true)) ServerCore[scDefaultSpawnZ] = floatstr(val);
        else if(!strcmp(key, "DefaultSpawnA", true)) ServerCore[scDefaultSpawnA] = floatstr(val);
        else if(!strcmp(key, "DefaultSpawnInterior", true)) ServerCore[scDefaultSpawnInt] = strval(val);
        else if(!strcmp(key, "DefaultSpawnVW", true)) ServerCore[scDefaultSpawnVW] = strval(val);
        else if(!strcmp(key, "DefaultMaleSkin", true)) ServerCore[scDefaultMaleSkin] = strval(val);
        else if(!strcmp(key, "DefaultFemaleSkin", true)) ServerCore[scDefaultFemaleSkin] = strval(val);
        else if(!strcmp(key, "JobLimitDefault", true)) ServerCore[scJobLimitDefault] = strval(val);
        else if(!strcmp(key, "VipJobLimit0", true)) ServerCore[scVipJobLimit][0] = strval(val);
        else if(!strcmp(key, "VipJobLimit1", true)) ServerCore[scVipJobLimit][1] = strval(val);
        else if(!strcmp(key, "VipJobLimit2", true)) ServerCore[scVipJobLimit][2] = strval(val);
        else if(!strcmp(key, "VipJobLimit3", true)) ServerCore[scVipJobLimit][3] = strval(val);
        else if(!strcmp(key, "VipJobLimit4", true)) ServerCore[scVipJobLimit][4] = strval(val);
        else if(!strcmp(key, "VipJobLimit5", true)) ServerCore[scVipJobLimit][5] = strval(val);
        else if(!strcmp(key, "VipHospitalTime0", true)) ServerCore[scVipHospitalTime][0] = strval(val);
        else if(!strcmp(key, "VipHospitalTime1", true)) ServerCore[scVipHospitalTime][1] = strval(val);
        else if(!strcmp(key, "VipHospitalTime2", true)) ServerCore[scVipHospitalTime][2] = strval(val);
        else if(!strcmp(key, "VipHospitalTime3", true)) ServerCore[scVipHospitalTime][3] = strval(val);
        else if(!strcmp(key, "VipHospitalTime4", true)) ServerCore[scVipHospitalTime][4] = strval(val);
        else if(!strcmp(key, "VipHospitalTime5", true)) ServerCore[scVipHospitalTime][5] = strval(val);
        else if(!strcmp(key, "VipHospitalTransferMinLevel", true)) ServerCore[scVipHospitalTransferMinLevel] = strval(val);
        else if(!strcmp(key, "DeathHPDecrease", true)) ServerCore[scDeathHPDecrease] = floatstr(val);
        else if(!strcmp(key, "DeathTickMS", true)) ServerCore[scDeathTickMS] = strval(val);
        else if(!strcmp(key, "HospitalRespawnHP", true)) ServerCore[scHospitalRespawnHP] = floatstr(val);
        else if(!strcmp(key, "FamilyBackupBeaconTime", true)) ServerCore[scFamilyBackupBeaconTime] = strval(val);
    }
    printf("[ServerCore] Loaded %d key/value entries.", rows);
    return 1;
}

new WeaponMaterialCost[47];

forward ER_OnWeaponCostsLoad();
public ER_OnWeaponCostsLoad()
{
    new rows, weaponid, cost;
    cache_get_row_count(rows);
    for(new i; i < sizeof(WeaponMaterialCost); i++) WeaponMaterialCost[i] = 0;
    for(new r; r < rows; r++)
    {
        cache_get_value_name_int(r, "weaponid", weaponid);
        cache_get_value_name_int(r, "material_cost", cost);
        if(0 <= weaponid < sizeof(WeaponMaterialCost)) WeaponMaterialCost[weaponid] = cost;
    }
    printf("[ServerCore] Loaded %d weapon material costs.", rows);
    return 1;
}

stock ER_GetVipJobLimit(playerid)
{
    new vip = PlayerInfo[playerid][pPlayerVip];
    if(vip < 0) vip = 0;
    if(vip > 5) vip = 5;
    return ServerCore[scVipJobLimit][vip];
}

stock ER_GetVipHospitalTime(playerid)
{
    new vip = PlayerInfo[playerid][pPlayerVip];
    if(vip < 0) vip = 0;
    if(vip > 5) vip = 5;
    return ServerCore[scVipHospitalTime][vip];
}
