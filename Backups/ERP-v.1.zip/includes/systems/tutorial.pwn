#if defined _ER_TUTORIAL_INCLUDED
    #endinput
#endif
#define _ER_TUTORIAL_INCLUDED

#define MAX_TUTORIAL_STEPS 6

stock ER_StartTutorial(playerid)
{
	if(!ServerCore[scTutorialEnabled])
	{
		ER_FinishTutorial(playerid);
		return 1;
	}

	PlayerInfo[playerid][pTutorialStep] = 0;
	TogglePlayerSpectating(playerid, true);
	ER_ShowTutorialStep(playerid);
	return 1;
}

stock ER_ShowTutorialStep(playerid)
{
	new step = PlayerInfo[playerid][pTutorialStep];

	switch(step)
	{
		case 0:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming",
				"Welcome to Express Roleplay - Gaming.\n\nThis server is built for old-school heavy roleplay.\nUse realistic names, respect roleplay, and keep OOC chat separated.",
				"Next", "Skip");
		}
		case 1:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming - Roleplay",
				"Roleplay means acting as your character.\n\nUse /me for actions and /do for descriptions.\nUse /s to shout, /l to speak low, and normal chat for nearby speech.",
				"Next", "Skip");
		}
		case 2:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming - Communication",
				"Phones and radios are roleplay tools.\n\nUse /call, /pickup, /hangup, /sms, /setfreq, and /pr.\nNearby players may see you speaking into your phone or radio.",
				"Next", "Skip");
		}
		case 3:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming - Death",
				"When injured, you can request EMS or /accept death.\n\nAccepting death sends you to hospital, removes your weapons, and charges hospital fees.",
				"Next", "Skip");
		}
		case 4:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming - Economy",
				"Businesses, families, vehicles, houses, hospitals, and items are dynamic.\n\nUse /help and /stats after spawning to learn your character and commands.",
				"Next", "Skip");
		}
		default:
		{
			ShowPlayerDialog(playerid, DIALOG_TUT_STEP, DIALOG_STYLE_MSGBOX,
				"Express Roleplay - Gaming",
				"Tutorial completed.\n\nWelcome to Express Roleplay - Gaming.",
				"Spawn", "");
		}
	}
	return 1;
}

stock ER_FinishTutorial(playerid)
{
	PlayerInfo[playerid][pTutorial] = 1;
	PlayerInfo[playerid][pTutorialStep] = 0;

	if(PlayerInfo[playerid][pID] > 0)
	{
		new q[96];
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `tutorial`=1 WHERE `id`=%d", PlayerInfo[playerid][pID]);
		mysql_tquery(MainPipeline, q);
	}

	ER_SpawnCharacter(playerid);
	return 1;
}

CMD:skiptut(playerid, params[])
{
	if(!PlayerInfo[playerid][pLoggedIn])
	{
		return ER_Send(playerid, COLOR_GREY, "You must be logged in first.");
	}

	if(!ServerCore[scAllowSkipTutorial] && PlayerInfo[playerid][pAdmin] < ADMIN_MOD)
	{
		return ER_Send(playerid, COLOR_GREY, "Tutorial skipping is currently disabled.");
	}

	if(PlayerInfo[playerid][pTutorial])
	{
		return ER_Send(playerid, COLOR_GREY, "You have already completed the tutorial.");
	}

	ER_Send(playerid, COLOR_YELLOW, "Tutorial skipped. Welcome to Express Roleplay - Gaming.");
	ER_FinishTutorial(playerid);
	return 1;
}

stock ER_TutorialDialog(playerid, dialogid, response, listitem, inputtext[])
{
	#pragma unused listitem
	#pragma unused inputtext

	if(dialogid != DIALOG_TUT_STEP)
	{
		return 0;
	}

	if(!response)
	{
		if(ServerCore[scAllowSkipTutorial] || PlayerInfo[playerid][pAdmin] >= ADMIN_MOD)
		{
			ER_Send(playerid, COLOR_YELLOW, "Tutorial skipped. Welcome to Express Roleplay - Gaming.");
			ER_FinishTutorial(playerid);
			return 1;
		}

		ER_Send(playerid, COLOR_GREY, "Tutorial skipping is currently disabled.");
		ER_ShowTutorialStep(playerid);
		return 1;
	}

	PlayerInfo[playerid][pTutorialStep]++;

	if(PlayerInfo[playerid][pTutorialStep] >= MAX_TUTORIAL_STEPS)
	{
		ER_FinishTutorial(playerid);
		return 1;
	}

	ER_ShowTutorialStep(playerid);
	return 1;
}
