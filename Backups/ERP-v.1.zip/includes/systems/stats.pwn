#if defined _ER_STATS_INCLUDED
    #endinput
#endif
#define _ER_STATS_INCLUDED

stock ER_GetHospitalNameByID(hid)
{
    static name[64];
    format(name, sizeof(name), "None");
    for(new i; i < HospitalCount; i++) if(Hospitals[i][hSQLID] == hid) { format(name, sizeof(name), "%s", Hospitals[i][hName]); return name; }
    return name;
}

CMD:stats(playerid, params[])
{
    new line[256], gender[8], insurance[64];
    format(gender, sizeof(gender), PlayerInfo[playerid][pGender] == 2 ? "Female" : "Male");
    if(PlayerInfo[playerid][pHospInsurance] == NO_HOSPITAL_INSURANCE) format(insurance, sizeof(insurance), "None");
    else format(insurance, sizeof(insurance), "%s", ER_GetHospitalNameByID(PlayerInfo[playerid][pHospInsurance]));
    SendClientMessage(playerid, COLOR_ORANGE, "------------------------------------------------------------");
    format(line, sizeof(line), "%s - (Level: %d) - (Playing hours: %d) - (Gender: %s) - (Age: %d) - (Phone number: %d) - (Warnings: %d)", ER_GetName(playerid), PlayerInfo[playerid][pLevel], PlayerInfo[playerid][pPlayingHours], gender, PlayerInfo[playerid][pAge], PlayerInfo[playerid][pPhone], PlayerInfo[playerid][pWarnings]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    format(line, sizeof(line), "(Family: %d) - (Rank: %d) - (Crew: %d) - (Job 1: %d) - (VIP: %d)", PlayerInfo[playerid][pFamily], PlayerInfo[playerid][pFamilyRank], PlayerInfo[playerid][pFamilyCrew], PlayerInfo[playerid][pPlayerJob][0], PlayerInfo[playerid][pPlayerVip]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    format(line, sizeof(line), "(Total wealth: $%d) - (Cash: $%d) - (Bank balance: $%d) - (Insurance: %s) - (Married to: %s)", PlayerInfo[playerid][pCash]+PlayerInfo[playerid][pBank], PlayerInfo[playerid][pCash], PlayerInfo[playerid][pBank], insurance, PlayerInfo[playerid][pMarriedTo]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    format(line, sizeof(line), "(Respect points: %d) - (Health: %.1f) - (Armor: %.1f) - (Radio: %d kHz) - (Phonebook: %s)", PlayerInfo[playerid][pRespectPoints], PlayerInfo[playerid][pHealth], PlayerInfo[playerid][pArmor], PlayerInfo[playerid][pRadio], PlayerInfo[playerid][pPhonebook] ? "Yes" : "No");
    SendClientMessage(playerid, COLOR_WHITE, line);
    format(line, sizeof(line), "(Crimes: %d) - (Arrests: %d) - (Wanted Level: %d) - (Materials: %d) - (Pot: %d) - (Crack: %d) - (Packages: %d)", PlayerInfo[playerid][pCrimes], PlayerInfo[playerid][pArrests], PlayerInfo[playerid][pWantedLevel], PlayerInfo[playerid][pMaterials], PlayerInfo[playerid][pPot], PlayerInfo[playerid][pCrack], PlayerInfo[playerid][pPackages]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    format(line, sizeof(line), "(Rope: %d) - (Sprunk: %d) - (Spray Cans: %d) - (Seeds: %d)", PlayerInfo[playerid][pRope], PlayerInfo[playerid][pSprunk], PlayerInfo[playerid][pSprayCans], PlayerInfo[playerid][pSeeds]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    SendClientMessage(playerid, COLOR_ORANGE, "------------------------------------------------------------");
    return 1;
}
