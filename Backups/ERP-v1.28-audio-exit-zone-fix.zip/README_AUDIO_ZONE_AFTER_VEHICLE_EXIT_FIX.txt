Audio zone after vehicle exit fix

Fixed:
- If player had vehicle radio playing and exits inside an audio zone,
  the audio zone now starts immediately.
- No need to leave the zone and enter again.
- Vehicle radio still has priority while player is inside the vehicle.
