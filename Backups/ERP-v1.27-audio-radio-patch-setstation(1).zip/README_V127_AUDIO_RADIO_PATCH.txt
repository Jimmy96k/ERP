ERP v1.27 Audio/Radio + Vehicle Alias Patch

Run SQL_V127_AUDIO_RADIO_PATCH.sql once before testing.

Vehicle aliases fixed:
- /aveh inf / infer / infern -> Infernus
- /createveh inf / infer / infern -> Infernus
- /aveh nr / nrg / nrg500 -> NRG-500
- /aveh lspd -> Police Car LSPD
- /aveh swat -> S.W.A.T.

Audio/radio system added:
- /createaudio [distance]
- /editaudios
- /editaudio [id]
- /deleteaudio
- /setstation inside vehicle with Favorite Radio + category selection
