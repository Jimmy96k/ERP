#if defined _ER_FACTIONS_INCLUDED
    #endinput
#endif
#define _ER_FACTIONS_INCLUDED

#define MAX_FACTIONS 100

enum E_FACTION_INFO
{
    facSQLID,
    facName[64],
    facLeaderID,
    facLeaderName[MAX_PLAYER_NAME_EX],
    facMOTD[128],
    facEnabled
}
new Factions[MAX_FACTIONS][E_FACTION_INFO];
new FactionCount;

stock ER_LoadFactions()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `factions` WHERE `enabled`=1", "ER_OnFactionsLoad");
    return 1;
}

forward ER_OnFactionsLoad();
public ER_OnFactionsLoad()
{
    new rows;
    cache_get_row_count(rows);
    FactionCount = 0;

    for(new r; r < rows && FactionCount < MAX_FACTIONS; r++)
    {
        cache_get_value_name_int(r, "id", Factions[FactionCount][facSQLID]);
        cache_get_value_name(r, "name", Factions[FactionCount][facName], 64);
        cache_get_value_name_int(r, "leader_id", Factions[FactionCount][facLeaderID]);
        cache_get_value_name(r, "leader_name", Factions[FactionCount][facLeaderName], MAX_PLAYER_NAME_EX);
        cache_get_value_name(r, "motd", Factions[FactionCount][facMOTD], 128);
        cache_get_value_name_int(r, "color", Factions[FactionCount][facColor]);
        cache_get_value_name_int(r, "radio_color", Factions[FactionCount][facRadioColor]);
        cache_get_value_name_int(r, "enabled", Factions[FactionCount][facEnabled]);
        if(Factions[FactionCount][facColor] == 0) Factions[FactionCount][facColor] = COLOR_BLUE;
        if(Factions[FactionCount][facRadioColor] == 0) Factions[FactionCount][facRadioColor] = COLOR_BLUE;
        FactionCount++;
    }

    printf("[Factions] Loaded %d factions.", FactionCount);
    return 1;
}

CMD:createfaction(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createfaction [name]");

    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `factions` (`name`,`leader_id`,`leader_name`,`motd`,`color`,`radio_color`,`safe_deposit_rank`,`safe_withdraw_rank`,`locker_deposit_rank`,`locker_withdraw_rank`,`locker_gun_rank`,`enabled`) VALUES ('%e',0,'Nobody','Welcome to the faction.',0x3399FFFF,0x3399FFFF,1,6,1,6,1,1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnFactionCreated", "i", playerid);
    return 1;
}

forward ER_OnFactionCreated(playerid);
public ER_OnFactionCreated(playerid)
{
    new fid = cache_insert_id(), q[1024];

    for(new r = 1; r <= 6; r++)
    {
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_ranks` (`faction_id`,`rank_id`,`rank_name`) VALUES (%d,%d,'Rank %d')", fid, r, r);
        mysql_tquery(MainPipeline, q);
    }

    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_divisions` (`faction_id`,`division_id`,`division_name`) VALUES (%d,1,'Default Division')", fid);
    mysql_tquery(MainPipeline, q);

    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_lockers` (`faction_id`,`materials`,`enabled`) VALUES (%d,10000,1)", fid);
    mysql_tquery(MainPipeline, q, "ER_OnDefaultFactionLocker", "i", fid);

    ER_LoadFactions();
    ER_Send(playerid, COLOR_GREEN, "Faction created with 6 ranks, 1 division, 1 locker and default materials.");
    ER_ShowFactionEditor(playerid, fid);
    return 1;
}

forward ER_OnDefaultFactionLocker(fid);
public ER_OnDefaultFactionLocker(fid)
{
    new lockerid = cache_insert_id(), q[256];

    for(new w; w < 10; w++)
    {
        new weapon = (w == 0) ? 22 : ((w == 1) ? 23 : ((w == 2) ? 29 : 0));
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_locker_guns` (`locker_id`,`weaponid`,`admin_enabled`,`leader_enabled`) VALUES (%d,%d,1,1)", lockerid, weapon);
        mysql_tquery(MainPipeline, q);
    }
    return 1;
}

CMD:editfactions(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");

    new list[2048];
    for(new i; i < FactionCount; i++)
    {
        format(list, sizeof(list), "%s%d | %s | Leader: %s\n", list, Factions[i][facSQLID], Factions[i][facName], Factions[i][facLeaderName]);
    }

    if(!FactionCount) return ER_Send(playerid, COLOR_GREY, "No factions found.");
    ShowPlayerDialog(playerid, DIALOG_FACTION_LIST, DIALOG_STYLE_LIST, "Select Faction", list, "Edit", "Cancel");
    return 1;
}

stock ER_ShowFactionEditor(playerid, fid)
{
    new q[160];
    SetPVarInt(playerid, "EditingFaction", fid);
    mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `factions` WHERE `id`=%d LIMIT 1", fid);
    mysql_tquery(MainPipeline, q, "ER_OnShowFactionEditor", "i", playerid);
    return 1;
}

forward ER_OnShowFactionEditor(playerid);
public ER_OnShowFactionEditor(playerid)
{
    new rows, fid, name[64], leaderid, leader[24], motd[128], list[1200], color, radiocolor;
    cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "Faction not found.");

    cache_get_value_name_int(0, "id", fid);
    cache_get_value_name(0, "name", name, sizeof(name));
    cache_get_value_name_int(0, "leader_id", leaderid);
    cache_get_value_name(0, "leader_name", leader, sizeof(leader));
    cache_get_value_name(0, "motd", motd, sizeof(motd));
    cache_get_value_name_int(0, "color", color);
    cache_get_value_name_int(0, "radio_color", radiocolor);
    if(color == 0) color = COLOR_BLUE;
    if(radiocolor == 0) radiocolor = COLOR_BLUE;

    if(leaderid == 0 || isnull(leader)) format(leader, sizeof(leader), "Nobody");
    if(isnull(motd)) format(motd, sizeof(motd), "None");

    format(list, sizeof(list),
        "Name: %s\nLeader: %s\nMOTD: %s\nFaction Color\nFaction Radio Color\nRanks\nDivisions\nLockers\nSafes\nPermissions\nStatus\nSave & Reload",
        name, leader, motd);
    ShowPlayerDialog(playerid, DIALOG_FACTION_EDITOR, DIALOG_STYLE_LIST, "Faction Editor", list, "Select", "Close");
    return 1;
}

CMD:editfaction(playerid, params[])
{
    new fid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", fid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editfaction [id]");
    return ER_ShowFactionEditor(playerid, fid);
}

stock ER_SaveFactionText(playerid, field, const value[])
{
    new fid = GetPVarInt(playerid, "EditingFaction"), q[256];
    if(field == 1) mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `name`='%e' WHERE `id`=%d", value, fid);
    else mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `motd`='%e' WHERE `id`=%d", value, fid);
    mysql_tquery(MainPipeline, q, "ER_LoadFactions");
    ER_Send(playerid, COLOR_GREEN, "Faction updated.");
    ER_ShowFactionEditor(playerid, fid);
    return 1;
}

forward ER_OnFactionLeaderName(playerid, sqlid, fid);
public ER_OnFactionLeaderName(playerid, sqlid, fid)
{
    new rows, name[24], q[256];
    cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "No account found with that SQL ID.");
    cache_get_value_name(0, "username", name, sizeof(name));
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `leader_id`=%d,`leader_name`='%e' WHERE `id`=%d", sqlid, name, fid);
    mysql_tquery(MainPipeline, q, "ER_LoadFactions");
    ER_Send(playerid, COLOR_GREEN, "Faction leader updated.");
    return ER_ShowFactionEditor(playerid, fid);
}


CMD:fr(playerid, params[])
{
    if(PlayerInfo[playerid][pFaction] == INVALID_FACTION_ID) return ER_Send(playerid, COLOR_GREY, "You are not in a faction.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /fr [message]");

    new msg[160], sendcolor = COLOR_BLUE;
    new facidx = ER_FindFactionIndexBySQLID(PlayerInfo[playerid][pFaction]);
    if(facidx != -1 && Factions[facidx][facRadioColor] != 0) sendcolor = Factions[facidx][facRadioColor];

    format(msg, sizeof(msg), "(( Faction )) %s: %s", ER_GetName(playerid), params);
    foreach(new i : Player)
    {
        if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pFaction] == PlayerInfo[playerid][pFaction])
        {
            SendClientMessage(i, sendcolor, msg);
        }
    }
    return 1;
}
alias:fr("factionradio")

stock ER_FactionDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_FACTION_LIST)
    {
        if(response && listitem >= 0 && listitem < FactionCount)
        {
            ER_ShowFactionEditor(playerid, Factions[listitem][facSQLID]);
        }
        return 1;
    }

    if(dialogid == DIALOG_FACTION_EDITOR)
    {
        if(!response) return 1;
        new fid = GetPVarInt(playerid, "EditingFaction");

        switch(listitem)
        {
            case 0:
            {
                SetPVarInt(playerid, "FactionInputField", 1);
                ShowPlayerDialog(playerid, DIALOG_FACTION_INPUT, DIALOG_STYLE_INPUT, "Faction Name", "Enter new faction name:", "Save", "Back");
            }
            case 1: ShowPlayerDialog(playerid, DIALOG_FACTION_LEADER_TYPE, DIALOG_STYLE_LIST, "Faction Leader", "Online Player\nOffline Player SQL ID\nClear Leader", "Select", "Back");
            case 2:
            {
                SetPVarInt(playerid, "FactionInputField", 2);
                ShowPlayerDialog(playerid, DIALOG_FACTION_INPUT, DIALOG_STYLE_INPUT, "Faction MOTD", "Enter new faction MOTD:", "Save", "Back");
            }
            case 3:
            {
                SetPVarInt(playerid, "FactionColorField", 1);
                ER_ShowNamedColorDialog(playerid, DIALOG_FACTION_COLOR_SELECT, "Faction Color");
            }
            case 4:
            {
                SetPVarInt(playerid, "FactionColorField", 2);
                ER_ShowNamedColorDialog(playerid, DIALOG_FACTION_COLOR_SELECT, "Faction Radio Color");
            }
            case 5: ShowPlayerDialog(playerid, DIALOG_FACTION_RANKS, DIALOG_STYLE_MSGBOX, "Faction Ranks", "Rank editor foundation is ready.\nFull rank rename/manage dialog comes next.", "Back", "");
            case 6: ShowPlayerDialog(playerid, DIALOG_FACTION_DIVISIONS, DIALOG_STYLE_MSGBOX, "Faction Divisions", "Division editor foundation is ready.\nFull division rename/manage dialog comes next.", "Back", "");
            case 7: ShowPlayerDialog(playerid, DIALOG_FACTION_LOCKERS, DIALOG_STYLE_MSGBOX, "Faction Lockers", "Locker editor foundation is ready.\nGuns/materials management comes next.", "Back", "");
            case 8: ShowPlayerDialog(playerid, DIALOG_FACTION_SAFES, DIALOG_STYLE_MSGBOX, "Faction Safes", "Safe editor foundation is ready.\nDeposit/withdraw positions come next.", "Back", "");
            case 9: ShowPlayerDialog(playerid, DIALOG_FACTION_PERMS, DIALOG_STYLE_MSGBOX, "Faction Permissions", "Permission editor foundation is ready.\nSafe/locker rank permissions comes next.", "Back", "");
            case 10:
            {
                new q[128];
                mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `enabled`=IF(`enabled`=1,0,1) WHERE `id`=%d", fid);
                mysql_tquery(MainPipeline, q, "ER_LoadFactions");
                ER_Send(playerid, COLOR_GREEN, "Faction status toggled.");
                ER_ShowFactionEditor(playerid, fid);
            }
            case 11:
            {
                ER_LoadFactions();
                ER_Send(playerid, COLOR_GREEN, "Factions reloaded.");
                ER_ShowFactionEditor(playerid, fid);
            }
        }
        return 1;
    }

    if(dialogid == DIALOG_FACTION_COLOR_SELECT)
    {
        if(!response) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));

        new fid = GetPVarInt(playerid, "EditingFaction"), field = GetPVarInt(playerid, "FactionColorField"), q[160];
        new color = ER_GetNamedColorValue(listitem);

        if(field == 1)
        {
            mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `color`=%d WHERE `id`=%d", color, fid);
            ER_Send(playerid, color, "Faction color updated.");
        }
        else
        {
            mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `radio_color`=%d WHERE `id`=%d", color, fid);
            ER_Send(playerid, color, "Faction radio color updated.");
        }

        mysql_tquery(MainPipeline, q, "ER_LoadFactions");
        return ER_ShowFactionEditor(playerid, fid);
    }

    if(dialogid == DIALOG_FACTION_INPUT)
    {
        if(!response) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        return ER_SaveFactionText(playerid, GetPVarInt(playerid, "FactionInputField"), inputtext);
    }

    if(dialogid == DIALOG_FACTION_LEADER_TYPE)
    {
        if(!response) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        if(listitem == 0)
        {
            new list[1024], count, pvarname[24], name[MAX_PLAYER_NAME];
            list[0] = EOS;
            foreach(new i : Player)
            {
                if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pID] > 0)
                {
                    GetPlayerName(i, name, sizeof(name));
                    format(pvarname, sizeof(pvarname), "FacLeadOnline%d", count);
                    SetPVarInt(playerid, pvarname, i);
                    format(list, sizeof(list), "%s%d\t%s\tSQL ID: %d\n", list, i, name, PlayerInfo[i][pID]);
                    count++;
                }
            }
            if(!count) return ER_Send(playerid, COLOR_GREY, "No online players found.");
            return ShowPlayerDialog(playerid, DIALOG_FACTION_LEADER_ONLINE, DIALOG_STYLE_TABLIST, "Select Online Leader", list, "Select", "Back");
        }
        if(listitem == 1) return ShowPlayerDialog(playerid, DIALOG_FACTION_LEADER_OFFLINE, DIALOG_STYLE_INPUT, "Offline Leader", "Enter player SQL ID:", "Save", "Back");

        new q[128], fid = GetPVarInt(playerid, "EditingFaction");
        mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `leader_id`=0,`leader_name`='Nobody' WHERE `id`=%d", fid);
        mysql_tquery(MainPipeline, q, "ER_LoadFactions");
        ER_Send(playerid, COLOR_GREEN, "Faction leader cleared.");
        return ER_ShowFactionEditor(playerid, fid);
    }

    if(dialogid == DIALOG_FACTION_LEADER_ONLINE)
    {
        if(!response) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        new pvarname[24]; format(pvarname, sizeof(pvarname), "FacLeadOnline%d", listitem);
        new target = GetPVarInt(playerid, pvarname);
        if(!IsPlayerConnected(target) || PlayerInfo[target][pID] <= 0) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        return ER_GetAccountNameBySQL(playerid, PlayerInfo[target][pID], "ER_OnFactionLeaderName", GetPVarInt(playerid, "EditingFaction"));
    }

    if(dialogid == DIALOG_FACTION_LEADER_OFFLINE)
    {
        if(!response) return ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        new sqlid = strval(inputtext);
        if(sqlid <= 0) return ER_Send(playerid, COLOR_GREY, "Invalid SQL ID.");
        return ER_GetAccountNameBySQL(playerid, sqlid, "ER_OnFactionLeaderName", GetPVarInt(playerid, "EditingFaction"));
    }

    if(dialogid == DIALOG_FACTION_RANKS || dialogid == DIALOG_FACTION_DIVISIONS || dialogid == DIALOG_FACTION_LOCKERS || dialogid == DIALOG_FACTION_SAFES || dialogid == DIALOG_FACTION_PERMS)
    {
        ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        return 1;
    }

    return 0;
}

// Login MOTD helpers merged here so no separate login_motd include is required.
stock ER_FindFamilyIndexBySQLID(fid)
{
    for(new i; i < FamilyCount; i++)
    {
        if(Families[i][fSQLID] == fid) return i;
    }
    return -1;
}

stock ER_FindFactionIndexBySQLID(fid)
{
    for(new i; i < FactionCount; i++)
    {
        if(Factions[i][facSQLID] == fid) return i;
    }
    return -1;
}

stock ER_ShowLoginMOTDs(playerid)
{
    new msg[192];

    if(PlayerInfo[playerid][pFamily] != INVALID_FAMILY_ID && PlayerInfo[playerid][pFamily] > 0)
    {
        new famidx = ER_FindFamilyIndexBySQLID(PlayerInfo[playerid][pFamily]);
        if(famidx != -1)
        {
            format(msg, sizeof(msg), "Family MOTD: %s", Families[famidx][fMOTD]);
            SendClientMessage(playerid, Families[famidx][fColor], msg);
        }
    }

    if(PlayerInfo[playerid][pFaction] != INVALID_FACTION_ID && PlayerInfo[playerid][pFaction] > 0)
    {
        new facidx = ER_FindFactionIndexBySQLID(PlayerInfo[playerid][pFaction]);
        if(facidx != -1)
        {
            format(msg, sizeof(msg), "Faction MOTD: %s", Factions[facidx][facMOTD]);
            SendClientMessage(playerid, Factions[facidx][facColor], msg);
        }
    }

    if(PlayerInfo[playerid][pAdmin] >= ADMIN_MOD)
    {
        SendClientMessage(playerid, COLOR_YELLOW, "Admin MOTD: None");
    }

    return 1;
}
