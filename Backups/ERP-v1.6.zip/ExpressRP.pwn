#pragma dynamic 65536

#include <a_samp>
#include <a_mysql>
#include <sscanf2>
#include <Pawn.CMD>
#include <streamer>
#include <foreach>
#include <whirlpool>

#include "includes/core/defines.pwn"
#include "includes/core/colors.pwn"
#include "includes/core/enums.pwn"
#include "includes/core/utils.pwn"
#include "includes/core/mysql.pwn"
#include "includes/core/servercore.pwn"
#include "includes/core/accounts.pwn"
#include "includes/core/savechars.pwn"
#include "includes/systems/tutorial.pwn"
#include "includes/systems/admin.pwn"
#include "includes/systems/stats.pwn"
#include "includes/systems/help.pwn"
#include "includes/systems/chat.pwn"
#include "includes/systems/phone.pwn"
#include "includes/systems/radio.pwn"
#include "includes/systems/inventory.pwn"
#include "includes/systems/weapons.pwn"
#include "includes/systems/vehicles.pwn"
#include "includes/systems/hospitals.pwn"
#include "includes/systems/death.pwn"
#include "includes/systems/businesses.pwn"
#include "includes/systems/families.pwn"

main() { }

public OnGameModeInit()
{
    SetGameModeText("Express Roleplay - Gaming");
    ShowPlayerMarkers(PLAYER_MARKERS_MODE_GLOBAL);
    UsePlayerPedAnims();
    DisableInteriorEnterExits();
    ER_CreateLoginTextDraws();

    ER_MySQLConnect();
    ER_LoadServerCore();
    ER_LoadHospitals();
    ER_LoadHospitalBeds();
    ER_LoadAudioStreams();
    ER_LoadBusinesses();
    ER_LoadFamilies();
    ER_LoadVehicles();
    return 1;
}

public OnGameModeExit()
{
    foreach(new i : Player) ER_SaveCharacter(i);
    ER_MySQLClose();
    return 1;
}

public OnPlayerConnect(playerid)
{
    ER_ResetPlayer(playerid);
    TogglePlayerSpectating(playerid, true);
    ER_ShowLoginScreen(playerid);
    ER_ShowLoginOrRegister(playerid);
    return 1;
}

public OnPlayerDisconnect(playerid, reason)
{
    ER_SaveCharacter(playerid);
    ER_ClearPhoneState(playerid);
    ER_ClearFamilyBeacon(playerid);
    ER_ReleaseHospitalBed(playerid);
    return 1;
}

public OnPlayerSpawn(playerid)
{
    if(PlayerInfo[playerid][pLoggedIn])
    {
        SetPlayerHealth(playerid, PlayerInfo[playerid][pHealth]);
        SetPlayerArmour(playerid, PlayerInfo[playerid][pArmor]);
        ER_GiveSavedWeapons(playerid);
    }
    return 1;
}

public OnPlayerText(playerid, text[])
{
    if(!PlayerInfo[playerid][pLoggedIn]) return 0;
    if(ER_PhoneText(playerid, text)) return 0;
    ER_LocalChat(playerid, text, CHAT_RANGE_NORMAL);
    return 0;
}

public OnPlayerDeath(playerid, killerid, reason)
{
    ER_StartInjured(playerid, killerid, reason);
    return 1;
}

public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[])
{
    if(ER_AccountDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_TutorialDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_HospitalDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_BusinessDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_FamilyDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_AudioDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    if(ER_VehicleDialog(playerid, dialogid, response, listitem, inputtext)) return 1;
    return 0;
}


public OnPlayerRequestClass(playerid, classid)
{
	#pragma unused classid
	if(PlayerInfo[playerid][pLoggedIn])
	{
		ER_SpawnCharacter(playerid);
	}
	else
	{
		TogglePlayerSpectating(playerid, true);
		ER_ShowLoginScreen(playerid);
	}
	return 0;
}
