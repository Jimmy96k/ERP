ERP v1.28 Login MOTD merged cleanup

Changed:
- Removed includes/systems/login_motd.pwn.
- Removed #include "includes/systems/login_motd.pwn" from ExpressRP.pwn.
- Merged ER_ShowLoginMOTDs and helper functions into includes/systems/factions.pwn.

Reason:
- The login/save system is included before family/faction arrays are declared.
- Keeping the function implementation after families/factions prevents undefined symbol issues.
- Login still calls ER_ShowLoginMOTDs after successful login.
