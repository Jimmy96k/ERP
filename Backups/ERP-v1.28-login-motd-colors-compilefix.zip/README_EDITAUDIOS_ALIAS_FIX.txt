Pawn.CMD alias fix:
- Removed alias:editaudio("editaudios") because CMD:editaudios already exists.
- /editaudio remains the main command.
- /editaudios still works because it is already a real command in radio.pwn.
