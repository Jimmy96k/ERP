ERP v1.28 Login MOTD + Color Name Patch

Added:
- Clears player chat after successful login, before welcome/MOTD messages.
- Shows:
  - Family MOTD if the player is in a family.
  - Faction MOTD if the player is in a faction.
  - Admin MOTD if the player is admin.
- Added family editor color menus:
  - Family Color
  - Family Radio Color
- Added faction editor color menus:
  - Faction Color
  - Faction Radio Color
- Colors are selected by name from colored text list, not typed as hex.
- /f uses Family Radio Color.
- /fr /factionradio uses Faction Radio Color.

SQL:
- Run SQL_V128_MOTD_COLORS_PATCH.sql once.
