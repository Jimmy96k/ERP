MOTD compile fix:
- Added facColor/facRadioColor to the local faction enum in includes/systems/factions.pwn.
- Added missing constants fallback:
  COLOR_BLUE
  INVALID_FACTION_ID
  INVALID_FAMILY_ID
- Replaced unsafe faction none checks with <= 0 where needed.
- Login MOTD still supports Family MOTD, Faction MOTD, and Admin MOTD.
