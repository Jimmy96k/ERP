#if defined _ER_BUSINESSES_INCLUDED
    #endinput
#endif
#define _ER_BUSINESSES_INCLUDED

#define BUSINESS_TYPE_247        1
#define BUSINESS_TYPE_RESTAURANT 2
#define BUSINESS_TYPE_CLOTHES    3
#define BUSINESS_TYPE_GUNSTORE   4
#define BUSINESS_TYPE_DEALERSHIP 5
#define BUSINESS_TYPE_BAR        6
#define BUSINESS_TYPE_GAS        7
#define BUSINESS_TYPE_BANK       8
#define BUSINESS_TYPE_GYM        9

#define BUSINESS_OWNER_NONE      0
#define BUSINESS_OWNER_PLAYER    1
#define BUSINESS_OWNER_FAMILY    2
#define BUSINESS_OWNER_FACTION   3

new ER_BuyProductID[MAX_PLAYERS][64];
new ER_BuyProductCount[MAX_PLAYERS];
new ER_BuyBusinessSQL[MAX_PLAYERS];
new ER_ClothesSelectedSkin[MAX_PLAYERS];
new ER_ToyCatalogSelected[MAX_PLAYERS];

stock ER_GetBusinessTypeName(type, dest[], size = sizeof(dest))
{
    switch(type)
    {
        case BUSINESS_TYPE_247: format(dest, size, "24/7 Store");
        case BUSINESS_TYPE_RESTAURANT: format(dest, size, "Restaurant");
        case BUSINESS_TYPE_CLOTHES: format(dest, size, "Clothes Store");
        case BUSINESS_TYPE_GUNSTORE: format(dest, size, "Gun Store");
        case BUSINESS_TYPE_DEALERSHIP: format(dest, size, "Dealership");
        case BUSINESS_TYPE_BAR: format(dest, size, "Bar / Club");
        case BUSINESS_TYPE_GAS: format(dest, size, "Gas Station");
        case BUSINESS_TYPE_BANK: format(dest, size, "Bank");
        case BUSINESS_TYPE_GYM: format(dest, size, "Gym");
        default: format(dest, size, "Unknown");
    }
    return 1;
}

stock ER_ShowBusinessTypes(playerid)
{
    return ER_Send(playerid, COLOR_GREY, "USAGE: /createbusiness [type/id] | Types: 1-24/7, 2-Restaurant, 3-Clothes, 4-Gun, 5-Dealership, 6-Bar, 7-Gas, 8-Bank, 9-Gym");
}

stock ER_ParseBusinessType(const src[])
{
    if(isnull(src)) return 0;
    if(src[0] >= '0' && src[0] <= '9')
    {
        new id = strval(src);
        if(id >= 1 && id <= 9) return id;
    }
    if(!strcmp(src, "247", true) || !strcmp(src, "24/7", true) || !strcmp(src, "store", true)) return BUSINESS_TYPE_247;
    if(!strcmp(src, "restaurant", true) || !strcmp(src, "food", true)) return BUSINESS_TYPE_RESTAURANT;
    if(!strcmp(src, "clothes", true) || !strcmp(src, "clothing", true)) return BUSINESS_TYPE_CLOTHES;
    if(!strcmp(src, "gun", true) || !strcmp(src, "guns", true) || !strcmp(src, "gunstore", true)) return BUSINESS_TYPE_GUNSTORE;
    if(!strcmp(src, "dealership", true) || !strcmp(src, "dealer", true)) return BUSINESS_TYPE_DEALERSHIP;
    if(!strcmp(src, "bar", true) || !strcmp(src, "club", true)) return BUSINESS_TYPE_BAR;
    if(!strcmp(src, "gas", true) || !strcmp(src, "fuel", true)) return BUSINESS_TYPE_GAS;
    if(!strcmp(src, "bank", true)) return BUSINESS_TYPE_BANK;
    if(!strcmp(src, "gym", true)) return BUSINESS_TYPE_GYM;
    return 0;
}

stock ER_DefaultBusinessPrice(type, const zone[])
{
    new base;
    switch(type)
    {
        case BUSINESS_TYPE_247: base = 300000;
        case BUSINESS_TYPE_RESTAURANT: base = 450000;
        case BUSINESS_TYPE_CLOTHES: base = 500000;
        case BUSINESS_TYPE_GUNSTORE: base = 900000;
        case BUSINESS_TYPE_DEALERSHIP: base = 2000000;
        case BUSINESS_TYPE_BAR: base = 750000;
        case BUSINESS_TYPE_GAS: base = 1000000;
        case BUSINESS_TYPE_BANK: base = 3000000;
        case BUSINESS_TYPE_GYM: base = 650000;
        default: base = 250000;
    }
    if(strfind(zone, "Vinewood", true) != -1 || strfind(zone, "Richman", true) != -1 || strfind(zone, "Rodeo", true) != -1 || strfind(zone, "Commerce", true) != -1) base = base * 3 / 2;
    if(strfind(zone, "Idlewood", true) != -1 || strfind(zone, "Ganton", true) != -1 || strfind(zone, "Willowfield", true) != -1) base = base * 3 / 4;
    return base;
}

stock ER_DefaultBusinessPickup(type)
{
    switch(type)
    {
        case BUSINESS_TYPE_247: return 1274;
        case BUSINESS_TYPE_RESTAURANT: return 2768;
        case BUSINESS_TYPE_CLOTHES: return 1275;
        case BUSINESS_TYPE_GUNSTORE: return 1242;
        case BUSINESS_TYPE_DEALERSHIP: return 1239;
        case BUSINESS_TYPE_BAR: return 1544;
        case BUSINESS_TYPE_GAS: return 1650;
        case BUSINESS_TYPE_BANK: return 1274;
        case BUSINESS_TYPE_GYM: return 1240;
    }
    return 1274;
}

stock ER_SetBusinessInteriorDefaults(type, bid, &Float:x, &Float:y, &Float:z, &Float:a, &interior, &vw)
{
    vw = bid;
    switch(type)
    {
        case BUSINESS_TYPE_247: { x = -25.8845; y = -185.8689; z = 1003.5469; a = 0.0; interior = 17; }
        case BUSINESS_TYPE_RESTAURANT: { x = 372.3520; y = -133.5240; z = 1001.4922; a = 0.0; interior = 5; }
        case BUSINESS_TYPE_CLOTHES: { x = 204.3329; y = -168.8799; z = 1000.5234; a = 0.0; interior = 14; }
        case BUSINESS_TYPE_GUNSTORE: { x = 285.8840; y = -39.0160; z = 1001.5156; a = 0.0; interior = 1; }
        case BUSINESS_TYPE_DEALERSHIP: { x = -2158.6731; y = 641.5175; z = 1052.3750; a = 0.0; interior = 1; }
        case BUSINESS_TYPE_BAR: { x = 501.9809; y = -69.1502; z = 998.7578; a = 0.0; interior = 11; }
        case BUSINESS_TYPE_GAS: { x = -27.3123; y = -29.2776; z = 1003.5573; a = 0.0; interior = 4; }
        case BUSINESS_TYPE_BANK: { x = 2306.3826; y = -15.2365; z = 26.7496; a = 0.0; interior = 0; }
        case BUSINESS_TYPE_GYM: { x = 772.1119; y = -3.8986; z = 1000.7288; a = 0.0; interior = 5; }
        default: { x = 0.0; y = 0.0; z = 3.0; a = 0.0; interior = 0; }
    }
    return 1;
}

stock ER_FindBusinessIndexBySQLID(sqlid)
{
    for(new i; i < BusinessCount; i++) if(Businesses[i][bSQLID] == sqlid) return i;
    return -1;
}

stock ER_ClearBusinessWorld()
{
    for(new i; i < BusinessCount; i++)
    {
        if(Businesses[i][bPickupID]) DestroyDynamicPickup(Businesses[i][bPickupID]);
        if(Businesses[i][bLabelID]) DestroyDynamic3DTextLabel(Businesses[i][bLabelID]);
        Businesses[i][bPickupID] = 0;
        Businesses[i][bLabelID] = Text3D:0;
    }
    return 1;
}

stock ER_FormatBusinessLabel(idx, label[], size = sizeof(label))
{
    new typeName[32], money[32];
    ER_GetBusinessTypeName(Businesses[idx][bType], typeName, sizeof(typeName));
    format(money, sizeof(money), "%s", ER_FormatMoney(Businesses[idx][bPrice]));
    if(Businesses[idx][bOwnerType] == BUSINESS_OWNER_NONE || Businesses[idx][bOwnerID] == 0)
    {
        format(label, size, "%s For Sale!\nPrice: %s\nBusiness ID: %d", typeName, money, Businesses[idx][bSQLID]);
    }
    else
    {
        format(label, size, "%s\nOwner: %s\n%s\nBusiness ID: %d", Businesses[idx][bName], Businesses[idx][bOwnerName], Businesses[idx][bLocked] ? ("Locked") : ("Unlocked"), Businesses[idx][bSQLID]);
    }
    return 1;
}

stock ER_CreateBusinessWorld(idx)
{
    if(idx < 0 || idx >= BusinessCount) return 0;
    new label[160]; ER_FormatBusinessLabel(idx, label, sizeof(label));
    Businesses[idx][bPickupID] = CreateDynamicPickup(Businesses[idx][bPickupModel], Businesses[idx][bPickupType] ? Businesses[idx][bPickupType] : 1, Businesses[idx][bExtX], Businesses[idx][bExtY], Businesses[idx][bExtZ], Businesses[idx][bExtVW], Businesses[idx][bExtInt]);
    Businesses[idx][bLabelID] = CreateDynamic3DTextLabel(label, COLOR_YELLOW, Businesses[idx][bExtX], Businesses[idx][bExtY], Businesses[idx][bExtZ] + 0.35, 15.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, Businesses[idx][bExtVW], Businesses[idx][bExtInt]);
    return 1;
}

stock ER_LoadBusinesses()
{
    ER_ClearBusinessWorld();
    mysql_tquery(MainPipeline, "SELECT * FROM `businesses` WHERE `enabled`=1", "ER_OnBusinessesLoad");
    return 1;
}
forward ER_OnBusinessesLoad();
public ER_OnBusinessesLoad()
{
    new rows; cache_get_row_count(rows); BusinessCount = 0;
    for(new r; r < rows && BusinessCount < MAX_BUSINESSES; r++)
    {
        cache_get_value_name_int(r, "id", Businesses[BusinessCount][bSQLID]);
        cache_get_value_name(r, "name", Businesses[BusinessCount][bName], 64);
        cache_get_value_name_int(r, "type", Businesses[BusinessCount][bType]);
        cache_get_value_name_int(r, "owner_type", Businesses[BusinessCount][bOwnerType]);
        cache_get_value_name_int(r, "owner_id", Businesses[BusinessCount][bOwnerID]);
        cache_get_value_name(r, "owner_name", Businesses[BusinessCount][bOwnerName], MAX_PLAYER_NAME_EX);
        cache_get_value_name_int(r, "price", Businesses[BusinessCount][bPrice]);
        cache_get_value_name_int(r, "price_mode", Businesses[BusinessCount][bPriceMode]);
        cache_get_value_name_int(r, "materials", Businesses[BusinessCount][bMaterials]);
        cache_get_value_name_int(r, "materials_capacity", Businesses[BusinessCount][bMaterialsCapacity]);
        cache_get_value_name_int(r, "safe_balance", Businesses[BusinessCount][bSafeBalance]);
        cache_get_value_name_float(r, "ext_x", Businesses[BusinessCount][bExtX]);
        cache_get_value_name_float(r, "ext_y", Businesses[BusinessCount][bExtY]);
        cache_get_value_name_float(r, "ext_z", Businesses[BusinessCount][bExtZ]);
        cache_get_value_name_float(r, "ext_a", Businesses[BusinessCount][bExtA]);
        cache_get_value_name_int(r, "ext_int", Businesses[BusinessCount][bExtInt]);
        cache_get_value_name_int(r, "ext_vw", Businesses[BusinessCount][bExtVW]);
        cache_get_value_name_float(r, "int_x", Businesses[BusinessCount][bIntX]);
        cache_get_value_name_float(r, "int_y", Businesses[BusinessCount][bIntY]);
        cache_get_value_name_float(r, "int_z", Businesses[BusinessCount][bIntZ]);
        cache_get_value_name_float(r, "int_a", Businesses[BusinessCount][bIntA]);
        cache_get_value_name_int(r, "int_int", Businesses[BusinessCount][bIntInt]);
        cache_get_value_name_int(r, "int_vw", Businesses[BusinessCount][bIntVW]);
        cache_get_value_name_float(r, "safe_x", Businesses[BusinessCount][bSafeX]);
        cache_get_value_name_float(r, "safe_y", Businesses[BusinessCount][bSafeY]);
        cache_get_value_name_float(r, "safe_z", Businesses[BusinessCount][bSafeZ]);
        cache_get_value_name_float(r, "safe_a", Businesses[BusinessCount][bSafeA]);
        cache_get_value_name_int(r, "safe_int", Businesses[BusinessCount][bSafeInt]);
        cache_get_value_name_int(r, "safe_vw", Businesses[BusinessCount][bSafeVW]);
        cache_get_value_name_int(r, "pickup_model", Businesses[BusinessCount][bPickupModel]);
        cache_get_value_name_int(r, "pickup_type", Businesses[BusinessCount][bPickupType]);
        cache_get_value_name_int(r, "locked", Businesses[BusinessCount][bLocked]);
        cache_get_value_name_int(r, "enabled", Businesses[BusinessCount][bEnabled]);
        ER_CreateBusinessWorld(BusinessCount);
        BusinessCount++;
    }
    printf("[Businesses] Loaded %d businesses.", BusinessCount);
    return 1;
}

CMD:createbusiness(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new type = ER_ParseBusinessType(params);
    if(!type) return ER_ShowBusinessTypes(playerid);
    new Float:x, Float:y, Float:z, Float:a, zone[32], typeName[32];
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a); ER_GetPlayerZone(playerid, zone, sizeof(zone)); ER_GetBusinessTypeName(type, typeName, sizeof(typeName));
    new price = ER_DefaultBusinessPrice(type, zone), pickup = ER_DefaultBusinessPickup(type);
    new q[768];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `businesses` (`name`,`type`,`owner_type`,`owner_id`,`owner_name`,`price`,`price_mode`,`materials`,`materials_capacity`,`safe_balance`,`ext_x`,`ext_y`,`ext_z`,`ext_a`,`ext_int`,`ext_vw`,`pickup_model`,`pickup_type`,`locked`,`enabled`) VALUES ('%e',%d,0,0,'Nobody',%d,0,0,2000,0,%f,%f,%f,%f,%d,%d,%d,1,0,1)", typeName, type, price, x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid), pickup);
    mysql_tquery(MainPipeline, q, "ER_OnBusinessCreated", "ii", playerid, type);
    return 1;
}
forward ER_OnBusinessCreated(playerid, type);
public ER_OnBusinessCreated(playerid, type)
{
    new bid = cache_insert_id();
    new Float:x, Float:y, Float:z, Float:a, interior, vw;
    ER_SetBusinessInteriorDefaults(type, bid, x, y, z, a, interior, vw);
    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `int_x`=%f,`int_y`=%f,`int_z`=%f,`int_a`=%f,`int_int`=%d,`int_vw`=%d WHERE `id`=%d", x, y, z, a, interior, vw, bid);
    mysql_tquery(MainPipeline, q);
    ER_CreateDefBusinessProducts(bid, type);
    ER_LoadBusinesses();
    ER_Send(playerid, COLOR_GREEN, "Business created. Use /editbusiness [id] to edit it.");
    return 1;
}

stock ER_CreateDefBusinessProducts(businessid, type)
{
    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `business_products` (`business_id`,`catalog_id`,`product_name`,`product_key`,`price`,`material_cost`,`stock`,`stock_capacity`,`admin_enabled`,`owner_enabled`) SELECT %d,`id`,`product_name`,`product_key`,`price`,`material_cost`,`default_stock_capacity`,`default_stock_capacity`,1,1 FROM `business_product_catalog` WHERE `business_type`=%d AND `enabled`=1", businessid, type);
    mysql_tquery(MainPipeline, q);
    return 1;
}

stock ER_GetNearestBusiness(playerid, bool:inside = true)
{
    new vw = GetPlayerVirtualWorld(playerid), interior = GetPlayerInterior(playerid);
    new Float:px, Float:py, Float:pz; GetPlayerPos(playerid, px, py, pz);
    for(new i; i < BusinessCount; i++)
    {
        if(inside && vw == Businesses[i][bIntVW] && interior == Businesses[i][bIntInt]) return i;
        if(IsPlayerInRangeOfPoint(playerid, 3.0, Businesses[i][bExtX], Businesses[i][bExtY], Businesses[i][bExtZ]) && vw == Businesses[i][bExtVW] && interior == Businesses[i][bExtInt]) return i;
    }
    return -1;
}

CMD:enter(playerid, params[])
{
    new idx = ER_GetNearestBusiness(playerid, false);
    if(idx != -1)
    {
        if(Businesses[idx][bLocked]) return ER_Send(playerid, COLOR_GREY, "This business is locked.");
        SetPlayerInterior(playerid, Businesses[idx][bIntInt]); SetPlayerVirtualWorld(playerid, Businesses[idx][bIntVW]); SetPlayerPos(playerid, Businesses[idx][bIntX], Businesses[idx][bIntY], Businesses[idx][bIntZ]); SetPlayerFacingAngle(playerid, Businesses[idx][bIntA]);
        return 1;
    }
    if(ER_TryEnterHouse(playerid)) return 1;
    if(ER_TryEnterDoor(playerid)) return 1;
    return ER_Send(playerid, COLOR_GREY, "You are not near an entrance.");
}
CMD:exit(playerid, params[])
{
    new vw = GetPlayerVirtualWorld(playerid), interior = GetPlayerInterior(playerid);
    for(new i; i < BusinessCount; i++) if(vw == Businesses[i][bIntVW] && interior == Businesses[i][bIntInt])
    {
        SetPlayerInterior(playerid, Businesses[i][bExtInt]); SetPlayerVirtualWorld(playerid, Businesses[i][bExtVW]); SetPlayerPos(playerid, Businesses[i][bExtX], Businesses[i][bExtY], Businesses[i][bExtZ]); SetPlayerFacingAngle(playerid, Businesses[i][bExtA]); return 1;
    }
    if(ER_TryExitHouse(playerid)) return 1;
    if(ER_TryExitDoor(playerid)) return 1;
    return ER_Send(playerid, COLOR_GREY, "You are not inside an exit.");
}

CMD:buy(playerid, params[])
{
    new idx = ER_GetNearestBusiness(playerid, true);
    if(idx == -1) return ER_Send(playerid, COLOR_GREY, "You are not inside or near a business.");
    ER_BuyBusinessSQL[playerid] = Businesses[idx][bSQLID];
    if(Businesses[idx][bType] == BUSINESS_TYPE_CLOTHES)
    {
        ShowPlayerDialog(playerid, DIALOG_BUY_CLOTHES_TOYS, DIALOG_STYLE_LIST, "Clothes Store", "Clothes - $500\nToys - $1000+", "Select", "Cancel");
        return 1;
    }
    new q[256];
    mysql_format(MainPipeline, q, sizeof(q), "SELECT id,product_name,price,stock FROM `business_products` WHERE `business_id`=%d AND `admin_enabled`=1 AND `owner_enabled`=1 ORDER BY id ASC LIMIT 64", Businesses[idx][bSQLID]);
    mysql_tquery(MainPipeline, q, "ER_ShowBuyProducts", "i", playerid);
    return 1;
}
forward ER_ShowBuyProducts(playerid);
public ER_ShowBuyProducts(playerid)
{
    if(!IsPlayerConnected(playerid)) return 1;
    new rows; cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "This business has no products available.");
    new list[2048], name[64], price, stock, id;
    ER_BuyProductCount[playerid] = 0;
    for(new r; r < rows && r < 64; r++)
    {
        cache_get_value_name_int(r, "id", id);
        cache_get_value_name(r, "product_name", name, sizeof(name));
        cache_get_value_name_int(r, "price", price);
        cache_get_value_name_int(r, "stock", stock);
        ER_BuyProductID[playerid][r] = id;
        format(list, sizeof(list), "%s%s - %s - Stock: %d\n", list, name, ER_FormatMoney(price), stock);
        ER_BuyProductCount[playerid]++;
    }
    ShowPlayerDialog(playerid, DIALOG_BUY_PRODUCTS, DIALOG_STYLE_LIST, "Buy Products", list, "Buy", "Cancel");
    return 1;
}

stock ER_ShowBusinessEditor(playerid, bid)
{
    SetPVarInt(playerid, "EditingBusiness", bid);
    ShowPlayerDialog(playerid, DIALOG_BUSINESS_EDITOR, DIALOG_STYLE_LIST, "Business Editor", "Name\nType\nOwner Type\nOwner ID\nPrice\nExterior Position\nInterior Position\nSelect Interior\nSafe Position\nMaterials\nSafe Balance\nManage Products\nPickup Icon\nToggle Locked\nToggle Status\nReload This Business\nDelete Business", "Select", "Close");
    return 1;
}

CMD:editbusinesses(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new list[2048], typeName[32];
    for(new i; i < BusinessCount; i++) { ER_GetBusinessTypeName(Businesses[i][bType], typeName, sizeof(typeName)); format(list, sizeof(list), "%s%d | %s | %s\n", list, Businesses[i][bSQLID], Businesses[i][bName], typeName); }
    ShowPlayerDialog(playerid, DIALOG_BUSINESS_LIST, DIALOG_STYLE_LIST, "Select Business", list, "Edit", "Cancel");
    return 1;
}

CMD:editbusiness(playerid, params[])
{
    new bid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", bid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editbusiness [id]");
    return ER_ShowBusinessEditor(playerid, bid);
}

CMD:mybusinesses(playerid, params[])
{
    new count, msg[144], list[1024];
    for(new i; i < BusinessCount; i++) if(Businesses[i][bOwnerType] == BUSINESS_OWNER_PLAYER && Businesses[i][bOwnerID] == PlayerInfo[playerid][pID])
    {
        format(list, sizeof(list), "%s%d - %s (ID %d)\n", list, ++count, Businesses[i][bName], Businesses[i][bSQLID]);
    }
    if(!count) return ER_Send(playerid, COLOR_GREY, "You do not own any businesses.");
    format(msg, sizeof(msg), "Your Businesses (%d/%d)", count, ER_GetMaxBusinesses(playerid));
    ShowPlayerDialog(playerid, DIALOG_BUSINESS_LIST, DIALOG_STYLE_LIST, msg, list, "Close", "");
    return 1;
}

CMD:businesssettings(playerid, params[])
{
    new idx = ER_GetNearestBusiness(playerid, true);
    if(idx == -1) return ER_Send(playerid, COLOR_GREY, "You are not inside your business.");
    if(Businesses[idx][bOwnerType] != BUSINESS_OWNER_PLAYER || Businesses[idx][bOwnerID] != PlayerInfo[playerid][pID]) return ER_Send(playerid, COLOR_GREY, "You do not own this business.");
    new msg[144]; format(msg, sizeof(msg), "Safe Balance: %s | Products are managed by admins for now.", ER_FormatMoney(Businesses[idx][bSafeBalance]));
    return ER_Send(playerid, COLOR_GREEN, msg);
}

stock ER_BusinessDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_BUSINESS_LIST)
    {
        if(response && listitem >= 0 && listitem < BusinessCount) ER_ShowBusinessEditor(playerid, Businesses[listitem][bSQLID]);
        return 1;
    }
    if(dialogid == DIALOG_BUSINESS_EDITOR)
    {
        if(!response) return 1;
        new bid = GetPVarInt(playerid, "EditingBusiness"), idx = ER_FindBusinessIndexBySQLID(bid);
        if(idx == -1) return ER_Send(playerid, COLOR_GREY, "Invalid business.");
        if(listitem == 5)
        {
            GetPlayerPos(playerid, Businesses[idx][bExtX], Businesses[idx][bExtY], Businesses[idx][bExtZ]); GetPlayerFacingAngle(playerid, Businesses[idx][bExtA]); Businesses[idx][bExtInt] = GetPlayerInterior(playerid); Businesses[idx][bExtVW] = GetPlayerVirtualWorld(playerid);
            new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `ext_x`=%f,`ext_y`=%f,`ext_z`=%f,`ext_a`=%f,`ext_int`=%d,`ext_vw`=%d WHERE `id`=%d", Businesses[idx][bExtX], Businesses[idx][bExtY], Businesses[idx][bExtZ], Businesses[idx][bExtA], Businesses[idx][bExtInt], Businesses[idx][bExtVW], bid); mysql_tquery(MainPipeline, q); ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Business exterior position saved.");
        }
        if(listitem == 6)
        {
            GetPlayerPos(playerid, Businesses[idx][bIntX], Businesses[idx][bIntY], Businesses[idx][bIntZ]); GetPlayerFacingAngle(playerid, Businesses[idx][bIntA]); Businesses[idx][bIntInt] = GetPlayerInterior(playerid);
            new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `int_x`=%f,`int_y`=%f,`int_z`=%f,`int_a`=%f,`int_int`=%d WHERE `id`=%d", Businesses[idx][bIntX], Businesses[idx][bIntY], Businesses[idx][bIntZ], Businesses[idx][bIntA], Businesses[idx][bIntInt], bid); mysql_tquery(MainPipeline, q); ER_Send(playerid, COLOR_GREEN, "Business interior position saved. Interior VW was not changed."); return ER_ShowBusinessEditor(playerid, bid);
        }
        if(listitem == 12)
        {
            ShowPlayerDialog(playerid, DIALOG_BUSINESS_PICKUP, DIALOG_STYLE_LIST, "Pickup Icon", "Default For Type\nHouse Icon\nWhite Arrow / Door\nStore\nClothes\nFood\nGun\nDealership / Car\nGas Station\nBank / Money\nBar / Club\nGym", "Select", "Back"); return 1;
        }
        if(listitem == 13)
        {
            Businesses[idx][bLocked] = !Businesses[idx][bLocked]; new q[128]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `locked`=%d WHERE `id`=%d", Businesses[idx][bLocked], bid); mysql_tquery(MainPipeline, q); ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Business lock state updated.");
        }
        if(listitem == 15) { ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Businesses reloaded."); }
        return ER_Send(playerid, COLOR_GREY, "This editor item is saved for the next code pass.");
    }
    if(dialogid == DIALOG_BUSINESS_PICKUP)
    {
        if(!response) return ER_ShowBusinessEditor(playerid, GetPVarInt(playerid, "EditingBusiness"));
        new bid = GetPVarInt(playerid, "EditingBusiness"), idx = ER_FindBusinessIndexBySQLID(bid), model = 1274;
        if(idx == -1) return 1;
        switch(listitem)
        {
            case 0: model = ER_DefaultBusinessPickup(Businesses[idx][bType]);
            case 1: model = 1273;
            case 2: model = 1318;
            case 3: model = 1274;
            case 4: model = 1275;
            case 5: model = 2768;
            case 6: model = 1242;
            case 7: model = 1239;
            case 8: model = 1650;
            case 9: model = 1274;
            case 10: model = 1544;
            case 11: model = 1240;
        }
        new q[128]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `pickup_model`=%d WHERE `id`=%d", model, bid); mysql_tquery(MainPipeline, q); ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Business pickup updated.");
    }
    if(dialogid == DIALOG_BUY_CLOTHES_TOYS)
    {
        if(!response) return 1;
        if(listitem == 0) return ER_ShowClothesGrid(playerid, 0);
        if(listitem == 1) return ER_ShowToyShopGrid(playerid, 0);
        return 1;
    }
    if(dialogid == DIALOG_BUY_PRODUCTS)
    {
        if(!response) return 1;
        if(listitem < 0 || listitem >= ER_BuyProductCount[playerid]) return 1;
        new productid = ER_BuyProductID[playerid][listitem];
        new q[128]; mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `business_products` WHERE `id`=%d LIMIT 1", productid);
        mysql_tquery(MainPipeline, q, "ER_OnBuyProductSelected", "ii", playerid, ER_BuyBusinessSQL[playerid]);
        return 1;
    }
    return 0;
}

forward ER_OnBuyProductSelected(playerid, businessid);
public ER_OnBuyProductSelected(playerid, businessid)
{
    if(!IsPlayerConnected(playerid)) return 1;
    new rows; cache_get_row_count(rows); if(!rows) return 1;
    new productid, price, stock, key[32], name[64];
    cache_get_value_name_int(0, "id", productid); cache_get_value_name_int(0, "price", price); cache_get_value_name_int(0, "stock", stock); cache_get_value_name(0, "product_key", key, sizeof(key)); cache_get_value_name(0, "product_name", name, sizeof(name));
    if(stock <= 0) return ER_Send(playerid, COLOR_GREY, "This product is out of stock.");
    if(PlayerInfo[playerid][pCash] < price) return ER_Send(playerid, COLOR_GREY, "You do not have enough cash.");
    PlayerInfo[playerid][pCash] -= price; GivePlayerMoney(playerid, -price);
    if(!strcmp(key, "mp3", true)) PlayerInfo[playerid][pHasMP3] = 1;
    else if(!strcmp(key, "radio", true)) PlayerInfo[playerid][pHasRadio] = 1;
    else if(!strcmp(key, "phone", true) && PlayerInfo[playerid][pPhone] == 0) PlayerInfo[playerid][pPhone] = 100000 + random(899999);
    else if(!strcmp(key, "rope", true)) PlayerInfo[playerid][pRope]++;
    else if(!strcmp(key, "sprunk", true)) PlayerInfo[playerid][pSprunk]++;
    else if(!strcmp(key, "weapon_22", true)) GivePlayerWeapon(playerid, 22, 50);
    else if(!strcmp(key, "weapon_23", true)) GivePlayerWeapon(playerid, 23, 50);
    else if(!strcmp(key, "weapon_24", true)) GivePlayerWeapon(playerid, 24, 30);
    else if(!strcmp(key, "weapon_25", true)) GivePlayerWeapon(playerid, 25, 20);
    else if(!strcmp(key, "weapon_29", true)) GivePlayerWeapon(playerid, 29, 120);
    else if(!strcmp(key, "armor_50", true)) SetPlayerArmour(playerid, 50.0);
    new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `business_products` SET `stock`=`stock`-1 WHERE `id`=%d", productid); mysql_tquery(MainPipeline, q); mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `safe_balance`=`safe_balance`+%d WHERE `id`=%d", price, businessid); mysql_tquery(MainPipeline, q);
    new msg[96]; format(msg, sizeof(msg), "You bought %s for %s.", name, ER_FormatMoney(price)); ER_Send(playerid, COLOR_GREEN, msg);
    return 1;
}

CMD:buybusiness(playerid, params[])
{
    new idx = ER_GetNearestBusiness(playerid, false);
    if(idx == -1) return ER_Send(playerid, COLOR_GREY, "You are not near a business.");
    if(Businesses[idx][bOwnerType] != BUSINESS_OWNER_NONE || Businesses[idx][bOwnerID] != 0) return ER_Send(playerid, COLOR_GREY, "This business is already owned.");
    new owned; for(new i; i < BusinessCount; i++) if(Businesses[i][bOwnerType] == BUSINESS_OWNER_PLAYER && Businesses[i][bOwnerID] == PlayerInfo[playerid][pID]) owned++;
    if(owned >= ER_GetMaxBusinesses(playerid)) return ER_Send(playerid, COLOR_GREY, "You have reached your business ownership limit.");
    if(PlayerInfo[playerid][pCash] < Businesses[idx][bPrice]) return ER_Send(playerid, COLOR_GREY, "You do not have enough cash.");
    PlayerInfo[playerid][pCash] -= Businesses[idx][bPrice]; GivePlayerMoney(playerid, -Businesses[idx][bPrice]);
    new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `owner_type`=1,`owner_id`=%d,`owner_name`='%e',`locked`=1 WHERE `id`=%d", PlayerInfo[playerid][pID], PlayerInfo[playerid][pName], Businesses[idx][bSQLID]); mysql_tquery(MainPipeline, q);
    ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Business purchased.");
}

CMD:sellbusiness(playerid, params[])
{
    new idx = ER_GetNearestBusiness(playerid, false);
    if(idx == -1) idx = ER_GetNearestBusiness(playerid, true);
    if(idx == -1) return ER_Send(playerid, COLOR_GREY, "You are not near your business.");
    if(Businesses[idx][bOwnerType] != BUSINESS_OWNER_PLAYER || Businesses[idx][bOwnerID] != PlayerInfo[playerid][pID]) return ER_Send(playerid, COLOR_GREY, "You do not own this business.");
    new refund = Businesses[idx][bPrice] / 2;
    PlayerInfo[playerid][pCash] += refund; GivePlayerMoney(playerid, refund);
    new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `businesses` SET `owner_type`=0,`owner_id`=0,`owner_name`='Nobody',`locked`=0 WHERE `id`=%d", Businesses[idx][bSQLID]); mysql_tquery(MainPipeline, q);
    ER_LoadBusinesses(); return ER_Send(playerid, COLOR_GREEN, "Business sold for 50 percent of its price.");
}
