#if defined _ER_HOUSES_INCLUDED
    #endinput
#endif
#define _ER_HOUSES_INCLUDED

#define HOUSE_OWNER_NONE 0
#define HOUSE_OWNER_PLAYER 1
#define HOUSE_OWNER_FAMILY 2
#define HOUSE_OWNER_FACTION 3

stock ER_FindHouseIndexBySQLID(sqlid)
{
    for(new i; i < HouseCount; i++) if(Houses[i][hSQLID] == sqlid) return i;
    return -1;
}
stock ER_DefaultHousePrice(const zone[])
{
    new price = 150000;
    if(strfind(zone, "Idlewood", true) != -1 || strfind(zone, "Ganton", true) != -1 || strfind(zone, "Willowfield", true) != -1) price = 90000 + random(70000);
    else if(strfind(zone, "Vinewood", true) != -1 || strfind(zone, "Richman", true) != -1 || strfind(zone, "Rodeo", true) != -1 || strfind(zone, "Mulholland", true) != -1) price = 500000 + random(600000);
    else price = 180000 + random(200000);
    return price;
}
stock ER_SetHouseInteriorDefaults(hid, &Float:x, &Float:y, &Float:z, &Float:a, &interior, &vw)
{
    vw = hid;
    switch(random(4))
    {
        case 0: { x = 223.0439; y = 1289.2598; z = 1082.1999; a = 0.0; interior = 1; }
        case 1: { x = 225.7569; y = 1240.0000; z = 1082.1499; a = 0.0; interior = 2; }
        case 2: { x = 2496.0498; y = -1695.2382; z = 1014.7422; a = 180.0; interior = 3; }
        default: { x = 2365.3149; y = -1135.6025; z = 1050.8750; a = 0.0; interior = 8; }
    }
    return 1;
}
stock ER_ClearHouseWorld()
{
    for(new i; i < HouseCount; i++)
    {
        if(Houses[i][hPickupID]) DestroyDynamicPickup(Houses[i][hPickupID]);
        if(Houses[i][hLabelID]) DestroyDynamic3DTextLabel(Houses[i][hLabelID]);
        Houses[i][hPickupID] = 0; Houses[i][hLabelID] = Text3D:0;
    }
    return 1;
}
stock ER_FormatHouseLabel(idx, label[], size = sizeof(label))
{
    if(Houses[idx][hOwnerType] == HOUSE_OWNER_NONE || Houses[idx][hOwnerID] == 0)
    {
        format(label, size, "%s House For Sale!\nPrice: %s\nHouse ID: %d", Houses[idx][hZone], ER_FormatMoney(Houses[idx][hPrice]), Houses[idx][hSQLID]);
    }
    else if(Houses[idx][hOwnerType] == HOUSE_OWNER_PLAYER)
    {
        new owner[32]; format(owner, sizeof(owner), "%s", Houses[idx][hOwnerName]); for(new c; owner[c]; c++) if(owner[c] == '_') owner[c] = ' ';
        format(label, size, "%s's House\nOwner: %s\n%s\nHouse ID: %d", owner, owner, Houses[idx][hLocked] ? ("Locked") : ("Unlocked"), Houses[idx][hSQLID]);
    }
    else
    {
        format(label, size, "%s HQ\nOwner: %s\n%s\nHouse ID: %d", Houses[idx][hOwnerName], Houses[idx][hOwnerName], Houses[idx][hLocked] ? ("Locked") : ("Unlocked"), Houses[idx][hSQLID]);
    }
    return 1;
}
stock ER_CreateHouseWorld(idx)
{
    new label[192]; ER_FormatHouseLabel(idx, label, sizeof(label));
    Houses[idx][hPickupID] = CreateDynamicPickup(Houses[idx][hPickupModel], Houses[idx][hPickupType] ? Houses[idx][hPickupType] : 1, Houses[idx][hExtX], Houses[idx][hExtY], Houses[idx][hExtZ], Houses[idx][hExtVW], Houses[idx][hExtInt]);
    Houses[idx][hLabelID] = CreateDynamic3DTextLabel(label, COLOR_YELLOW, Houses[idx][hExtX], Houses[idx][hExtY], Houses[idx][hExtZ] + 0.35, 15.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 1, Houses[idx][hExtVW], Houses[idx][hExtInt]);
    return 1;
}
stock ER_LoadHouses()
{
    ER_ClearHouseWorld();
    mysql_tquery(MainPipeline, "SELECT * FROM `houses` WHERE `enabled`=1", "ER_OnHousesLoad");
    return 1;
}
forward ER_OnHousesLoad();
public ER_OnHousesLoad()
{
    new rows; cache_get_row_count(rows); HouseCount = 0;
    for(new r; r < rows && HouseCount < MAX_HOUSES; r++)
    {
        cache_get_value_name_int(r, "id", Houses[HouseCount][hSQLID]); cache_get_value_name(r, "zone", Houses[HouseCount][hZone], 32); cache_get_value_name(r, "custom_name", Houses[HouseCount][hCustomName], 64);
        cache_get_value_name_int(r, "owner_type", Houses[HouseCount][hOwnerType]); cache_get_value_name_int(r, "owner_id", Houses[HouseCount][hOwnerID]); cache_get_value_name(r, "owner_name", Houses[HouseCount][hOwnerName], MAX_PLAYER_NAME_EX);
        cache_get_value_name_int(r, "price", Houses[HouseCount][hPrice]); cache_get_value_name_int(r, "price_mode", Houses[HouseCount][hPriceMode]);
        cache_get_value_name_float(r, "ext_x", Houses[HouseCount][hExtX]); cache_get_value_name_float(r, "ext_y", Houses[HouseCount][hExtY]); cache_get_value_name_float(r, "ext_z", Houses[HouseCount][hExtZ]); cache_get_value_name_float(r, "ext_a", Houses[HouseCount][hExtA]); cache_get_value_name_int(r, "ext_int", Houses[HouseCount][hExtInt]); cache_get_value_name_int(r, "ext_vw", Houses[HouseCount][hExtVW]);
        cache_get_value_name_float(r, "int_x", Houses[HouseCount][hIntX]); cache_get_value_name_float(r, "int_y", Houses[HouseCount][hIntY]); cache_get_value_name_float(r, "int_z", Houses[HouseCount][hIntZ]); cache_get_value_name_float(r, "int_a", Houses[HouseCount][hIntA]); cache_get_value_name_int(r, "int_int", Houses[HouseCount][hIntInt]); cache_get_value_name_int(r, "int_vw", Houses[HouseCount][hIntVW]);
        cache_get_value_name_int(r, "safe_balance", Houses[HouseCount][hSafeBalance]); cache_get_value_name_int(r, "materials", Houses[HouseCount][hMaterials]); cache_get_value_name_int(r, "pot", Houses[HouseCount][hPot]); cache_get_value_name_int(r, "crack", Houses[HouseCount][hCrack]);
        cache_get_value_name_int(r, "pickup_model", Houses[HouseCount][hPickupModel]); cache_get_value_name_int(r, "pickup_type", Houses[HouseCount][hPickupType]); cache_get_value_name_int(r, "locked", Houses[HouseCount][hLocked]); cache_get_value_name_int(r, "enabled", Houses[HouseCount][hEnabled]);
        ER_CreateHouseWorld(HouseCount); HouseCount++;
    }
    printf("[Houses] Loaded %d houses.", HouseCount); return 1;
}
CMD:createhouse(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new Float:x, Float:y, Float:z, Float:a, zone[32]; GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a); ER_GetPlayerZone(playerid, zone, sizeof(zone)); new price = ER_DefaultHousePrice(zone);
    new q[512]; mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `houses` (`zone`,`owner_type`,`owner_id`,`owner_name`,`price`,`price_mode`,`ext_x`,`ext_y`,`ext_z`,`ext_a`,`ext_int`,`ext_vw`,`pickup_model`,`pickup_type`,`locked`,`enabled`) VALUES ('%e',0,0,'Nobody',%d,0,%f,%f,%f,%f,%d,%d,1273,1,1,1)", zone, price, x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid)); mysql_tquery(MainPipeline, q, "ER_OnHouseCreated", "i", playerid); return 1;
}
forward ER_OnHouseCreated(playerid);
public ER_OnHouseCreated(playerid)
{
    new hid = cache_insert_id(); new Float:x, Float:y, Float:z, Float:a, interior, vw; ER_SetHouseInteriorDefaults(hid, x, y, z, a, interior, vw); new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `houses` SET `int_x`=%f,`int_y`=%f,`int_z`=%f,`int_a`=%f,`int_int`=%d,`int_vw`=%d WHERE `id`=%d", x, y, z, a, interior, vw, hid); mysql_tquery(MainPipeline, q); ER_LoadHouses(); ER_Send(playerid, COLOR_GREEN, "House created. Use /edithouse [id] to edit it."); return 1;
}
stock ER_GetNearestHouse(playerid, bool:inside = true)
{
    new vw = GetPlayerVirtualWorld(playerid), interior = GetPlayerInterior(playerid);
    for(new i; i < HouseCount; i++)
    {
        if(inside && vw == Houses[i][hIntVW] && interior == Houses[i][hIntInt]) return i;
        if(IsPlayerInRangeOfPoint(playerid, 3.0, Houses[i][hExtX], Houses[i][hExtY], Houses[i][hExtZ]) && vw == Houses[i][hExtVW] && interior == Houses[i][hExtInt]) return i;
    }
    return -1;
}
stock ER_PlayerOwnsHouse(playerid, idx) { return Houses[idx][hOwnerType] == HOUSE_OWNER_PLAYER && Houses[idx][hOwnerID] == PlayerInfo[playerid][pID]; }
stock ER_TryEnterHouse(playerid)
{
    new idx = ER_GetNearestHouse(playerid, false); if(idx == -1) return 0;
    if(Houses[idx][hLocked] && !ER_PlayerOwnsHouse(playerid, idx)) { ER_Send(playerid, COLOR_GREY, "This house is locked."); return 1; }
    SetPlayerInterior(playerid, Houses[idx][hIntInt]); SetPlayerVirtualWorld(playerid, Houses[idx][hIntVW]); SetPlayerPos(playerid, Houses[idx][hIntX], Houses[idx][hIntY], Houses[idx][hIntZ]); SetPlayerFacingAngle(playerid, Houses[idx][hIntA]); return 1;
}
stock ER_TryExitHouse(playerid)
{
    new idx = ER_GetNearestHouse(playerid, true); if(idx == -1) return 0;
    SetPlayerInterior(playerid, Houses[idx][hExtInt]); SetPlayerVirtualWorld(playerid, Houses[idx][hExtVW]); SetPlayerPos(playerid, Houses[idx][hExtX], Houses[idx][hExtY], Houses[idx][hExtZ]); SetPlayerFacingAngle(playerid, Houses[idx][hExtA]); return 1;
}
CMD:buyhouse(playerid, params[])
{
    new idx = ER_GetNearestHouse(playerid, false); if(idx == -1) return ER_Send(playerid, COLOR_GREY, "You are not near a house.");
    if(Houses[idx][hOwnerType] != HOUSE_OWNER_NONE || Houses[idx][hOwnerID] != 0) return ER_Send(playerid, COLOR_GREY, "This house is already owned.");
    new owned; for(new i; i < HouseCount; i++) if(Houses[i][hOwnerType] == HOUSE_OWNER_PLAYER && Houses[i][hOwnerID] == PlayerInfo[playerid][pID]) owned++;
    if(owned >= ER_GetMaxHouses(playerid)) return ER_Send(playerid, COLOR_GREY, "You have reached your house ownership limit.");
    if(PlayerInfo[playerid][pCash] < Houses[idx][hPrice]) return ER_Send(playerid, COLOR_GREY, "You do not have enough cash.");
    PlayerInfo[playerid][pCash] -= Houses[idx][hPrice]; GivePlayerMoney(playerid, -Houses[idx][hPrice]); new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `houses` SET `owner_type`=1,`owner_id`=%d,`owner_name`='%e',`locked`=1 WHERE `id`=%d", PlayerInfo[playerid][pID], PlayerInfo[playerid][pName], Houses[idx][hSQLID]); mysql_tquery(MainPipeline, q); ER_LoadHouses(); return ER_Send(playerid, COLOR_GREEN, "House purchased.");
}
CMD:myhouses(playerid, params[])
{
    new list[1024], count; for(new i; i < HouseCount; i++) if(ER_PlayerOwnsHouse(playerid, i)) format(list, sizeof(list), "%s%d - %s House (ID %d)\n", list, ++count, Houses[i][hZone], Houses[i][hSQLID]); if(!count) return ER_Send(playerid, COLOR_GREY, "You do not own any houses."); ShowPlayerDialog(playerid, DIALOG_HOUSE_LIST, DIALOG_STYLE_LIST, "My Houses", list, "Close", ""); return 1;
}
CMD:housestorage(playerid, params[]) { return cmd_hstorage(playerid, params); }
CMD:hstorage(playerid, params[])
{
    new idx = ER_GetNearestHouse(playerid, true); if(idx == -1 || !ER_PlayerOwnsHouse(playerid, idx)) return ER_Send(playerid, COLOR_GREY, "You are not inside your house.");
    new msg[256]; format(msg, sizeof(msg), "Cash Safe: %s\nMaterials: %d\nPot: %d\nCrack: %d\nGuns: use house weapons table", ER_FormatMoney(Houses[idx][hSafeBalance]), Houses[idx][hMaterials], Houses[idx][hPot], Houses[idx][hCrack]); ShowPlayerDialog(playerid, DIALOG_HOUSE_STORAGE, DIALOG_STYLE_MSGBOX, "House Storage", msg, "Close", ""); return 1;
}
CMD:edithouse(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized."); new hid; if(sscanf(params, "d", hid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /edithouse [id]"); SetPVarInt(playerid, "EditingHouse", hid); ShowPlayerDialog(playerid, DIALOG_HOUSE_EDITOR, DIALOG_STYLE_LIST, "House Editor", "Set Exterior Position\nSet Interior Position\nSet Interior VW Manually\nReset Interior VW To Default\nSet Pickup Icon\nToggle Locked\nReload This House\nDelete House", "Select", "Close"); return 1;
}
CMD:lock(playerid, params[])
{
    new idx = ER_GetNearestHouse(playerid, false); if(idx != -1 && ER_PlayerOwnsHouse(playerid, idx)) { Houses[idx][hLocked] = !Houses[idx][hLocked]; new q[128]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `houses` SET `locked`=%d WHERE `id`=%d", Houses[idx][hLocked], Houses[idx][hSQLID]); mysql_tquery(MainPipeline, q); ER_LoadHouses(); return ER_Send(playerid, COLOR_GREEN, "House lock toggled."); }
    if(ER_TryDoorLock(playerid)) return 1;
    return ER_Send(playerid, COLOR_GREY, "You are not near something you can lock.");
}
stock ER_HouseDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_HOUSE_EDITOR)
    {
        if(!response) return 1; new hid = GetPVarInt(playerid, "EditingHouse"), idx = ER_FindHouseIndexBySQLID(hid); if(idx == -1) return ER_Send(playerid, COLOR_GREY, "Invalid house.");
        if(listitem == 0) { GetPlayerPos(playerid, Houses[idx][hExtX], Houses[idx][hExtY], Houses[idx][hExtZ]); GetPlayerFacingAngle(playerid, Houses[idx][hExtA]); Houses[idx][hExtInt]=GetPlayerInterior(playerid); Houses[idx][hExtVW]=GetPlayerVirtualWorld(playerid); new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `houses` SET `ext_x`=%f,`ext_y`=%f,`ext_z`=%f,`ext_a`=%f,`ext_int`=%d,`ext_vw`=%d WHERE `id`=%d", Houses[idx][hExtX],Houses[idx][hExtY],Houses[idx][hExtZ],Houses[idx][hExtA],Houses[idx][hExtInt],Houses[idx][hExtVW],hid); mysql_tquery(MainPipeline,q); ER_LoadHouses(); return ER_Send(playerid,COLOR_GREEN,"House exterior saved."); }
        if(listitem == 1) { GetPlayerPos(playerid, Houses[idx][hIntX], Houses[idx][hIntY], Houses[idx][hIntZ]); GetPlayerFacingAngle(playerid, Houses[idx][hIntA]); Houses[idx][hIntInt]=GetPlayerInterior(playerid); new q[256]; mysql_format(MainPipeline,q,sizeof(q),"UPDATE `houses` SET `int_x`=%f,`int_y`=%f,`int_z`=%f,`int_a`=%f,`int_int`=%d WHERE `id`=%d",Houses[idx][hIntX],Houses[idx][hIntY],Houses[idx][hIntZ],Houses[idx][hIntA],Houses[idx][hIntInt],hid); mysql_tquery(MainPipeline,q); return ER_Send(playerid,COLOR_GREEN,"House interior saved. VW was not changed."); }
        if(listitem == 3) { new q[128]; mysql_format(MainPipeline,q,sizeof(q),"UPDATE `houses` SET `int_vw`=%d WHERE `id`=%d",hid,hid); mysql_tquery(MainPipeline,q); ER_LoadHouses(); return ER_Send(playerid,COLOR_GREEN,"House VW reset to House ID."); }
        if(listitem == 5) { Houses[idx][hLocked]=!Houses[idx][hLocked]; new q[128]; mysql_format(MainPipeline,q,sizeof(q),"UPDATE `houses` SET `locked`=%d WHERE `id`=%d",Houses[idx][hLocked],hid); mysql_tquery(MainPipeline,q); ER_LoadHouses(); return ER_Send(playerid,COLOR_GREEN,"House lock updated."); }
        if(listitem == 6) { ER_LoadHouses(); return ER_Send(playerid,COLOR_GREEN,"Houses reloaded."); }
        return ER_Send(playerid, COLOR_GREY, "This house editor item is reserved for next code pass.");
    }
    return 0;
}

CMD:sellhouse(playerid, params[])
{
    new idx = ER_GetNearestHouse(playerid, false);
    if(idx == -1) idx = ER_GetNearestHouse(playerid, true);
    if(idx == -1 || !ER_PlayerOwnsHouse(playerid, idx)) return ER_Send(playerid, COLOR_GREY, "You are not near your house.");
    new refund = Houses[idx][hPrice] / 2;
    PlayerInfo[playerid][pCash] += refund; GivePlayerMoney(playerid, refund);
    new q[256]; mysql_format(MainPipeline, q, sizeof(q), "UPDATE `houses` SET `owner_type`=0,`owner_id`=0,`owner_name`='Nobody',`locked`=1 WHERE `id`=%d", Houses[idx][hSQLID]); mysql_tquery(MainPipeline, q);
    ER_LoadHouses(); return ER_Send(playerid, COLOR_GREEN, "House sold for 50 percent of its price.");
}
