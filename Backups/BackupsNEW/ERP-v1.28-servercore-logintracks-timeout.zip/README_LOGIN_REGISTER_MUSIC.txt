Login/Register music patch

Added two different screen music URLs in includes/core/defines.pwn:

#define LOGIN_MUSIC_URL "https://example.com/login.mp3"
#define REGISTER_MUSIC_URL "https://example.com/register.mp3"

Behavior:
- Existing/registered account: plays LOGIN_MUSIC_URL while password dialog is open.
- New/unregistered account: plays REGISTER_MUSIC_URL while register dialog is open.
- Music stops after successful login/register before spawn/tutorial.
- Replace the example URLs with direct public MP3/stream URLs.
