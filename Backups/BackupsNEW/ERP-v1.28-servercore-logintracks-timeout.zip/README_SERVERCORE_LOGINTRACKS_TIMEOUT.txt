ERP v1.28 ServerCore Login/Register Tracks + 90s Timeout

Changed:
- Removed hardcoded LOGIN_MUSIC_URL / REGISTER_MUSIC_URL.
- Login screen music now reads from servercore key:
  LoginTrack
- Register screen music now reads from servercore key:
  RegisterTrack
- If the player stays on login/register screen for 90 seconds without completing,
  the server closes their connection with Kick(playerid).

SQL:
- Run SQL_V128_SERVERCORE_LOGINTRACKS.sql once.
- Then update the values in servercore with direct public mp3/stream URLs.

Example:
UPDATE `servercore` SET `value`='https://yourdomain.com/login.mp3' WHERE `keyname`='LoginTrack';
UPDATE `servercore` SET `value`='https://yourdomain.com/register.mp3' WHERE `keyname`='RegisterTrack';
