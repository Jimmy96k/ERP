-- Fix persistent business pickups for existing databases
ALTER TABLE `businesses`
  ADD COLUMN IF NOT EXISTS `pickup_model` int(11) NOT NULL DEFAULT 1274 AFTER `safe_vw`,
  ADD COLUMN IF NOT EXISTS `pickup_type` int(11) NOT NULL DEFAULT 23 AFTER `pickup_model`;

UPDATE `businesses` SET `pickup_type`=23 WHERE `pickup_type` IS NULL OR `pickup_type`=0 OR `pickup_type`=1;
UPDATE `businesses` SET `pickup_model`=1274 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=1;
UPDATE `businesses` SET `pickup_model`=2768 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=2;
UPDATE `businesses` SET `pickup_model`=1275 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=3;
UPDATE `businesses` SET `pickup_model`=1242 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=4;
UPDATE `businesses` SET `pickup_model`=1239 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=5;
UPDATE `businesses` SET `pickup_model`=1544 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=6;
UPDATE `businesses` SET `pickup_model`=1650 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=7;
UPDATE `businesses` SET `pickup_model`=1274 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=8;
UPDATE `businesses` SET `pickup_model`=1240 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=9;
