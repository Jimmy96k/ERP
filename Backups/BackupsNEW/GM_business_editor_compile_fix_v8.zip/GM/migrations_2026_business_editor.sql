-- Business editor/runtime safety migration
-- Run this if your DB was imported before the business editor update.

ALTER TABLE `businesses`
  ADD COLUMN IF NOT EXISTS `owner_type` INT NOT NULL DEFAULT 0 AFTER `type`,
  ADD COLUMN IF NOT EXISTS `owner_name` VARCHAR(24) NOT NULL DEFAULT 'Nobody' AFTER `owner_id`,
  ADD COLUMN IF NOT EXISTS `price_mode` TINYINT NOT NULL DEFAULT 0 AFTER `price`,
  ADD COLUMN IF NOT EXISTS `pickup_model` INT NOT NULL DEFAULT 1274 AFTER `safe_vw`,
  ADD COLUMN IF NOT EXISTS `pickup_type` INT NOT NULL DEFAULT 23 AFTER `pickup_model`,
  ADD COLUMN IF NOT EXISTS `locked` TINYINT NOT NULL DEFAULT 0 AFTER `pickup_type`;

UPDATE `businesses` SET `owner_type`=0 WHERE `owner_id`=0 AND (`owner_type` IS NULL OR `owner_type`=0);
UPDATE `businesses` SET `owner_name`='Nobody' WHERE `owner_id`=0 AND (`owner_name` IS NULL OR `owner_name`='');
UPDATE `businesses` SET `pickup_type`=23 WHERE `pickup_type` IS NULL OR `pickup_type`=0 OR `pickup_type`=1;
UPDATE `businesses` SET `pickup_model`=1274 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=1;
UPDATE `businesses` SET `pickup_model`=2768 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=2;
UPDATE `businesses` SET `pickup_model`=1275 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=3;
UPDATE `businesses` SET `pickup_model`=1242 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=4;
UPDATE `businesses` SET `pickup_model`=1239 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=5;
UPDATE `businesses` SET `pickup_model`=1544 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=6;
UPDATE `businesses` SET `pickup_model`=1650 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=7;
UPDATE `businesses` SET `pickup_model`=1274 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=8;
UPDATE `businesses` SET `pickup_model`=1240 WHERE (`pickup_model` IS NULL OR `pickup_model`=0) AND `type`=9;

-- Correct/expand product catalog for the current business type ids.
DELETE FROM `business_product_catalog`;
INSERT INTO `business_product_catalog` (`id`, `business_type`, `product_name`, `product_key`, `price`, `material_cost`, `default_stock_capacity`, `enabled`) VALUES
(1, 1, 'Phone', 'phone', 500, 20, 50, 1),
(2, 1, 'Phone Credit', 'phone_credit', 100, 5, 100, 1),
(3, 1, 'Radio', 'radio', 300, 10, 50, 1),
(4, 1, 'MP3 Player', 'mp3', 750, 20, 50, 1),
(5, 1, 'Rope', 'rope', 100, 5, 50, 1),
(6, 1, 'Sprunk', 'sprunk', 15, 1, 100, 1),
(7, 1, 'Mask', 'mask', 300, 15, 50, 1),
(8, 1, 'Camera', 'camera', 200, 10, 50, 1),
(9, 1, 'Repair Kit', 'repairkit', 800, 40, 25, 1),
(10, 1, 'GPS', 'gps', 500, 25, 50, 1),
(11, 2, 'Burger', 'burger', 25, 2, 100, 1),
(12, 2, 'Pizza', 'pizza', 30, 3, 100, 1),
(13, 2, 'Chicken Meal', 'chicken_meal', 35, 3, 100, 1),
(14, 2, 'Water', 'water', 10, 1, 100, 1),
(15, 2, 'Sprunk', 'sprunk', 15, 1, 100, 1),
(16, 2, 'Coffee', 'coffee', 10, 1, 100, 1),
(17, 3, 'Clothes', 'clothes', 500, 25, 100, 1),
(18, 3, 'Toys', 'toys', 1000, 50, 100, 1),
(19, 4, 'Colt 45', 'weapon_22', 1500, 100, 20, 1),
(20, 4, 'Silenced Pistol', 'weapon_23', 2500, 150, 20, 1),
(21, 4, 'Shotgun', 'weapon_25', 4500, 300, 15, 1),
(22, 4, 'Rifle', 'weapon_33', 6500, 500, 10, 1),
(23, 4, 'Ammo Pack', 'ammo_pack', 500, 50, 50, 1),
(24, 4, 'Armor 50', 'armor_50', 1000, 250, 20, 1),
(25, 6, 'Beer', 'beer', 30, 2, 100, 1),
(26, 6, 'Wine', 'wine', 60, 3, 100, 1),
(27, 6, 'Sprunk', 'sprunk', 15, 1, 100, 1),
(28, 7, 'Fuel Can', 'fuelcan', 250, 15, 50, 1),
(29, 7, 'Repair Kit', 'repairkit', 800, 40, 25, 1),
(30, 7, 'Oil', 'oil', 150, 10, 50, 1),
(31, 7, 'Sprunk', 'sprunk', 15, 1, 100, 1),
(32, 9, 'Gym Membership', 'gym_membership', 500, 0, 100, 1),
(33, 9, 'Strength Training', 'strength_training', 1000, 0, 100, 1);
