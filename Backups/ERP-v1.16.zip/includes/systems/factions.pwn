#if defined _ER_FACTIONS_INCLUDED
    #endinput
#endif
#define _ER_FACTIONS_INCLUDED

#define MAX_FACTIONS 100

enum E_FACTION_INFO
{
    facSQLID,
    facName[64],
    facLeaderID,
    facLeaderName[MAX_PLAYER_NAME_EX],
    facMOTD[128],
    facEnabled
}
new Factions[MAX_FACTIONS][E_FACTION_INFO];
new FactionCount;

stock ER_LoadFactions()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `factions` WHERE `enabled`=1", "ER_OnFactionsLoad");
    return 1;
}

forward ER_OnFactionsLoad();
public ER_OnFactionsLoad()
{
    new rows;
    cache_get_row_count(rows);
    FactionCount = 0;

    for(new r; r < rows && FactionCount < MAX_FACTIONS; r++)
    {
        cache_get_value_name_int(r, "id", Factions[FactionCount][facSQLID]);
        cache_get_value_name(r, "name", Factions[FactionCount][facName], 64);
        cache_get_value_name_int(r, "leader_id", Factions[FactionCount][facLeaderID]);
        cache_get_value_name(r, "leader_name", Factions[FactionCount][facLeaderName], MAX_PLAYER_NAME_EX);
        cache_get_value_name(r, "motd", Factions[FactionCount][facMOTD], 128);
        cache_get_value_name_int(r, "enabled", Factions[FactionCount][facEnabled]);
        FactionCount++;
    }

    printf("[Factions] Loaded %d factions.", FactionCount);
    return 1;
}

CMD:createfaction(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createfaction [name]");

    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `factions` (`name`,`leader_id`,`leader_name`,`motd`,`safe_deposit_rank`,`safe_withdraw_rank`,`locker_deposit_rank`,`locker_withdraw_rank`,`locker_gun_rank`,`enabled`) VALUES ('%e',0,'Nobody','Welcome to the faction.',1,6,1,6,1,1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnFactionCreated", "i", playerid);
    return 1;
}

forward ER_OnFactionCreated(playerid);
public ER_OnFactionCreated(playerid)
{
    new fid = cache_insert_id(), q[1024];

    for(new r = 1; r <= 6; r++)
    {
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_ranks` (`faction_id`,`rank_id`,`rank_name`) VALUES (%d,%d,'Rank %d')", fid, r, r);
        mysql_tquery(MainPipeline, q);
    }

    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_divisions` (`faction_id`,`division_id`,`division_name`) VALUES (%d,1,'Default Division')", fid);
    mysql_tquery(MainPipeline, q);

    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_lockers` (`faction_id`,`materials`,`enabled`) VALUES (%d,10000,1)", fid);
    mysql_tquery(MainPipeline, q, "ER_OnDefaultFactionLocker", "i", fid);

    ER_LoadFactions();

    new msg[128];
    format(msg, sizeof(msg), "Faction created. ID: %d. Editor opened.", fid);
    ER_Send(playerid, COLOR_GREEN, msg);
    ER_ShowFactionEditor(playerid, fid);
    return 1;
}

forward ER_OnDefaultFactionLocker(fid);
public ER_OnDefaultFactionLocker(fid)
{
    new lockerid = cache_insert_id(), q[256];

    for(new w; w < 10; w++)
    {
        new weapon = (w == 0) ? 22 : ((w == 1) ? 23 : ((w == 2) ? 29 : 0));
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `faction_locker_guns` (`locker_id`,`weaponid`,`admin_enabled`,`leader_enabled`) VALUES (%d,%d,1,1)", lockerid, weapon);
        mysql_tquery(MainPipeline, q);
    }
    return 1;
}

CMD:editfactions(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");

    new list[2048];
    for(new i; i < FactionCount; i++)
    {
        format(list, sizeof(list), "%s%d | %s | Leader: %s\n", list, Factions[i][facSQLID], Factions[i][facName], Factions[i][facLeaderName]);
    }

    if(!FactionCount) return ER_Send(playerid, COLOR_GREY, "No factions found.");
    ShowPlayerDialog(playerid, DIALOG_FACTION_LIST, DIALOG_STYLE_LIST, "Select Faction", list, "Edit", "Cancel");
    return 1;
}

stock ER_ShowFactionEditor(playerid, fid)
{
    SetPVarInt(playerid, "EditingFaction", fid);
    ShowPlayerDialog(playerid, DIALOG_FACTION_EDITOR, DIALOG_STYLE_LIST, "Faction Editor",
        "Name\nLeader\nMOTD\nRanks\nDivisions\nLockers\nSafes\nPermissions\nStatus\nSave & Reload",
        "Select", "Close");
    return 1;
}

CMD:editfaction(playerid, params[])
{
    new fid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", fid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editfaction [id]");
    return ER_ShowFactionEditor(playerid, fid);
}

stock ER_FactionDialog(playerid, dialogid, response, listitem, inputtext[])
{
    #pragma unused inputtext

    if(dialogid == DIALOG_FACTION_LIST)
    {
        if(response && listitem >= 0 && listitem < FactionCount)
        {
            ER_ShowFactionEditor(playerid, Factions[listitem][facSQLID]);
        }
        return 1;
    }

    if(dialogid == DIALOG_FACTION_EDITOR)
    {
        if(!response) return 1;
        new fid = GetPVarInt(playerid, "EditingFaction");

        switch(listitem)
        {
            case 0: ShowPlayerDialog(playerid, DIALOG_FACTION_INPUT, DIALOG_STYLE_INPUT, "Faction Name", "Enter new faction name:", "Save", "Back");
            case 1: ShowPlayerDialog(playerid, DIALOG_FACTION_INPUT, DIALOG_STYLE_INPUT, "Faction Leader", "Enter leader player SQL ID:", "Save", "Back");
            case 2: ShowPlayerDialog(playerid, DIALOG_FACTION_INPUT, DIALOG_STYLE_INPUT, "Faction MOTD", "Enter new faction MOTD:", "Save", "Back");
            case 3: ShowPlayerDialog(playerid, DIALOG_FACTION_RANKS, DIALOG_STYLE_MSGBOX, "Faction Ranks", "Rank editor foundation is ready.\nFull rank rename/manage dialog comes next.", "Back", "");
            case 4: ShowPlayerDialog(playerid, DIALOG_FACTION_DIVISIONS, DIALOG_STYLE_MSGBOX, "Faction Divisions", "Division editor foundation is ready.\nFull division rename/manage dialog comes next.", "Back", "");
            case 5: ShowPlayerDialog(playerid, DIALOG_FACTION_LOCKERS, DIALOG_STYLE_MSGBOX, "Faction Lockers", "Locker editor foundation is ready.\nGuns/materials management comes next.", "Back", "");
            case 6: ShowPlayerDialog(playerid, DIALOG_FACTION_SAFES, DIALOG_STYLE_MSGBOX, "Faction Safes", "Safe editor foundation is ready.\nDeposit/withdraw positions come next.", "Back", "");
            case 7: ShowPlayerDialog(playerid, DIALOG_FACTION_PERMS, DIALOG_STYLE_MSGBOX, "Faction Permissions", "Permission editor foundation is ready.\nSafe/locker rank permissions come next.", "Back", "");
            case 8:
            {
                new q[128];
                mysql_format(MainPipeline, q, sizeof(q), "UPDATE `factions` SET `enabled`=IF(`enabled`=1,0,1) WHERE `id`=%d", fid);
                mysql_tquery(MainPipeline, q, "ER_LoadFactions");
                ER_Send(playerid, COLOR_GREEN, "Faction status toggled.");
                ER_ShowFactionEditor(playerid, fid);
            }
            case 9:
            {
                ER_LoadFactions();
                ER_Send(playerid, COLOR_GREEN, "Factions reloaded.");
                ER_ShowFactionEditor(playerid, fid);
            }
        }
        return 1;
    }

    if(dialogid == DIALOG_FACTION_INPUT || dialogid == DIALOG_FACTION_RANKS || dialogid == DIALOG_FACTION_DIVISIONS || dialogid == DIALOG_FACTION_LOCKERS || dialogid == DIALOG_FACTION_SAFES || dialogid == DIALOG_FACTION_PERMS)
    {
        if(response || !response) ER_ShowFactionEditor(playerid, GetPVarInt(playerid, "EditingFaction"));
        return 1;
    }

    return 0;
}
