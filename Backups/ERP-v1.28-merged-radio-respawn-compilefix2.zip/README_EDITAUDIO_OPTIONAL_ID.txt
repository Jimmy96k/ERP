Edit audio command update:
- /editaudio opens the list of all audio zones.
- /editaudio [id] opens that specific audio zone edit menu.
- /editaudios remains as an alias for /editaudio.
