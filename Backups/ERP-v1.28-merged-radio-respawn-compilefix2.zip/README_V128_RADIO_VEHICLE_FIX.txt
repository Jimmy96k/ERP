ERP v1.28 radio/vehicle patch

Vehicle radio behavior:
- /setstation now applies the station to the vehicle, not only the player.
- Driver and all passengers in the same vehicle hear the same station.
- A passenger entering later will hear the current station automatically.
- Leaving the vehicle stops the radio for that player.
- Stop Radio stops it for everyone in that vehicle.
- Vehicle radio resets when the vehicle is destroyed/respawned to avoid vehicleid reuse bugs.

Parking:
- /park now saves occupants and seats before respawning/recreating the car.
- After park, driver/passengers are put back into the same seats when possible.
- Current vehicle radio station is preserved through /park.

Vehicle name resolver:
- /aveh inf -> Infernus
- /aveh infer -> Infernus
- /aveh lspd -> LSPD Police Car
- /aveh swat -> S.W.A.T.
- /createveh uses the same resolver.
- It also uses normalized exact/prefix/contains matching, so any piece of a car name can work if unambiguous.
