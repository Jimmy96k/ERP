ERP v1.28 clean package

Main changes:
- Old `audio_streams` system cleaned out of code/SQL package.
- New placed/world audio system uses `audiozones`.
- Main radio command is `/setstation`.
- `/editaudio` with no ID opens the list.
- `/editaudio [id]` opens a specific audio zone.
- `/createaudio [distance]` creates a placed audio zone.
- `/deleteaudio` opens a delete list.
- Vehicle alias resolver included:
  /aveh inf -> Infernus
  /aveh nr or nrg -> NRG-500
  /aveh lspd -> Police Car LSPD
  /aveh swat -> S.W.A.T.

SQL:
- Run `SQL_V128_CLEAN_AUDIOZONES_RADIO.sql` once.
- `audio_streams` is not used anymore.
- The DROP TABLE for old audio_streams is included as a commented optional line.
