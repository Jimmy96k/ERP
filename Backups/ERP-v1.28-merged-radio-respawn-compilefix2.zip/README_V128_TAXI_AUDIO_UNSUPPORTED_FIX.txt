ERP v1.28 taxi/audio/unsupported vehicle fix

Fixes:
- Taxi/TransFender cars show Hood/Scoop category again when valid.
- NRG/bikes and other unsupported vehicles no longer show Paintjob, NOS, Hydraulics, or Rims rows if the model cannot use them.
- Vehicle editor rows are now action-mapped dynamically, so hiding rows does not break the selected action.
- Audio zones now stop correctly when player leaves the zone.
- Audio zone system has a backup OnPlayerUpdate distance check in case Streamer leave callback misses.
- Vehicle radio has priority over zone audio while inside a car, and zone audio will not keep playing after leaving range.
