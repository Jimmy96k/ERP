ERP v1.28 merged radio respawn package

Merged:
- Save-position shutdown fix
- Clean audiozones/radiostations system
- /setstation system
- Taxi hood/unsupported vehicle editor cleanup
- Vehicle alias resolver
- Audio zone stop/range backup check

Vehicle radio behavior:
- /setstation tunes the current vehicle, not only the player.
- Driver and current passengers hear the same station.
- A passenger entering later hears the same station automatically.
- Leaving the vehicle stops the station for that player.
- Stop Radio stops it for everyone in that vehicle.
- Vehicle radio is temporary and tied to the current vehicle instance.
- When the vehicle respawns/reloads/destroys, the radio is turned off/reset.
- /park also turns vehicle radio off because it recreates/respawns the vehicle.
