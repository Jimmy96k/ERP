#if defined _ER_ENUMS_INCLUDED
    #endinput
#endif
#define _ER_ENUMS_INCLUDED

enum E_PLAYER_INFO
{
    pID,
    pLoggedIn,
    pRegistered,
    pTutorial,
    pTutorialStep,
    pName[MAX_PLAYER_NAME_EX],
    pPassword[129],
    pAdmin,
    pPlayerVip,
    pLevel,
    pPlayingHours,
    pAge,
    pDOB[16],
    pCountry[32],
    pGender,
    pAccent,
    pSkin,
    pCash,
    pBank,
    pPhone,
    bool:pPhoneOff,
    bool:pPhonespeaker,
    pPhoneline,
    pCalling,
    pCallState,
    pPhonebook,
    pHospInsurance,
    pMarriedTo[MAX_PLAYER_NAME_EX],
    pCrimes,
    pArrests,
    pWantedLevel,
    pMaterials,
    pPot,
    pCrack,
    pRope,
    pPackages,
    pSeeds,
    pSprunk,
    pSprayCans,
    Float:pHealth,
    Float:pArmor,
    pRespectPoints,
    pWarnings,
    pHasRadio,
    pRadio,
    pFavRadio,
    pVehicleLock,
    pHospitalTime,
    pTogFreeHospital,
    pFamily,
    pFaction,
    pFamilyRank,
    pFamilyCrew,
    pBusiness,
    Float:pSpawnX,
    Float:pSpawnY,
    Float:pSpawnZ,
    Float:pSpawnA,
    pSpawnInt,
    pSpawnVW,
    pPlayerJob[MAX_JOBS_PER_PLAYER],
    pPlayerWeapons[MAX_WEAPON_SLOTS],
    pInjured,
    pHospitalized,
    pHospitalBed,
    pHospitalID,
    pDeliveredByEMS
};
new PlayerInfo[MAX_PLAYERS][E_PLAYER_INFO];

new AccentNames[][] = {
    "None", "American", "British", "Japanese", "Chinese", "Korean", "Scottish", "Irish", "Russian", "Spanish",
    "Italian", "French", "German", "Australian", "Arabic", "Egyptian", "Mexican", "Gangsta", "Jamaican", "Hungarian",
    "Greek", "Indian", "Turkish", "Portuguese", "Polish", "Swedish", "Dutch", "Canadian", "Texan", "Southern"
};


enum E_SERVER_CORE
{
    scServerName[64],
    scWebsite[96],
    scDiscord[96],
    scNews[128],
    scDefaultCash,
    scDefaultBank,
    Float:scDefaultSpawnX,
    Float:scDefaultSpawnY,
    Float:scDefaultSpawnZ,
    Float:scDefaultSpawnA,
    scDefaultSpawnInt,
    scDefaultSpawnVW,
    scDefaultMaleSkin,
    scDefaultFemaleSkin,
    scTutorialEnabled,
    scAllowSkipTutorial,
    scJobLimitDefault,
    scVipJobLimit[6],
    scVipHospitalTime[6],
    scVipHospitalTransferMinLevel,
    Float:scDeathHPDecrease,
    scDeathTickMS,
    Float:scHospitalRespawnHP,
    scFamilyBackupBeaconTime
};
new ServerCore[E_SERVER_CORE];

enum E_HOSPITAL
{
    hSQLID,
    hName[64],
    hCity,
    hCityName[32],
    Float:hInsuranceX,
    Float:hInsuranceY,
    Float:hInsuranceZ,
    Float:hInsuranceA,
    hInsuranceInt,
    hInsuranceVW,
    Float:hEMSX,
    Float:hEMSY,
    Float:hEMSZ,
    Float:hEMSA,
    hEMSInt,
    hEMSVW,
    Float:hSafeX,
    Float:hSafeY,
    Float:hSafeZ,
    Float:hSafeA,
    hSafeInt,
    hSafeVW,
    hHospitalPrice,
    hHospitalPriceInsured,
    hInsurancePrice,
    hEMSFee,
    hEMSFeeInsured,
    hSafeBalance,
    hEnabled
};
new Hospitals[MAX_HOSPITALS][E_HOSPITAL];
new HospitalCount;

enum E_HOSPITAL_BED
{
    hbSQLID,
    hbHospital,
    Float:hbX,
    Float:hbY,
    Float:hbZ,
    Float:hbA,
    hbInt,
    hbVW,
    hbOccupiedBy,
    hbOccupiedUntil
};
new HospitalBeds[MAX_HOSPITAL_BEDS][E_HOSPITAL_BED];
new HospitalBedCount;

enum E_BUSINESS
{
    bSQLID,
    bName[64],
    bType,
    bOwnerID,
    bPrice,
    bMaterials,
    bMaterialsCapacity,
    bSafeBalance,
    Float:bExtX,
    Float:bExtY,
    Float:bExtZ,
    Float:bExtA,
    bExtInt,
    bExtVW,
    Float:bIntX,
    Float:bIntY,
    Float:bIntZ,
    Float:bIntA,
    bIntInt,
    bIntVW,
    Float:bSafeX,
    Float:bSafeY,
    Float:bSafeZ,
    Float:bSafeA,
    bSafeInt,
    bSafeVW,
    bEnabled
};
new Businesses[MAX_BUSINESSES][E_BUSINESS];
new BusinessCount;

enum E_FAMILY
{
    fSQLID,
    fName[64],
    fLeaderID,
    fLeaderName[MAX_PLAYER_NAME_EX],
    fMOTD[128],
    fSafeDepositRank,
    fSafeWithdrawRank,
    fLockerDepositRank,
    fLockerWithdrawRank,
    fLockerGunRank,
    fEnabled
};
new Families[MAX_FAMILIES][E_FAMILY];
new FamilyRankNames[MAX_FAMILIES][MAX_FAMILY_RANKS][32];
new FamilyCrewNames[MAX_FAMILIES][MAX_FAMILY_CREWS][32];
new FamilyCount;

enum E_RADIO_STATION
{
    rsSQLID,
    rsName[64],
    rsURL[256],
    rsCategory[32],
    rsEnabled
};
new RadioStations[MAX_RADIO_STATIONS][E_RADIO_STATION];
new RadioStationCount;

enum E_RADIO_CATEGORY
{
    rcName[32]
};
new RadioCategories[MAX_RADIO_CATEGORIES][E_RADIO_CATEGORY];
new RadioCategoryCount;

enum E_AUDIO_ZONE
{
    azSQLID,
    azName[64],
    azURL[256],
    Float:azX,
    Float:azY,
    Float:azZ,
    Float:azRange,
    azVW,
    azInt,
    azAreaID,
    azEnabled
};
new AudioZones[MAX_AUDIO_ZONES][E_AUDIO_ZONE];
new AudioZoneCount;

enum E_VEHICLE_INFO
{
    vSQLID,
    vOwnerPID,
    vFamilyID,
    vFactionID,
    vModel,
    vColor1,
    vColor2,
    vPaintjob,
    Float:vX,
    Float:vY,
    Float:vZ,
    Float:vA,
    vInt,
    vVW,
    vLockType,
    vNos,
    vUnlimitedNos,
    vModSpoiler,
    vModHood,
    vModRoof,
    vModSideskirtL,
    vModSideskirtR,
    vModLamps,
    vModNitro,
    vModExhaust,
    vModWheels,
    vModStereo,
    vModHydraulics,
    vModFrontBumper,
    vModRearBumper,
    vModVentRight,
    vModVentLeft,
    vSpawnedID,
    vEngine,
    vLights,
    vWindows[4],
    Float:vHealth,
    vEnabled
};
new VehicleInfo[MAX_DYNAMIC_VEHICLES][E_VEHICLE_INFO];
new VehicleCount;

new MySQL:MainPipeline;
