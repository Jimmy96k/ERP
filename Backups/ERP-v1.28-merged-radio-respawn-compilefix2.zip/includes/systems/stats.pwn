#if defined _ER_STATS_INCLUDED
    #endinput
#endif
#define _ER_STATS_INCLUDED

stock ER_GetHospitalNameByID(hid)
{
    static name[64];
    format(name, sizeof(name), "None");
    for(new i; i < HospitalCount; i++)
    {
        if(Hospitals[i][hSQLID] == hid)
        {
            format(name, sizeof(name), "%s", Hospitals[i][hName]);
            return name;
        }
    }
    return name;
}

stock ER_FormatNoneInt(value, dest[], size = sizeof(dest))
{
    if(value == 0) format(dest, size, "None");
    else format(dest, size, "%d", value);
    return 1;
}

CMD:stats(playerid, params[])
{
    new line[256], gender[8], insurance[64], phone[24], family[24], rank[24], crew[24], job[24], vip[24], married[32], radio[24];

    format(gender, sizeof(gender), PlayerInfo[playerid][pGender] == 2 ? "Female" : "Male");

    if(PlayerInfo[playerid][pHospInsurance] == NO_HOSPITAL_INSURANCE) format(insurance, sizeof(insurance), "None");
    else format(insurance, sizeof(insurance), "%s", ER_GetHospitalNameByID(PlayerInfo[playerid][pHospInsurance]));

    if(PlayerInfo[playerid][pPhone] == 0) format(phone, sizeof(phone), "None");
    else format(phone, sizeof(phone), "%d", PlayerInfo[playerid][pPhone]);

    ER_FormatNoneInt(PlayerInfo[playerid][pFamily], family, sizeof(family));
    ER_FormatNoneInt(PlayerInfo[playerid][pFamilyRank], rank, sizeof(rank));
    ER_FormatNoneInt(PlayerInfo[playerid][pFamilyCrew], crew, sizeof(crew));
    ER_FormatNoneInt(PlayerInfo[playerid][pPlayerJob][0], job, sizeof(job));
    ER_FormatNoneInt(PlayerInfo[playerid][pPlayerVip], vip, sizeof(vip));

    if(isnull(PlayerInfo[playerid][pMarriedTo]) || !strcmp(PlayerInfo[playerid][pMarriedTo], "0", true)) format(married, sizeof(married), "Nobody");
    else format(married, sizeof(married), "%s", PlayerInfo[playerid][pMarriedTo]);

    if(PlayerInfo[playerid][pRadio] == 0) format(radio, sizeof(radio), "None");
    else format(radio, sizeof(radio), "%d kHz", PlayerInfo[playerid][pRadio]);

    SendClientMessage(playerid, COLOR_ORANGE, "------------------------------------------------------------");
    format(line, sizeof(line), "%s - (Level: %d) - (Playing hours: %d) - (Gender: %s) - (Age: %d) - (Phone number: %s) - (Warnings: %d)",
        ER_GetName(playerid), PlayerInfo[playerid][pLevel], PlayerInfo[playerid][pPlayingHours], gender, PlayerInfo[playerid][pAge], phone, PlayerInfo[playerid][pWarnings]);
    SendClientMessage(playerid, COLOR_WHITE, line);

    format(line, sizeof(line), "(Family: %s) - (Rank: %s) - (Crew: %s) - (Job 1: %s) - (VIP: %s)",
        family, rank, crew, job, vip);
    SendClientMessage(playerid, COLOR_WHITE, line);

    format(line, sizeof(line), "(Total wealth: $%d) - (Cash: $%d) - (Bank balance: $%d) - (Insurance: %s) - (Married to: %s)",
        PlayerInfo[playerid][pCash] + PlayerInfo[playerid][pBank], PlayerInfo[playerid][pCash], PlayerInfo[playerid][pBank], insurance, married);
    SendClientMessage(playerid, COLOR_WHITE, line);

    format(line, sizeof(line), "(Respect points: %d) - (Health: %.1f) - (Armor: %.1f) - (Radio: %s) - (Country: %s)",
        PlayerInfo[playerid][pRespectPoints], PlayerInfo[playerid][pHealth], PlayerInfo[playerid][pArmor], radio, PlayerInfo[playerid][pCountry]);
    SendClientMessage(playerid, COLOR_WHITE, line);

    format(line, sizeof(line), "(Crimes: %d) - (Arrests: %d) - (Wanted Level: %d) - (Materials: %d) - (Pot: %d) - (Crack: %d) - (Packages: %d)",
        PlayerInfo[playerid][pCrimes], PlayerInfo[playerid][pArrests], PlayerInfo[playerid][pWantedLevel], PlayerInfo[playerid][pMaterials], PlayerInfo[playerid][pPot], PlayerInfo[playerid][pCrack], PlayerInfo[playerid][pPackages]);
    SendClientMessage(playerid, COLOR_WHITE, line);

    format(line, sizeof(line), "(Rope: %d) - (Sprunk: %d) - (Spray Cans: %d) - (Seeds: %d)",
        PlayerInfo[playerid][pRope], PlayerInfo[playerid][pSprunk], PlayerInfo[playerid][pSprayCans], PlayerInfo[playerid][pSeeds]);
    SendClientMessage(playerid, COLOR_WHITE, line);
    SendClientMessage(playerid, COLOR_ORANGE, "------------------------------------------------------------");
    return 1;
}
