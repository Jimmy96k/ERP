#if defined _ER_BUSINESSES_INCLUDED
    #endinput
#endif
#define _ER_BUSINESSES_INCLUDED

#define BUSINESS_TYPE_247 1
#define BUSINESS_TYPE_GUNSTORE 2
#define BUSINESS_TYPE_CLOTHES 3
#define BUSINESS_TYPE_ADS 4
#define BUSINESS_TYPE_DEALERSHIP 5
#define BUSINESS_TYPE_GAS 6
#define BUSINESS_TYPE_RESTAURANT 7

stock ER_LoadBusinesses()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `businesses` WHERE `enabled`=1", "ER_OnBusinessesLoad");
    return 1;
}
forward ER_OnBusinessesLoad();
public ER_OnBusinessesLoad()
{
    new rows; cache_get_row_count(rows); BusinessCount = 0;
    for(new r; r < rows && BusinessCount < MAX_BUSINESSES; r++)
    {
        cache_get_value_name_int(r, "id", Businesses[BusinessCount][bSQLID]);
        cache_get_value_name(r, "name", Businesses[BusinessCount][bName], 64);
        cache_get_value_name_int(r, "type", Businesses[BusinessCount][bType]);
        cache_get_value_name_int(r, "owner_id", Businesses[BusinessCount][bOwnerID]);
        cache_get_value_name_int(r, "price", Businesses[BusinessCount][bPrice]);
        cache_get_value_name_int(r, "materials", Businesses[BusinessCount][bMaterials]);
        cache_get_value_name_int(r, "materials_capacity", Businesses[BusinessCount][bMaterialsCapacity]);
        cache_get_value_name_int(r, "safe_balance", Businesses[BusinessCount][bSafeBalance]);
        BusinessCount++;
    }
    printf("[Businesses] Loaded %d businesses.", BusinessCount);
    return 1;
}

CMD:createbusiness(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createbusiness [name]");
    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `businesses` (`name`,`type`,`owner_id`,`price`,`materials`,`materials_capacity`,`enabled`) VALUES ('%e',1,0,250000,0,2000,1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnBusinessCreated", "i", playerid);
    return 1;
}
forward ER_OnBusinessCreated(playerid);
public ER_OnBusinessCreated(playerid)
{
    new bid = cache_insert_id();
    ER_CreateDefBusinessProducts(bid, BUSINESS_TYPE_247);
    ER_LoadBusinesses();
    ER_Send(playerid, COLOR_GREEN, "Business created. Use /editbusiness [id] to edit it.");
    return 1;
}

stock ER_CreateDefBusinessProducts(businessid, type)
{
    new q[256];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `business_products` (`business_id`,`catalog_id`,`product_name`,`product_key`,`price`,`material_cost`,`stock`,`stock_capacity`,`admin_enabled`,`owner_enabled`) SELECT %d,`id`,`product_name`,`product_key`,`price`,`material_cost`,0,`default_stock_capacity`,1,1 FROM `business_product_catalog` WHERE `business_type`=%d AND `enabled`=1", businessid, type);
    mysql_tquery(MainPipeline, q);
    return 1;
}

CMD:editbusinesses(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new list[2048];
    for(new i; i < BusinessCount; i++) format(list, sizeof(list), "%s%d | %s | Type %d\n", list, Businesses[i][bSQLID], Businesses[i][bName], Businesses[i][bType]);
    ShowPlayerDialog(playerid, DIALOG_BUSINESS_LIST, DIALOG_STYLE_LIST, "Select Business", list, "Edit", "Cancel");
    return 1;
}


stock ER_ShowBusinessEditor(playerid, bid)
{
	SetPVarInt(playerid, "EditingBusiness", bid);
	ShowPlayerDialog(playerid, DIALOG_BUSINESS_EDITOR, DIALOG_STYLE_LIST, "Business Editor",
		"Name\nType\nOwner\nPrice\nExterior Position\nInterior Position\nSafe Position\nMaterials\nSafe Balance\nManage Products\nManage Dealership Vehicles\nStatus\nSave & Reload",
		"Select", "Close");
	return 1;
}


CMD:editbusiness(playerid, params[])
{
    new bid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", bid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editbusiness [id]");
    return ER_ShowBusinessEditor(playerid, bid);
}

CMD:businesssettings(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREEN, "Business owner settings placeholder. It will only allow managing admin-enabled products/guns.");
}

stock ER_BusinessDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_BUSINESS_LIST)
    {
        if(response && listitem >= 0 && listitem < BusinessCount) { ER_ShowBusinessEditor(playerid, Businesses[listitem][bSQLID]); }
        return 1;
    }
    if(dialogid == DIALOG_BUSINESS_EDITOR) { if(response) ER_Send(playerid, COLOR_GREY, "Business editor field placeholder for next phase."); return 1; }
    return 0;
}
