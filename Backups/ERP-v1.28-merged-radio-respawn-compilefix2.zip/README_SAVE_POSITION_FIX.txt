ERP v1.28 Save Position Fix

Cause:
- /q saved correctly because async mysql_tquery had time to finish.
- Closing/restarting the server called mysql_tquery then immediately closed MySQL,
  so the newest spawn_x/spawn_y/spawn_z could be lost.

Fix:
- ER_SaveLastPosition(playerid, bool:syncsave = false) added.
- OnGameModeExit now uses ER_SaveLastPosition(i, true).
- ER_SaveCharacter now supports synchronous mysql_query when SyncSaveOnExit PVar is set.
- OnGameModeExit sets SyncSaveOnExit before saving and closes MySQL only after sync saves finish.

This matches the NGRP idea of saving pPos_x/pPos_y/pPos_z before account close, but adapted to your spawn_x/spawn_y/spawn_z columns.
