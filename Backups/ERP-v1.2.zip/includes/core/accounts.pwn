#if defined _ER_ACCOUNTS_INCLUDED
    #endinput
#endif
#define _ER_ACCOUNTS_INCLUDED

stock ER_ShowLoginOrRegister(playerid)
{
    new q[160];
    mysql_format(MainPipeline, q, sizeof(q), "SELECT `id`,`password` FROM `accounts` WHERE `username`='%e' LIMIT 1", ER_GetName(playerid));
    mysql_tquery(MainPipeline, q, "ER_OnAccountCheck", "i", playerid);
    return 1;
}

forward ER_OnAccountCheck(playerid);
public ER_OnAccountCheck(playerid)
{
    new rows;
    cache_get_row_count(rows);
    if(!IsPlayerConnected(playerid)) return 1;
    if(rows)
    {
        PlayerInfo[playerid][pRegistered] = 1;
        cache_get_value_name_int(0, "id", PlayerInfo[playerid][pID]);
        cache_get_value_name(0, "password", PlayerInfo[playerid][pPassword], 129);
        ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, SERVER_BRAND, "Welcome back.\n\nPlease enter your password to login.", "Login", "Quit");
    }
    else
    {
        PlayerInfo[playerid][pRegistered] = 0;
        ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD, SERVER_BRAND, "Welcome to Express Roleplay - Gaming.\n\nPlease create a password to register.", "Register", "Quit");
    }
    return 1;
}

stock ER_AccountDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_LOGIN)
    {
        if(!response) return Kick(playerid);
        new hash[129];
        WP_Hash(hash, sizeof(hash), inputtext);
        if(strcmp(hash, PlayerInfo[playerid][pPassword], false))
        {
            ShowPlayerDialog(playerid, DIALOG_LOGIN, DIALOG_STYLE_PASSWORD, SERVER_BRAND, "Wrong password. Try again.", "Login", "Quit");
            return 1;
        }
        ER_LoadCharacter(playerid);
        return 1;
    }
    if(dialogid == DIALOG_REGISTER)
    {
        if(!response) return Kick(playerid);
        if(strlen(inputtext) < 4) return ShowPlayerDialog(playerid, DIALOG_REGISTER, DIALOG_STYLE_PASSWORD, SERVER_BRAND, "Password too short. Enter at least 4 characters.", "Register", "Quit");
        new hash[129], q[2048];
        WP_Hash(hash, sizeof(hash), inputtext);
        ER_ApplyDefaultPlayerInfo(playerid);
        format(PlayerInfo[playerid][pPassword], 129, "%s", hash);
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `accounts` (`username`,`password`,`tutorial`,`level`,`cash`,`bank`,`phone`,`hosp_insurance`,`spawn_x`,`spawn_y`,`spawn_z`,`spawn_a`,`spawn_int`,`spawn_vw`,`health`,`armor`) VALUES ('%e','%e',0,1,%d,%d,%d,%d,%f,%f,%f,%f,%d,%d,100.0,0.0)", ER_GetName(playerid), hash, PlayerInfo[playerid][pCash], PlayerInfo[playerid][pBank], PlayerInfo[playerid][pPhone], NO_HOSPITAL_INSURANCE, PlayerInfo[playerid][pSpawnX], PlayerInfo[playerid][pSpawnY], PlayerInfo[playerid][pSpawnZ], PlayerInfo[playerid][pSpawnA], PlayerInfo[playerid][pSpawnInt], PlayerInfo[playerid][pSpawnVW]);
        mysql_tquery(MainPipeline, q, "ER_OnAccountRegister", "i", playerid);
        return 1;
    }
    return 0;
}

forward ER_OnAccountRegister(playerid);
public ER_OnAccountRegister(playerid)
{
    PlayerInfo[playerid][pID] = cache_insert_id();
    PlayerInfo[playerid][pRegistered] = 1;
    PlayerInfo[playerid][pLoggedIn] = 1;
    ER_Send(playerid, COLOR_GREEN, "Account created successfully. Welcome to Express Roleplay - Gaming.");
    ER_StartTutorial(playerid);
    return 1;
}


