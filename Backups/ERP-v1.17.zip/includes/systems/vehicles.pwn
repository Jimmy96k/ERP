#if defined _ER_VEHICLES_INCLUDED
    #endinput
#endif
#define _ER_VEHICLES_INCLUDED

new VehicleTrackIcon[MAX_PLAYERS] = { -1, ... };

new const ER_VehicleNames[212][] =
{
	"Landstalker","Bravura","Buffalo","Linerunner","Pereniel","Sentinel","Dumper","Firetruck","Trashmaster","Stretch","Manana","Infernus","Voodoo","Pony","Mule","Cheetah","Ambulance","Leviathan","Moonbeam","Esperanto","Taxi","Washington","Bobcat","Mr Whoopee","BF Injection","Hunter","Premier","Enforcer","Securicar","Banshee","Predator","Bus","Rhino","Barracks","Hotknife","Trailer","Previon","Coach","Cabbie","Stallion","Rumpo","RC Bandit","Romero","Packer","Monster","Admiral","Squalo","Seasparrow","Pizzaboy","Tram","Trailer","Turismo","Speeder","Reefer","Tropic","Flatbed","Yankee","Caddy","Solair","Berkley's RC Van","Skimmer","PCJ-600","Faggio","Freeway","RC Baron","RC Raider","Glendale","Oceanic","Sanchez","Sparrow","Patriot","Quad","Coastguard","Dinghy","Hermes","Sabre","Rustler","ZR-350","Walton","Regina","Comet","BMX","Burrito","Camper","Marquis","Baggage","Dozer","Maverick","News Chopper","Rancher","FBI Rancher","Virgo","Greenwood","Jetmax","Hotring","Sandking","Blista Compact","Police Maverick","Boxville","Benson","Mesa","RC Goblin","Hotring Racer A","Hotring Racer B","Bloodring Banger","Rancher","Super GT","Elegant","Journey","Bike","Mountain Bike","Beagle","Cropdust","Stunt","Tanker","RoadTrain","Nebula","Majestic","Buccaneer","Shamal","Hydra","FCR-900","NRG-500","HPV1000","Cement Truck","Tow Truck","Fortune","Cadrona","FBI Truck","Willard","Forklift","Tractor","Combine","Feltzer","Remington","Slamvan","Blade","Freight","Streak","Vortex","Vincent","Bullet","Clover","Sadler","Firetruck LA","Hustler","Intruder","Primo","Cargobob","Tampa","Sunrise","Merit","Utility","Nevada","Yosemite","Windsor","Monster A","Monster B","Uranus","Jester","Sultan","Stratum","Elegy","Raindance","RC Tiger","Flash","Tahoma","Savanna","Bandito","Freight Flat","Streak Carriage","Kart","Mower","Duneride","Sweeper","Broadway","Tornado","AT-400","DFT-30","Huntley","Stafford","BF-400","Newsvan","Tug","Trailer 3","Emperor","Wayfarer","Euros","Hotdog","Club","Freight Carriage","Trailer 3","Andromada","Dodo","RC Cam","Launch","Police Car LSPD","Police Car SFPD","Police Car LVPD","Police Ranger","Picador","S.W.A.T.","Alpha","Phoenix","Glendale Shit","Sadler Shit","Luggage Trailer A","Luggage Trailer B","Stair Trailer","Boxville","Farm Plow","Utility Trailer"
};

stock ER_GetVehicleModelName(model)
{
	static name[32];
	if(model >= 400 && model <= 611) format(name, sizeof(name), "%s", ER_VehicleNames[model - 400]);
	else format(name, sizeof(name), "Unknown");
	return name;
}

stock ER_FindVehicleModel(const input[])
{
	if(strlen(input) == 0) return 0;
	if(input[0] >= '0' && input[0] <= '9')
	{
		new model = strval(input);
		if(model >= 400 && model <= 611) return model;
		return 0;
	}

	for(new i; i < sizeof(ER_VehicleNames); i++)
	{
		if(!strcmp(input, ER_VehicleNames[i], true)) return i + 400;
	}
	if(!strcmp(input, "nrg", true) || !strcmp(input, "nrg500", true)) return 522;
	return 0;
}

stock ER_GetVehicleAreaName(Float:x, Float:y, Float:z, dest[], size = sizeof(dest))
{
	#pragma unused z
	if(x >= 44.0 && x <= 2997.0 && y >= -2892.0 && y <= -768.0) format(dest, size, "Los Santos");
	else if(x >= -2997.0 && x <= -1213.0 && y >= -1115.0 && y <= 1659.0) format(dest, size, "San Fierro");
	else if(x >= 869.0 && x <= 2997.0 && y >= 596.0 && y <= 2997.0) format(dest, size, "Las Venturas");
	else format(dest, size, "San Andreas");
	return 1;
}

stock ER_GetVehicleLockName(locktype)
{
	static name[16];
	switch(locktype)
	{
		case 1: format(name, sizeof(name), "Alarm");
		case 2: format(name, sizeof(name), "Industrial");
		default: format(name, sizeof(name), "None");
	}
	return name;
}

stock ER_FindVehicleBySpawnID(vehicleid)
{
	for(new i; i < VehicleCount; i++)
	{
		if(VehicleInfo[i][vSpawnedID] == vehicleid) return i;
	}
	return -1;
}

stock ER_FindVehicleBySQLID(sqlid)
{
	for(new i; i < VehicleCount; i++)
	{
		if(VehicleInfo[i][vSQLID] == sqlid) return i;
	}
	return -1;
}

stock ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername[], dest[], size = sizeof(dest))
{
	if(ownerpid > 0) format(dest, size, "Player Owned (%d) %s", ownerpid, ownername[0] ? ownername : "Unknown");
	else if(familyid > 0) format(dest, size, "Family Owned (%d)", familyid);
	else if(factionid > 0) format(dest, size, "Faction Owned (%d)", factionid);
	else format(dest, size, "None");
	return 1;
}

stock ER_LoadVehicles()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `vehicles` WHERE `enabled`=1", "ER_OnVehiclesLoad");
    return 1;
}

forward ER_ReloadVehicles();
public ER_ReloadVehicles()
{
    ER_LoadVehicles();
    return 1;
}

forward ER_OnVehiclesLoad();
public ER_OnVehiclesLoad()
{
    new rows; cache_get_row_count(rows);

    for(new i; i < VehicleCount; i++)
    {
        if(VehicleInfo[i][vSpawnedID] != INVALID_VEHICLE_ID)
        {
            DestroyVehicle(VehicleInfo[i][vSpawnedID]);
        }
    }

    VehicleCount = 0;
    for(new r; r < rows && VehicleCount < MAX_DYNAMIC_VEHICLES; r++)
    {
        cache_get_value_name_int(r, "id", VehicleInfo[VehicleCount][vSQLID]);
        cache_get_value_name_int(r, "owner_pid", VehicleInfo[VehicleCount][vOwnerPID]);
        cache_get_value_name_int(r, "family_id", VehicleInfo[VehicleCount][vFamilyID]);
        cache_get_value_name_int(r, "faction_id", VehicleInfo[VehicleCount][vFactionID]);
        cache_get_value_name_int(r, "model", VehicleInfo[VehicleCount][vModel]);
        cache_get_value_name_int(r, "color1", VehicleInfo[VehicleCount][vColor1]);
        cache_get_value_name_int(r, "color2", VehicleInfo[VehicleCount][vColor2]);
        cache_get_value_name_int(r, "paintjob", VehicleInfo[VehicleCount][vPaintjob]);
        cache_get_value_name_float(r, "x", VehicleInfo[VehicleCount][vX]);
        cache_get_value_name_float(r, "y", VehicleInfo[VehicleCount][vY]);
        cache_get_value_name_float(r, "z", VehicleInfo[VehicleCount][vZ]);
        cache_get_value_name_float(r, "a", VehicleInfo[VehicleCount][vA]);
        cache_get_value_name_int(r, "interior", VehicleInfo[VehicleCount][vInt]);
        cache_get_value_name_int(r, "vw", VehicleInfo[VehicleCount][vVW]);
        cache_get_value_name_int(r, "lock_type", VehicleInfo[VehicleCount][vLockType]);

        VehicleInfo[VehicleCount][vSpawnedID] = CreateVehicle(VehicleInfo[VehicleCount][vModel], VehicleInfo[VehicleCount][vX], VehicleInfo[VehicleCount][vY], VehicleInfo[VehicleCount][vZ], VehicleInfo[VehicleCount][vA], VehicleInfo[VehicleCount][vColor1], VehicleInfo[VehicleCount][vColor2], -1);
        if(VehicleInfo[VehicleCount][vPaintjob] >= 0) ChangeVehiclePaintjob(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vPaintjob]);
        SetVehicleVirtualWorld(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vVW]);
        LinkVehicleToInterior(VehicleInfo[VehicleCount][vSpawnedID], VehicleInfo[VehicleCount][vInt]);
        VehicleCount++;
    }
    printf("[Vehicles] Loaded %d vehicles.", VehicleCount);
    return 1;
}

CMD:aveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0;
    if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /aveh [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    new Float:x, Float:y, Float:z, Float:a;
    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    new veh = CreateVehicle(model, x + 3.0, y, z, a, c1, c2, -1);
    SetVehicleVirtualWorld(veh, GetPlayerVirtualWorld(playerid));
    LinkVehicleToInterior(veh, GetPlayerInterior(playerid));
    PutPlayerInVehicle(playerid, veh, 0);

    new msg[96];
    format(msg, sizeof(msg), "Spawned temporary %s (%d).", ER_GetVehicleModelName(model), model);
    return ER_Send(playerid, COLOR_GREEN, msg);
}

CMD:createveh(playerid, params[])
{
    new modelstr[32], model, c1 = 0, c2 = 0, q[512], Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "s[32]D(0)D(0)", modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createveh(icle) [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`paintjob`,`x`,`y`,`z`,`a`,`interior`,`vw`,`lock_type`,`enabled`) VALUES (0,0,0,%d,%d,%d,-1,%f,%f,%f,%f,%d,%d,0,1)",
        model, c1, c2, x + 3.0, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    SetPVarInt(playerid, "CreateVehModel", model);
    SetPVarInt(playerid, "CreateVehColor1", c1);
    SetPVarInt(playerid, "CreateVehColor2", c2);
    SetPVarFloat(playerid, "CreateVehX", x + 3.0);
    SetPVarFloat(playerid, "CreateVehY", y);
    SetPVarFloat(playerid, "CreateVehZ", z);
    SetPVarFloat(playerid, "CreateVehA", a);
    SetPVarInt(playerid, "CreateVehInt", GetPlayerInterior(playerid));
    SetPVarInt(playerid, "CreateVehVW", GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q, "ER_OnAdminVehicleCreated", "i", playerid);
    return 1;
}
alias:createveh("createvehicle")

forward ER_OnAdminVehicleCreated(playerid);
public ER_OnAdminVehicleCreated(playerid)
{
    new vid = cache_insert_id();

    if(VehicleCount < MAX_DYNAMIC_VEHICLES)
    {
        new idx = VehicleCount;
        VehicleInfo[idx][vSQLID] = vid;
        VehicleInfo[idx][vOwnerPID] = 0;
        VehicleInfo[idx][vFamilyID] = 0;
        VehicleInfo[idx][vFactionID] = 0;
        VehicleInfo[idx][vModel] = GetPVarInt(playerid, "CreateVehModel");
        VehicleInfo[idx][vColor1] = GetPVarInt(playerid, "CreateVehColor1");
        VehicleInfo[idx][vColor2] = GetPVarInt(playerid, "CreateVehColor2");
        VehicleInfo[idx][vPaintjob] = -1;
        VehicleInfo[idx][vX] = GetPVarFloat(playerid, "CreateVehX");
        VehicleInfo[idx][vY] = GetPVarFloat(playerid, "CreateVehY");
        VehicleInfo[idx][vZ] = GetPVarFloat(playerid, "CreateVehZ");
        VehicleInfo[idx][vA] = GetPVarFloat(playerid, "CreateVehA");
        VehicleInfo[idx][vInt] = GetPVarInt(playerid, "CreateVehInt");
        VehicleInfo[idx][vVW] = GetPVarInt(playerid, "CreateVehVW");
        VehicleInfo[idx][vLockType] = 0;

        VehicleInfo[idx][vSpawnedID] = CreateVehicle(VehicleInfo[idx][vModel], VehicleInfo[idx][vX], VehicleInfo[idx][vY], VehicleInfo[idx][vZ], VehicleInfo[idx][vA], VehicleInfo[idx][vColor1], VehicleInfo[idx][vColor2], -1);
        SetVehicleVirtualWorld(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vVW]);
        LinkVehicleToInterior(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vInt]);
        PutPlayerInVehicle(playerid, VehicleInfo[idx][vSpawnedID], 0);
        VehicleCount++;
    }

    new msg[128], model = GetPVarInt(playerid, "CreateVehModel");
    format(msg, sizeof(msg), "Saved vehicle created. SQL ID: %d | %s (%d).", vid, ER_GetVehicleModelName(model), model);
    ER_Send(playerid, COLOR_GREEN, msg);
    return 1;
}

CMD:createpveh(playerid, params[])
{
    new pid, modelstr[32], model, q[512], c1 = 0, c2 = 0, Float:x, Float:y, Float:z, Float:a;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
    if(sscanf(params, "ds[32]D(0)D(0)", pid, modelstr, c1, c2)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createpveh [pID] [model/name] [color1 optional] [color2 optional]");

    model = ER_FindVehicleModel(modelstr);
    if(model < 400 || model > 611) return ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");

    GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `vehicles` (`owner_pid`,`family_id`,`faction_id`,`model`,`color1`,`color2`,`paintjob`,`x`,`y`,`z`,`a`,`interior`,`vw`,`enabled`) VALUES (%d,0,0,%d,%d,%d,-1,%f,%f,%f,%f,%d,%d,1)",
        pid, model, c1, c2, x+3.0, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid));
    mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
    return ER_Send(playerid, COLOR_GREEN, "Player vehicle created.");
}

CMD:vehicles(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnMyVehiclesDialog", "i", playerid);
	return 1;
}

forward ER_OnMyVehiclesDialog(playerid);
public ER_OnMyVehiclesDialog(playerid)
{
	new rows, list[2048], model, locktype, spawnid, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		new sqlid;
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_MY_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "My Vehicles", list, "Close", "");
	return 1;
}

CMD:trackveh(playerid, params[])
{
	new q[160];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC", PlayerInfo[playerid][pID]);
	mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleList", "i", playerid);
	return 1;
}
alias:trackveh("trackvehicle")

forward ER_OnTrackVehicleList(playerid);
public ER_OnTrackVehicleList(playerid)
{
	new rows, list[2048], model, locktype, spawnid, Float:x, Float:y, Float:z, area[32];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "You do not own any vehicles.");

	format(list, sizeof(list), "ID\tVehID\tVehicle\tLock\tLocation\n");
	for(new r; r < rows; r++)
	{
		new sqlid;
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "lock_type", locktype);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), ER_GetVehicleLockName(locktype), area);
	}
	ShowPlayerDialog(playerid, DIALOG_TRACK_VEHICLE, DIALOG_STYLE_TABLIST_HEADERS, "Track Vehicle", list, "Track", "Close");
	return 1;
}

CMD:allvehs(playerid, params[])
{
	if(!ER_IsAdmin(playerid, ADMIN_MOD)) return 0;
	mysql_tquery(MainPipeline, "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.enabled=1 ORDER BY v.id ASC LIMIT 150", "ER_OnAllVehiclesDialog", "i", playerid);
	return 1;
}
alias:allvehs("allvehicles")

CMD:editvehicles(playerid, params[])
{
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	mysql_tquery(MainPipeline, "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.enabled=1 ORDER BY v.id ASC LIMIT 150", "ER_OnEditVehiclesDialog", "i", playerid);
	return 1;
}

forward ER_OnAllVehiclesDialog(playerid);
public ER_OnAllVehiclesDialog(playerid)
{
	new rows, list[4096], sqlid, model, ownerpid, familyid, factionid, spawnid, Float:x, Float:y, Float:z, area[32], owner[96], ownername[24];
	cache_get_row_count(rows);
	format(list, sizeof(list), "ID\tVehID\tModel\tOwner\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "owner_pid", ownerpid);
		cache_get_value_name_int(r, "family_id", familyid);
		cache_get_value_name_int(r, "faction_id", factionid);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		cache_get_value_name(r, "owner_name", ownername, sizeof(ownername));

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), owner, area);
	}
	ShowPlayerDialog(playerid, DIALOG_ALL_VEHICLES, DIALOG_STYLE_TABLIST_HEADERS, "All Vehicles", list, "Close", "");
	return 1;
}

forward ER_OnEditVehiclesDialog(playerid);
public ER_OnEditVehiclesDialog(playerid)
{
	new rows, list[4096], sqlid, model, ownerpid, familyid, factionid, spawnid, Float:x, Float:y, Float:z, area[32], owner[96], ownername[24];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "No vehicles found.");
	format(list, sizeof(list), "ID\tVehID\tModel\tOwner\tLocation\n");
	for(new r; r < rows; r++)
	{
		cache_get_value_name_int(r, "id", sqlid);
		cache_get_value_name_int(r, "model", model);
		cache_get_value_name_int(r, "owner_pid", ownerpid);
		cache_get_value_name_int(r, "family_id", familyid);
		cache_get_value_name_int(r, "faction_id", factionid);
		cache_get_value_name_float(r, "x", x);
		cache_get_value_name_float(r, "y", y);
		cache_get_value_name_float(r, "z", z);
		cache_get_value_name(r, "owner_name", ownername, sizeof(ownername));

		spawnid = INVALID_VEHICLE_ID;
		new idx = ER_FindVehicleBySQLID(sqlid);
		if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

		ER_GetVehicleAreaName(x, y, z, area, sizeof(area));
		ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));
		format(list, sizeof(list), "%s%d\t%d\t%s\t%s\t%s\n", list, sqlid, spawnid, ER_GetVehicleModelName(model), owner, area);
	}
	ShowPlayerDialog(playerid, DIALOG_EDIT_VEHICLE_LIST, DIALOG_STYLE_TABLIST_HEADERS, "Edit Vehicles", list, "Edit", "Close");
	return 1;
}

CMD:editveh(playerid, params[])
{
	new vehid, sqlid;
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editveh(icle) [ingame vehicle id]");

	new idx = ER_FindVehicleBySpawnID(vehid);
	if(idx == -1) return ER_Send(playerid, COLOR_GREY, "That ingame vehicle ID is not a saved dynamic vehicle.");

	sqlid = VehicleInfo[idx][vSQLID];
	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	ER_ShowVehicleEditor(playerid, sqlid);
	return 1;
}
alias:editveh("editvehicle")

CMD:deleteveh(playerid, params[])
{
	new vehid, q[128], sqlid = 0;
	if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return 0;
	if(sscanf(params, "d", vehid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /deleteveh(icle) [ingame vehicle id]");

	new idx = ER_FindVehicleBySpawnID(vehid);
	if(idx != -1) sqlid = VehicleInfo[idx][vSQLID];
	else sqlid = vehid; // fallback, useful if admin typed SQL ID

	mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", sqlid);
	mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
	return ER_Send(playerid, COLOR_GREEN, "Vehicle disabled/deleted.");
}
alias:deleteveh("deletevehicle")

stock ER_ShowVehicleEditor(playerid, sqlid)
{
	new q[256];
	mysql_format(MainPipeline, q, sizeof(q), "SELECT v.*, a.username AS owner_name FROM `vehicles` v LEFT JOIN `accounts` a ON a.id=v.owner_pid WHERE v.id=%d LIMIT 1", sqlid);
	mysql_tquery(MainPipeline, q, "ER_OnShowVehicleEditor", "i", playerid);
	return 1;
}

forward ER_OnShowVehicleEditor(playerid);
public ER_OnShowVehicleEditor(playerid)
{
	new rows;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	new sqlid, model, c1, c2, paintjob, ownerpid, familyid, factionid, spawnid, ownername[24], owner[96], list[1024];
	cache_get_value_name_int(0, "id", sqlid);
	cache_get_value_name_int(0, "model", model);
	cache_get_value_name_int(0, "color1", c1);
	cache_get_value_name_int(0, "color2", c2);
	cache_get_value_name_int(0, "paintjob", paintjob);
	cache_get_value_name_int(0, "owner_pid", ownerpid);
	cache_get_value_name_int(0, "family_id", familyid);
	cache_get_value_name_int(0, "faction_id", factionid);
	cache_get_value_name(0, "owner_name", ownername, sizeof(ownername));

	spawnid = INVALID_VEHICLE_ID;
	new idx = ER_FindVehicleBySQLID(sqlid);
	if(idx != -1) spawnid = VehicleInfo[idx][vSpawnedID];

	ER_GetVehicleOwnerText(ownerpid, familyid, factionid, ownername, owner, sizeof(owner));

	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	format(list, sizeof(list),
		"Owner: %s\nModel: %s (%d)\nColor 1: %d\nColor 2: %d\nPaintjob: %d\nPosition: Set here\nGoto Vehicle\nRespawn/Reload\nDisable/Delete",
		owner, ER_GetVehicleModelName(model), model, c1, c2, paintjob);
	new title[64];
	format(title, sizeof(title), "Vehicle Editor - ID %d | VehID %d", sqlid, spawnid);
	ShowPlayerDialog(playerid, DIALOG_EDIT_VEHICLE_MENU, DIALOG_STYLE_LIST, title, list, "Select", "Close");
	return 1;
}

stock ER_SetVehicleOwner(playerid, sqlid, type, value)
{
	new q[256];
	if(type == 1)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	else if(type == 2)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	else if(type == 3)
	{
		mysql_format(MainPipeline, q, sizeof(q), "SELECT owner_pid,family_id,faction_id FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
		SetPVarInt(playerid, "SetOwnerType", type);
		SetPVarInt(playerid, "SetOwnerValue", value);
		mysql_tquery(MainPipeline, q, "ER_OnCheckVehicleOwnerSet", "ii", playerid, sqlid);
	}
	return 1;
}

forward ER_OnCheckVehicleOwnerSet(playerid, sqlid);
public ER_OnCheckVehicleOwnerSet(playerid, sqlid)
{
	new rows, ownerpid, familyid, factionid, type, value, q[256], err[128];
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	cache_get_value_name_int(0, "owner_pid", ownerpid);
	cache_get_value_name_int(0, "family_id", familyid);
	cache_get_value_name_int(0, "faction_id", factionid);

	type = GetPVarInt(playerid, "SetOwnerType");
	value = GetPVarInt(playerid, "SetOwnerValue");

	if(value > 0)
	{
		if(type != 1 && ownerpid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Player: %d.", ownerpid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
		if(type != 2 && familyid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Family: %d.", familyid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
		if(type != 3 && factionid > 0)
		{
			format(err, sizeof(err), "Error: this vehicle is already owned by Faction: %d.", factionid);
			ER_Send(playerid, COLOR_LIGHTRED, err);
			return ER_ShowVehicleEditor(playerid, sqlid);
		}
	}

	switch(type)
	{
		case 1: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=%d,`family_id`=0,`faction_id`=0 WHERE `id`=%d", value, sqlid);
		case 2: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=%d,`faction_id`=0 WHERE `id`=%d", value, sqlid);
		case 3: mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=0,`faction_id`=%d WHERE `id`=%d", value, sqlid);
		default: return ER_ShowVehicleEditor(playerid, sqlid);
	}
	mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
	ER_Send(playerid, COLOR_GREEN, "Vehicle owner updated.");
	return ER_ShowVehicleEditor(playerid, sqlid);
}

stock ER_VehicleDialog(playerid, dialogid, response, listitem, inputtext[])
{
	if(dialogid == DIALOG_TRACK_VEHICLE)
	{
		if(!response) return 1;
		new q[160];
		mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `owner_pid`=%d AND `enabled`=1 ORDER BY `id` ASC LIMIT %d,1", PlayerInfo[playerid][pID], listitem);
		mysql_tquery(MainPipeline, q, "ER_OnTrackVehicleSelect", "i", playerid);
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEHICLE_LIST)
	{
		if(!response) return 1;
		new q[160];
		mysql_format(MainPipeline, q, sizeof(q), "SELECT `id` FROM `vehicles` WHERE `enabled`=1 ORDER BY `id` ASC LIMIT %d,1", listitem);
		mysql_tquery(MainPipeline, q, "ER_OnEditVehicleListSelect", "i", playerid);
		return 1;
	}

	if(dialogid == DIALOG_MY_VEHICLES || dialogid == DIALOG_ALL_VEHICLES)
	{
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEHICLE_MENU)
	{
		if(!response) return 1;
		new sqlid = GetPVarInt(playerid, "EditingVehicleID");
		if(sqlid <= 0) return 1;

		switch(listitem)
		{
			case 0:
			{
				ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER, DIALOG_STYLE_LIST, "Vehicle Owner", "Player\nFamily (SQL ID)\nFaction (SQL ID)\nClear Owner", "Select", "Back");
			}
			case 1:
			{
				ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_MODEL, DIALOG_STYLE_INPUT, "Vehicle Model", "Enter model ID or vehicle name:", "Save", "Back");
			}
			case 2:
			{
				ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_COLOR1, DIALOG_STYLE_INPUT, "Vehicle Color 1", "Enter color 1 number:", "Save", "Back");
			}
			case 3:
			{
				ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_COLOR2, DIALOG_STYLE_INPUT, "Vehicle Color 2", "Enter color 2 number:", "Save", "Back");
			}
			case 4:
			{
				ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_PAINTJOB, DIALOG_STYLE_INPUT, "Vehicle Paintjob", "Enter paintjob ID (-1 for none):", "Save", "Back");
			}
			case 5:
			{
				new Float:x, Float:y, Float:z, Float:a, q[256];
				GetPlayerPos(playerid, x, y, z); GetPlayerFacingAngle(playerid, a);
				mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `x`=%f,`y`=%f,`z`=%f,`a`=%f,`interior`=%d,`vw`=%d WHERE `id`=%d",
					x, y, z, a, GetPlayerInterior(playerid), GetPlayerVirtualWorld(playerid), sqlid);
				mysql_tquery(MainPipeline, q);

				new idx = ER_FindVehicleBySQLID(sqlid);
				if(idx != -1)
				{
					VehicleInfo[idx][vX] = x;
					VehicleInfo[idx][vY] = y;
					VehicleInfo[idx][vZ] = z;
					VehicleInfo[idx][vA] = a;
					VehicleInfo[idx][vInt] = GetPlayerInterior(playerid);
					VehicleInfo[idx][vVW] = GetPlayerVirtualWorld(playerid);
					SetVehiclePos(VehicleInfo[idx][vSpawnedID], x, y, z);
					SetVehicleZAngle(VehicleInfo[idx][vSpawnedID], a);
					SetVehicleVirtualWorld(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vVW]);
					LinkVehicleToInterior(VehicleInfo[idx][vSpawnedID], VehicleInfo[idx][vInt]);
				}

				ER_Send(playerid, COLOR_GREEN, "Vehicle position updated.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 6:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `vehicles` WHERE `id`=%d LIMIT 1", sqlid);
				mysql_tquery(MainPipeline, q, "ER_OnGotoVehicleSQL", "i", playerid);
			}
			case 7:
			{
				ER_LoadVehicles();
				ER_Send(playerid, COLOR_GREEN, "Vehicles reloaded.");
				ER_ShowVehicleEditor(playerid, sqlid);
			}
			case 8:
			{
				new q[128];
				mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `enabled`=0 WHERE `id`=%d", sqlid);
				mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
				ER_Send(playerid, COLOR_GREEN, "Vehicle disabled/deleted.");
			}
		}
		return 1;
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		if(listitem == 0)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER_PLAYER_TYPE, DIALOG_STYLE_LIST, "Player Owner", "Online Player\nOffline Player SQL ID", "Select", "Back");
		}
		if(listitem == 1)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_FAMILY, DIALOG_STYLE_INPUT, "Family Owner", "Enter family SQL ID:", "Save", "Back");
		}
		if(listitem == 2)
		{
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_FACTION, DIALOG_STYLE_INPUT, "Faction Owner", "Enter faction SQL ID:", "Save", "Back");
		}

		new q[128], sqlid = GetPVarInt(playerid, "EditingVehicleID");
		mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `owner_pid`=0,`family_id`=0,`faction_id`=0 WHERE `id`=%d", sqlid);
		mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
		ER_Send(playerid, COLOR_GREEN, "Vehicle owner cleared.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER_PLAYER_TYPE)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		if(listitem == 0)
		{
			new list[1024], count = 0, name[MAX_PLAYER_NAME];
			list[0] = EOS;
			foreach(new i : Player)
			{
				if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pID] > 0)
				{
					GetPlayerName(i, name, sizeof(name));
					new pvarname[24]; format(pvarname, sizeof(pvarname), "OwnerOnline%d", count); SetPVarInt(playerid, pvarname, i);
					format(list, sizeof(list), "%s%d\t%s\tSQL ID: %d\n", list, i, name, PlayerInfo[i][pID]);
					count++;
				}
			}
			if(!count) return ER_Send(playerid, COLOR_GREY, "No online players found.");
			return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_OWNER_ONLINE_PLAYER, DIALOG_STYLE_TABLIST, "Select Online Player", list, "Select", "Back");
		}
		return ShowPlayerDialog(playerid, DIALOG_EDIT_VEH_SET_PLAYER, DIALOG_STYLE_INPUT, "Offline Player Owner", "Enter player SQL ID:", "Save", "Back");
	}

	if(dialogid == DIALOG_EDIT_VEH_OWNER_ONLINE_PLAYER)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		new pvarname[24]; format(pvarname, sizeof(pvarname), "OwnerOnline%d", listitem); new target = GetPVarInt(playerid, pvarname);
		if(!IsPlayerConnected(target) || PlayerInfo[target][pID] <= 0) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		return ER_SetVehicleOwner(playerid, GetPVarInt(playerid, "EditingVehicleID"), 1, PlayerInfo[target][pID]);
	}

	if(dialogid == DIALOG_EDIT_VEH_SET_PLAYER || dialogid == DIALOG_EDIT_VEH_SET_FAMILY || dialogid == DIALOG_EDIT_VEH_SET_FACTION)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));
		new value = strval(inputtext), sqlid = GetPVarInt(playerid, "EditingVehicleID");
		if(value < 0) value = 0;
		if(dialogid == DIALOG_EDIT_VEH_SET_PLAYER) return ER_SetVehicleOwner(playerid, sqlid, 1, value);
		if(dialogid == DIALOG_EDIT_VEH_SET_FAMILY) return ER_SetVehicleOwner(playerid, sqlid, 2, value);
		if(dialogid == DIALOG_EDIT_VEH_SET_FACTION) return ER_SetVehicleOwner(playerid, sqlid, 3, value);
	}

	if(dialogid == DIALOG_EDIT_VEH_MODEL || dialogid == DIALOG_EDIT_VEH_COLOR1 || dialogid == DIALOG_EDIT_VEH_COLOR2 || dialogid == DIALOG_EDIT_VEH_PAINTJOB)
	{
		if(!response) return ER_ShowVehicleEditor(playerid, GetPVarInt(playerid, "EditingVehicleID"));

		new sqlid = GetPVarInt(playerid, "EditingVehicleID"), q[160], value;
		if(dialogid == DIALOG_EDIT_VEH_MODEL)
		{
			value = ER_FindVehicleModel(inputtext);
			if(value < 400 || value > 611)
			{
				ER_Send(playerid, COLOR_GREY, "Invalid vehicle model/name.");
				return ER_ShowVehicleEditor(playerid, sqlid);
			}
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `model`=%d WHERE `id`=%d", value, sqlid);
		}
		else if(dialogid == DIALOG_EDIT_VEH_COLOR1)
		{
			value = strval(inputtext);
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `color1`=%d WHERE `id`=%d", value, sqlid);
		}
		else if(dialogid == DIALOG_EDIT_VEH_COLOR2)
		{
			value = strval(inputtext);
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `color2`=%d WHERE `id`=%d", value, sqlid);
		}
		else
		{
			value = strval(inputtext);
			mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `paintjob`=%d WHERE `id`=%d", value, sqlid);
		}
		mysql_tquery(MainPipeline, q, "ER_ReloadVehicles");
		ER_Send(playerid, COLOR_GREEN, "Vehicle updated.");
		return ER_ShowVehicleEditor(playerid, sqlid);
	}

	return 0;
}

forward ER_OnEditVehicleListSelect(playerid);
public ER_OnEditVehicleListSelect(playerid)
{
	new rows, sqlid;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");
	cache_get_value_name_int(0, "id", sqlid);
	SetPVarInt(playerid, "EditingVehicleID", sqlid);
	return ER_ShowVehicleEditor(playerid, sqlid);
}

forward ER_OnTrackVehicleSelect(playerid);
public ER_OnTrackVehicleSelect(playerid)
{
	new rows, Float:x, Float:y, Float:z, sqlid, model;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");

	cache_get_value_name_int(0, "id", sqlid);
	cache_get_value_name_int(0, "model", model);
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);

	if(VehicleTrackIcon[playerid] != -1) DestroyDynamicMapIcon(VehicleTrackIcon[playerid]);
	VehicleTrackIcon[playerid] = CreateDynamicMapIcon(x, y, z, 55, 0xFF0000FF, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid), playerid, 6000.0, MAPICON_GLOBAL);

	new msg[128];
	format(msg, sizeof(msg), "Tracking vehicle %d: %s. Red marker added to your map.", sqlid, ER_GetVehicleModelName(model));
	return ER_Send(playerid, COLOR_GREEN, msg);
}

forward ER_OnGotoVehicleSQL(playerid);
public ER_OnGotoVehicleSQL(playerid)
{
	new rows, Float:x, Float:y, Float:z, interior, vw;
	cache_get_row_count(rows);
	if(!rows) return ER_Send(playerid, COLOR_GREY, "Vehicle not found.");
	cache_get_value_name_float(0, "x", x);
	cache_get_value_name_float(0, "y", y);
	cache_get_value_name_float(0, "z", z);
	cache_get_value_name_int(0, "interior", interior);
	cache_get_value_name_int(0, "vw", vw);
	SetPlayerInterior(playerid, interior);
	SetPlayerVirtualWorld(playerid, vw);
	SetPlayerPos(playerid, x + 2.0, y, z);
	return 1;
}


stock ER_PlayerCanUseVehicle(playerid, vehicleid)
{
    new idx = ER_FindVehicleBySpawnID(vehicleid);
    if(idx == -1) return 0;

    if(VehicleInfo[idx][vOwnerPID] > 0 && VehicleInfo[idx][vOwnerPID] == PlayerInfo[playerid][pID])
    {
        ER_Send(playerid, COLOR_GREEN, "You are the owner of this vehicle.");
        return 1;
    }

    if(VehicleInfo[idx][vFactionID] > 0 && VehicleInfo[idx][vFactionID] == PlayerInfo[playerid][pFaction])
    {
        ER_Send(playerid, COLOR_GREEN, "You are in a faction that owns this vehicle.");
        return 1;
    }

    if(VehicleInfo[idx][vFamilyID] > 0 && VehicleInfo[idx][vFamilyID] == PlayerInfo[playerid][pFamily])
    {
        ER_Send(playerid, COLOR_GREEN, "You are in a family that owns this vehicle.");
        return 1;
    }

    return 0;
}

stock ER_PlayerOwnsVehicleDirectly(playerid, vehicleid)
{
    new idx = ER_FindVehicleBySpawnID(vehicleid);
    if(idx == -1) return 0;
    return (VehicleInfo[idx][vOwnerPID] > 0 && VehicleInfo[idx][vOwnerPID] == PlayerInfo[playerid][pID]);
}


CMD:veh(playerid, params[])
{
    new vehicleid = GetPlayerVehicleID(playerid);
    if(vehicleid == 0) return ER_Send(playerid, COLOR_GREY, "You must be inside a vehicle.");
    ER_PlayerCanUseVehicle(playerid, vehicleid);

    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /veh(icle) [engine/lights/hood/trunk/windows]");
    return ER_Send(playerid, COLOR_GREY, "Vehicle component command placeholder. Engine/lights/hood/trunk/windows logic comes next.");
}
alias:veh("vehicle")

CMD:vehlock(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREY, "Vehicle lock/unlock placeholder. Ownership lock logic comes next.");
}
alias:vehlock("vehiclelock")

CMD:park(playerid, params[])
{
    new vehicleid = GetPlayerVehicleID(playerid);
    if(vehicleid == 0) return ER_Send(playerid, COLOR_GREY, "You must be inside the vehicle you wish to park.");
    if(!ER_PlayerOwnsVehicleDirectly(playerid, vehicleid))
    {
        return ER_Send(playerid, COLOR_GREY, "You cannot park a vehicle you do not personally own.");
    }

    new idx = ER_FindVehicleBySpawnID(vehicleid);
    if(idx == -1) return ER_Send(playerid, COLOR_GREY, "This vehicle is not a saved dynamic vehicle.");

    new Float:x, Float:y, Float:z, Float:a, q[256];
    GetVehiclePos(vehicleid, x, y, z);
    GetVehicleZAngle(vehicleid, a);

    VehicleInfo[idx][vX] = x;
    VehicleInfo[idx][vY] = y;
    VehicleInfo[idx][vZ] = z;
    VehicleInfo[idx][vA] = a;
    VehicleInfo[idx][vInt] = GetPlayerInterior(playerid);
    VehicleInfo[idx][vVW] = GetPlayerVirtualWorld(playerid);

    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `vehicles` SET `x`=%f,`y`=%f,`z`=%f,`a`=%f,`interior`=%d,`vw`=%d WHERE `id`=%d",
        x, y, z, a, VehicleInfo[idx][vInt], VehicleInfo[idx][vVW], VehicleInfo[idx][vSQLID]);
    mysql_tquery(MainPipeline, q);

    SetVehicleToRespawn(vehicleid);
    SetVehiclePos(vehicleid, x, y, z);
    SetVehicleZAngle(vehicleid, a);
    SetVehicleVirtualWorld(vehicleid, VehicleInfo[idx][vVW]);
    LinkVehicleToInterior(vehicleid, VehicleInfo[idx][vInt]);
    PutPlayerInVehicle(playerid, vehicleid, 0);

    return ER_Send(playerid, COLOR_GREEN, "Your vehicle has been parked successfully.");
}
