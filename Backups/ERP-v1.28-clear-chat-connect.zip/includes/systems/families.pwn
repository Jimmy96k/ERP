#if defined _ER_FAMILIES_INCLUDED
    #endinput
#endif
#define _ER_FAMILIES_INCLUDED

stock ER_LoadFamilies()
{
    mysql_tquery(MainPipeline, "SELECT * FROM `families` WHERE `enabled`=1", "ER_OnFamiliesLoad");
    return 1;
}
forward ER_OnFamiliesLoad();
public ER_OnFamiliesLoad()
{
    new rows; cache_get_row_count(rows); FamilyCount = 0;
    for(new r; r < rows && FamilyCount < MAX_FAMILIES; r++)
    {
        cache_get_value_name_int(r, "id", Families[FamilyCount][fSQLID]);
        cache_get_value_name(r, "name", Families[FamilyCount][fName], 64);
        cache_get_value_name_int(r, "leader_id", Families[FamilyCount][fLeaderID]);
        cache_get_value_name(r, "leader_name", Families[FamilyCount][fLeaderName], MAX_PLAYER_NAME_EX);
        cache_get_value_name(r, "motd", Families[FamilyCount][fMOTD], 128);
        cache_get_value_name_int(r, "color", Families[FamilyCount][fColor]);
        cache_get_value_name_int(r, "radio_color", Families[FamilyCount][fRadioColor]);
        if(Families[FamilyCount][fColor] == 0) Families[FamilyCount][fColor] = COLOR_GREEN;
        if(Families[FamilyCount][fRadioColor] == 0) Families[FamilyCount][fRadioColor] = COLOR_GREEN;
        FamilyCount++;
    }
    printf("[Families] Loaded %d families.", FamilyCount);
    return 1;
}

stock ER_GetAccountNameBySQL(playerid, sqlid, callback[], extra)
{
    new q[160];
    mysql_format(MainPipeline, q, sizeof(q), "SELECT `username` FROM `accounts` WHERE `id`=%d LIMIT 1", sqlid);
    mysql_tquery(MainPipeline, q, callback, "iii", playerid, sqlid, extra);
    return 1;
}

CMD:createfamily(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /createfamily [name]");
    new q[512];
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `families` (`name`,`leader_id`,`leader_name`,`motd`,`color`,`radio_color`,`safe_deposit_rank`,`safe_withdraw_rank`,`locker_deposit_rank`,`locker_withdraw_rank`,`locker_gun_rank`,`enabled`) VALUES ('%e',0,'Nobody','Welcome to the family.',0x33CC33FF,0x33CC33FF,1,6,1,6,1,1)", params);
    mysql_tquery(MainPipeline, q, "ER_OnFamilyCreated", "i", playerid);
    return 1;
}
forward ER_OnFamilyCreated(playerid);
public ER_OnFamilyCreated(playerid)
{
    new fid = cache_insert_id(), q[1024];
    for(new r = 1; r <= 6; r++)
    {
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_ranks` (`family_id`,`rank_id`,`rank_name`) VALUES (%d,%d,'Rank %d')", fid, r, r);
        mysql_tquery(MainPipeline, q);
    }
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_crews` (`family_id`,`crew_id`,`crew_name`) VALUES (%d,1,'Default Crew')", fid);
    mysql_tquery(MainPipeline, q);
    mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_lockers` (`family_id`,`materials`,`enabled`) VALUES (%d,10000,1)", fid);
    mysql_tquery(MainPipeline, q, "ER_OnDefaultFamilyLocker", "i", fid);
    ER_LoadFamilies();
    ER_Send(playerid, COLOR_GREEN, "Family created with 6 ranks, 1 crew, 1 locker and default materials.");
    ER_ShowFamilyEditor(playerid, fid);
    return 1;
}
forward ER_OnDefaultFamilyLocker(fid);
public ER_OnDefaultFamilyLocker(fid)
{
    new lockerid = cache_insert_id(), q[256];
    for(new w; w < 10; w++)
    {
        new weapon = (w == 0) ? 22 : ((w == 1) ? 23 : ((w == 2) ? 29 : 0));
        mysql_format(MainPipeline, q, sizeof(q), "INSERT INTO `family_locker_guns` (`locker_id`,`weaponid`,`admin_enabled`,`leader_enabled`) VALUES (%d,%d,1,1)", lockerid, weapon);
        mysql_tquery(MainPipeline, q);
    }
    return 1;
}

CMD:editfamilies(playerid, params[])
{
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    new list[2048];
    for(new i; i < FamilyCount; i++) format(list, sizeof(list), "%s%d | %s | Leader: %s\n", list, Families[i][fSQLID], Families[i][fName], Families[i][fLeaderName]);
    if(!FamilyCount) return ER_Send(playerid, COLOR_GREY, "No families found.");
    ShowPlayerDialog(playerid, DIALOG_FAMILY_LIST, DIALOG_STYLE_LIST, "Select Family", list, "Edit", "Cancel");
    return 1;
}

stock ER_ShowFamilyEditor(playerid, fid)
{
    new q[160];
    SetPVarInt(playerid, "EditingFamily", fid);
    mysql_format(MainPipeline, q, sizeof(q), "SELECT * FROM `families` WHERE `id`=%d LIMIT 1", fid);
    mysql_tquery(MainPipeline, q, "ER_OnShowFamilyEditor", "i", playerid);
    return 1;
}

forward ER_OnShowFamilyEditor(playerid);
public ER_OnShowFamilyEditor(playerid)
{
    new rows, fid, name[64], leaderid, leader[24], motd[128], list[1200], color, radiocolor;
    cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "Family not found.");

    cache_get_value_name_int(0, "id", fid);
    cache_get_value_name(0, "name", name, sizeof(name));
    cache_get_value_name_int(0, "leader_id", leaderid);
    cache_get_value_name(0, "leader_name", leader, sizeof(leader));
    cache_get_value_name(0, "motd", motd, sizeof(motd));
    cache_get_value_name_int(0, "color", color);
    cache_get_value_name_int(0, "radio_color", radiocolor);
    if(color == 0) color = COLOR_GREEN;
    if(radiocolor == 0) radiocolor = COLOR_GREEN;

    if(leaderid == 0 || isnull(leader)) format(leader, sizeof(leader), "Nobody");
    if(isnull(motd)) format(motd, sizeof(motd), "None");

    format(list, sizeof(list),
        "Name: %s\nLeader: %s\nMOTD: %s\nFamily Color\nFamily Radio Color\nRanks\nCrews\nLockers\nSafes\nPermissions\nStatus\nSave & Reload",
        name, leader, motd);
    ShowPlayerDialog(playerid, DIALOG_FAMILY_EDITOR, DIALOG_STYLE_LIST, "Family Editor", list, "Select", "Close");
    return 1;
}

CMD:editfamily(playerid, params[])
{
    new fid;
    if(!ER_IsAdmin(playerid, ADMIN_HEAD)) return ER_Send(playerid, COLOR_GREY, "You are not authorized.");
    if(sscanf(params, "d", fid)) return ER_Send(playerid, COLOR_GREY, "USAGE: /editfamily [id]");
    return ER_ShowFamilyEditor(playerid, fid);
}

CMD:f(playerid, params[])
{
    if(PlayerInfo[playerid][pFamily] <= 0) return ER_Send(playerid, COLOR_GREY, "You are not in a family.");
    if(isnull(params)) return ER_Send(playerid, COLOR_GREY, "USAGE: /f [message]");
    new msg[160], sendcolor = COLOR_GREEN;
    new famidx = ER_FindFamilyIndexBySQLID(PlayerInfo[playerid][pFamily]);
    if(famidx != -1 && Families[famidx][fRadioColor] != 0) sendcolor = Families[famidx][fRadioColor];
    format(msg, sizeof(msg), "(( Family )) [Crew %d] %s: %s", PlayerInfo[playerid][pFamilyCrew], ER_GetName(playerid), params);
    foreach(new i : Player) if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pFamily] == PlayerInfo[playerid][pFamily]) SendClientMessage(i, sendcolor, msg);
    return 1;
}
alias:f("family")

CMD:familysettings(playerid, params[])
{
    return ER_Send(playerid, COLOR_GREEN, "Family settings placeholder. Leaders will manage leader-enabled guns, lockers, safes and crews here.");
}

stock ER_SaveFamilyText(playerid, field, const value[])
{
    new fid = GetPVarInt(playerid, "EditingFamily"), q[256];
    if(field == 1) mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `name`='%e' WHERE `id`=%d", value, fid);
    else mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `motd`='%e' WHERE `id`=%d", value, fid);
    mysql_tquery(MainPipeline, q, "ER_LoadFamilies");
    ER_Send(playerid, COLOR_GREEN, "Family updated.");
    ER_ShowFamilyEditor(playerid, fid);
    return 1;
}

forward ER_OnFamilyLeaderName(playerid, sqlid, fid);
public ER_OnFamilyLeaderName(playerid, sqlid, fid)
{
    new rows, name[24], q[512];
    cache_get_row_count(rows);
    if(!rows) return ER_Send(playerid, COLOR_GREY, "No account found with that SQL ID.");
    cache_get_value_name(0, "username", name, sizeof(name));

    // Save leader in family table.
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `leader_id`=%d,`leader_name`='%e' WHERE `id`=%d", sqlid, name, fid);
    mysql_tquery(MainPipeline, q, "ER_LoadFamilies");

    // Also join the account to this family as leader rank.
    // family_rank 6 = Leader, family_crew 0 = no crew.
    mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `family_id`=%d,`family_rank`=6,`family_crew`=0 WHERE `id`=%d", fid, sqlid);
    mysql_tquery(MainPipeline, q);

    foreach(new i : Player)
    {
        if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pID] == sqlid)
        {
            PlayerInfo[i][pFamily] = fid;
            PlayerInfo[i][pFamilyRank] = 6;
            PlayerInfo[i][pFamilyCrew] = 0;
            break;
        }
    }

    ER_Send(playerid, COLOR_GREEN, "Family leader updated and assigned to the family with rank 6.");
    return ER_ShowFamilyEditor(playerid, fid);
}

stock ER_FamilyDialog(playerid, dialogid, response, listitem, inputtext[])
{
    if(dialogid == DIALOG_FAMILY_LIST)
    {
        if(response && listitem >= 0 && listitem < FamilyCount) ER_ShowFamilyEditor(playerid, Families[listitem][fSQLID]);
        return 1;
    }

    if(dialogid == DIALOG_FAMILY_EDITOR)
    {
        if(!response) return 1;
        new fid = GetPVarInt(playerid, "EditingFamily");
        switch(listitem)
        {
            case 0:
            {
                SetPVarInt(playerid, "FamilyInputField", 1);
                ShowPlayerDialog(playerid, DIALOG_FAMILY_INPUT, DIALOG_STYLE_INPUT, "Family Name", "Enter new family name:", "Save", "Back");
            }
            case 1: ShowPlayerDialog(playerid, DIALOG_FAMILY_LEADER_TYPE, DIALOG_STYLE_LIST, "Family Leader", "Online Player\nOffline Player SQL ID\nClear Leader", "Select", "Back");
            case 2:
            {
                SetPVarInt(playerid, "FamilyInputField", 2);
                ShowPlayerDialog(playerid, DIALOG_FAMILY_INPUT, DIALOG_STYLE_INPUT, "Family MOTD", "Enter new family MOTD:", "Save", "Back");
            }
            case 3:
            {
                SetPVarInt(playerid, "FamilyColorField", 1);
                ER_ShowNamedColorDialog(playerid, DIALOG_FAMILY_COLOR_SELECT, "Family Color");
            }
            case 4:
            {
                SetPVarInt(playerid, "FamilyColorField", 2);
                ER_ShowNamedColorDialog(playerid, DIALOG_FAMILY_COLOR_SELECT, "Family Radio Color");
            }
            case 5: ShowPlayerDialog(playerid, DIALOG_FAMILY_RANKS, DIALOG_STYLE_MSGBOX, "Family Ranks", "Rank editor foundation is ready.\nFull rank rename/manage dialog comes next.", "Back", "");
            case 6: ShowPlayerDialog(playerid, DIALOG_FAMILY_RANKS, DIALOG_STYLE_MSGBOX, "Family Crews", "Crew editor foundation is ready.\nFull crew rename/manage dialog comes next.", "Back", "");
            case 7: ShowPlayerDialog(playerid, DIALOG_FAMILY_LOCKERS, DIALOG_STYLE_MSGBOX, "Family Lockers", "Locker editor foundation is ready.\nGuns/materials management comes next.", "Back", "");
            case 8: ShowPlayerDialog(playerid, DIALOG_FAMILY_LOCKERS, DIALOG_STYLE_MSGBOX, "Family Safes", "Safe editor foundation is ready.\nDeposit/withdraw positions come next.", "Back", "");
            case 9: ShowPlayerDialog(playerid, DIALOG_FAMILY_PERMS, DIALOG_STYLE_MSGBOX, "Family Permissions", "Permission editor foundation is ready.\nSafe/locker rank permissions come next.", "Back", "");
            case 10:
            {
                new q[128];
                mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `enabled`=IF(`enabled`=1,0,1) WHERE `id`=%d", fid);
                mysql_tquery(MainPipeline, q, "ER_LoadFamilies");
                ER_Send(playerid, COLOR_GREEN, "Family status toggled.");
                ER_ShowFamilyEditor(playerid, fid);
            }
            case 11:
            {
                ER_LoadFamilies();
                ER_Send(playerid, COLOR_GREEN, "Families reloaded.");
                ER_ShowFamilyEditor(playerid, fid);
            }
        }
        return 1;
    }

    if(dialogid == DIALOG_FAMILY_INPUT)
    {
        if(!response) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        return ER_SaveFamilyText(playerid, GetPVarInt(playerid, "FamilyInputField"), inputtext);
    }

    if(dialogid == DIALOG_FAMILY_COLOR_SELECT)
    {
        if(!response) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));

        new fid = GetPVarInt(playerid, "EditingFamily"), field = GetPVarInt(playerid, "FamilyColorField"), q[160];
        new color = ER_GetNamedColorValue(listitem);

        if(field == 1)
        {
            mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `color`=%d WHERE `id`=%d", color, fid);
            ER_Send(playerid, color, "Family color updated.");
        }
        else
        {
            mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `radio_color`=%d WHERE `id`=%d", color, fid);
            ER_Send(playerid, color, "Family radio color updated.");
        }

        mysql_tquery(MainPipeline, q, "ER_LoadFamilies");
        return ER_ShowFamilyEditor(playerid, fid);
    }

    if(dialogid == DIALOG_FAMILY_LEADER_TYPE)
    {
        if(!response) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        if(listitem == 0)
        {
            new list[1024], count, pvarname[24], name[MAX_PLAYER_NAME];
            list[0] = EOS;
            foreach(new i : Player)
            {
                if(PlayerInfo[i][pLoggedIn] && PlayerInfo[i][pID] > 0)
                {
                    GetPlayerName(i, name, sizeof(name));
                    format(pvarname, sizeof(pvarname), "FamLeadOnline%d", count);
                    SetPVarInt(playerid, pvarname, i);
                    format(list, sizeof(list), "%s%d\t%s\tSQL ID: %d\n", list, i, name, PlayerInfo[i][pID]);
                    count++;
                }
            }
            if(!count) return ER_Send(playerid, COLOR_GREY, "No online players found.");
            return ShowPlayerDialog(playerid, DIALOG_FAMILY_LEADER_ONLINE, DIALOG_STYLE_TABLIST, "Select Online Leader", list, "Select", "Back");
        }
        if(listitem == 1) return ShowPlayerDialog(playerid, DIALOG_FAMILY_LEADER_OFFLINE, DIALOG_STYLE_INPUT, "Offline Leader", "Enter player SQL ID:", "Save", "Back");

        new q[128], fid = GetPVarInt(playerid, "EditingFamily");
        mysql_format(MainPipeline, q, sizeof(q), "UPDATE `accounts` SET `family_id`=0,`family_rank`=0,`family_crew`=0 WHERE `family_id`=%d AND `family_rank`=6", fid);
        mysql_tquery(MainPipeline, q);
        mysql_format(MainPipeline, q, sizeof(q), "UPDATE `families` SET `leader_id`=0,`leader_name`='Nobody' WHERE `id`=%d", fid);
        mysql_tquery(MainPipeline, q, "ER_LoadFamilies");
        ER_Send(playerid, COLOR_GREEN, "Family leader cleared.");
        return ER_ShowFamilyEditor(playerid, fid);
    }

    if(dialogid == DIALOG_FAMILY_LEADER_ONLINE)
    {
        if(!response) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        new pvarname[24]; format(pvarname, sizeof(pvarname), "FamLeadOnline%d", listitem);
        new target = GetPVarInt(playerid, pvarname);
        if(!IsPlayerConnected(target) || PlayerInfo[target][pID] <= 0) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        return ER_GetAccountNameBySQL(playerid, PlayerInfo[target][pID], "ER_OnFamilyLeaderName", GetPVarInt(playerid, "EditingFamily"));
    }

    if(dialogid == DIALOG_FAMILY_LEADER_OFFLINE)
    {
        if(!response) return ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        new sqlid = strval(inputtext);
        if(sqlid <= 0) return ER_Send(playerid, COLOR_GREY, "Invalid SQL ID.");
        return ER_GetAccountNameBySQL(playerid, sqlid, "ER_OnFamilyLeaderName", GetPVarInt(playerid, "EditingFamily"));
    }

    if(dialogid == DIALOG_FAMILY_RANKS || dialogid == DIALOG_FAMILY_LOCKERS || dialogid == DIALOG_FAMILY_PERMS)
    {
        ER_ShowFamilyEditor(playerid, GetPVarInt(playerid, "EditingFamily"));
        return 1;
    }
    return 0;
}
