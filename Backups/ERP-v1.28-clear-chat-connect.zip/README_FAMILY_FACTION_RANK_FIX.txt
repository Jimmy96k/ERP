ERP v1.28 Family/Faction membership rank fix

Fixed:
- When /editfamilies sets a family leader, that account is also updated:
  family_id = family ID
  family_rank = 6
  family_crew = 0
- When /editfactions sets a faction leader, that account is also updated:
  faction_id = faction ID
  faction_rank = 6
  faction_division = 0
- New/default players now use:
  family_id = 0
  faction_id = 0
  family_rank = 0
  family_crew = 0
  faction_rank = 0
  faction_division = 0
- If a player is only joined later as normal member, use rank 1 and crew/division 0.
- Existing leaders in SQL can be normalized by running the migration.

Run SQL:
SQL_V128_FAMILY_FACTION_RANK_FIX.sql
