Clear chat timing fix

Changed:
- Chat now clears on OnPlayerConnect.
- Removed ER_ClearChat from successful login/character load.
- Therefore the post-login messages stay visible:
  SERVER: Welcome, Name.
  Family MOTD
  Faction MOTD
  Admin MOTD
